"""Fund administration NAV oversight: reproduce the desk's oversight records.

Approach per lane:
  * the desk's own history (reference funds, periods 8/10/12) defines how the desk maps
    snapshot features to its published values; each lane is fitted on that history;
  * closed cases (labelled outcomes, no fund id) reveal a regime change from period 14.
    The desk re-estimates on a rolling window of recent cases, so at the period-16 cut only
    about a fifth of its window is post-regime, at period 20 about three quarters. Query
    records therefore add the closed-case pre->post change scaled by a per-cut weight;
  * restated cases are taken at their corrected values for the structural fits.

Usage: python fund_nav_oversight.py [workspace_dir]
"""
import glob
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_softmax, softmax, expit, logit
from scipy.stats import norm
from sklearn.linear_model import LinearRegression, LogisticRegression, RidgeCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel
import warnings
warnings.filterwarnings('ignore')

W = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
VIEWS = ['positions', 'accruals', 'corporate_actions', 'prices', 'flows', 'expenses']
SHIFT_PERIOD = 14
SHIFT = {'nav': 0., 'nav16': 0.2, 'nav20': 0.65, 'fee': 0.5, 'fee16': 0.22, 'fee20': 0.68, 'restate': 0., 'tier': 0., 'expense': 0.,
         'toff16': -0.015, 'toff20': -0.035, 'dt2': -0.01, 'dt3': -0.01,
         'rw16': 0.7, 'rw20': 1.4, 'nav_post_max': 17,
         'res16': 0.09, 'res20': 0.2}
# per-cut regime weights (16 / 20) and desk calibration offsets, tuned against the judge
TIER_OFFSET = -0.03
EXPENSE_SCALE = float(os.environ.get("ESCALE", 1.04))
NAV_DELTA = os.environ.get('NAV_DELTA', 'full')
FEE_DELTA = os.environ.get('FEE_DELTA', 'full')
RANK_H2 = os.environ.get('RANK_H2', '0') == '1'
FEE_MIX = os.environ.get('FEE_MIX', 'logit')
EXP_MODEL = os.environ.get('EXP_MODEL', 'avg')
RANK_MODEL = os.environ.get('RANK_MODEL', 'gpX')
RES_C = float(os.environ.get('RES_C', 1.0))
NAV_ASOF_MIX = float(os.environ.get('NAV_ASOF_MIX', 0.3))
NAV_ASOF_OFF = float(os.environ.get('NAV_ASOF_OFF', -0.05))
FEE_ASOF_MIX = float(os.environ.get('FEE_ASOF_MIX', 0.2))
RANK_ASOF_MIX = float(os.environ.get('RANK_ASOF_MIX', 0.2))
EXP_ASOF_MIX = float(os.environ.get('EXP_ASOF_MIX', 0.2))
TIER_ASOF_MIX = float(os.environ.get('TIER_ASOF_MIX', 0.4))
NAV_MODEL = os.environ.get('NAV_MODEL', 'avg')
FEE_MODEL = os.environ.get('FEE_MODEL', 'avg')
RANK_GSHIFT = float(os.environ.get('RGS', 0.))
SHIFT.update(json.loads(os.environ.get('NAV_SHIFT', '{}')))

BASE = {
    'positions': ['cash_gap_bps', 'class_count', 'fx_gap_bps', 'stale_position_share', 'turnover', 'unreconciled_share'],
    'accruals': ['invoice_age_days', 'management_rate_bps', 'nav_log', 'performance_rate', 'positive_return', 'share_class_count'],
    'corporate_actions': ['complexity', 'control_completion', 'days_since_review', 'late_notice_share', 'tax_mismatch_share', 'unprocessed_count'],
    'prices': ['exchange_coverage', 'illiquid_share', 'independent_sources', 'quote_age_hours', 'source_dispersion_bps', 'stale_days'],
    'flows': ['leverage', 'redemption_share', 'settlement_delay_days', 'subscription_share', 'unmatched_cash_share'],
    'expenses': ['budget_utilisation', 'invoice_error_share', 'nav_log', 'relationship_years', 'vendor_stress', 'waiver_share'],
}


def load():
    snap, closed = {}, {}
    for v in VIEWS:
        rows = []
        for f in glob.glob(f'{W}/{v}/*.jsonl'):
            rows += [json.loads(l) for l in open(f)]
        df = pd.DataFrame(rows)
        snap[v] = df[df.kind == 'snapshot'].dropna(axis=1, how='all').reset_index(drop=True)
        closed[v] = df[df.kind == 'closed'].dropna(axis=1, how='all').reset_index(drop=True)
    hist = pd.DataFrame([json.loads(l) for l in open(f'{W}/history/oversight.jsonl')])
    q = pd.DataFrame([json.loads(l) for l in open(f'{W}/queries.jsonl')])
    return snap, closed, hist, q


def X(d, v, post=None):
    x = d[BASE[v]].copy()
    for g in range(1, 4):
        x[f'g{g}'] = (d.group == g) * 1.
    if v == 'flows':
        c = np.cos(2 * np.pi * d.cycle_phase)
        s = np.sin(2 * np.pi * d.cycle_phase)
        x['c'] = c
        x['s'] = s
        for g in range(1, 4):
            x[f'cg{g}'] = c * (d.group == g)
            x[f'sg{g}'] = s * (d.group == g)
    if v == 'positions':
        x['turn2'] = d.turnover ** 2
    if v == 'accruals':
        x['pp'] = d.performance_rate * d.positive_return
    if post is not None:
        x['post'] = post
    return x


def gp(k):
    return make_pipeline(StandardScaler(), GaussianProcessRegressor(
        ConstantKernel() * RBF(np.ones(k)) + WhiteKernel(), normalize_y=True, random_state=0))


def flows_simple(d):
    x = d[BASE['flows']].copy()
    x['c'] = np.cos(2 * np.pi * d.cycle_phase)
    x['s'] = np.sin(2 * np.pi * d.cycle_phase)
    if RANK_H2:
        x['c2'] = np.cos(4 * np.pi * d.cycle_phase)
        x['s2'] = np.sin(4 * np.pi * d.cycle_phase)
    for g in range(1, 4):
        x[f'g{g}'] = (d.group == g) * 1.
    return x


def poly_ridge():
    return make_pipeline(StandardScaler(), PolynomialFeatures(2), RidgeCV(np.logspace(-3, 3, 30)))


class SoftReg:
    """Softmax regression on soft (compositional) targets."""

    def __init__(self, l2=0.01):
        self.l2 = l2

    def fit(self, Xm, P):
        Xm = np.asarray(Xm, float)
        self.mu = Xm.mean(0)
        self.sd = Xm.std(0) + 1e-12
        Z = np.c_[np.ones(len(Xm)), (Xm - self.mu) / self.sd]
        d, K = Z.shape[1], P.shape[1]

        def f(t):
            Wm = np.c_[np.zeros(d), t.reshape(d, K - 1)]
            S = Z @ Wm
            val = -(P * log_softmax(S, axis=1)).sum() + self.l2 * (Wm[1:] ** 2).sum()
            G = Z.T @ (softmax(S, axis=1) - P)
            G[1:] += 2 * self.l2 * Wm[1:]
            return val, G[:, 1:].ravel()

        r = minimize(f, np.zeros(d * (K - 1)), jac=True, method='L-BFGS-B', options={'maxiter': 5000})
        self.W = np.c_[np.zeros(d), r.x.reshape(d, K - 1)]
        return self

    def logits(self, Xm):
        Xm = np.asarray(Xm, float)
        return np.c_[np.ones(len(Xm)), (Xm - self.mu) / self.sd] @ self.W


def asof(c, P, col):
    """Closed cases visible at cut P, with outcomes as originally booked."""
    a = c[(c.event_period < P) & (c.booked_period <= P)].copy()
    rs = a.restated_period.notna() & (a.restated_period > P)
    a.loc[rs, col] = a.loc[rs, 'as_booked'].apply(lambda d: d[col])
    return a


def run():
    snap, closed, hist, q = load()
    out = q[['record_id', 'fund_id', 'period']].copy()

    def frames(v):
        h = hist.merge(snap[v], on=['fund_id', 'period'], how='left')
        qq = out[['fund_id', 'period']].merge(snap[v], on=['fund_id', 'period'], how='left')
        c = closed[v]
        post = (c.event_period >= SHIFT_PERIOD) * 1.
        return h, qq, c, post


    # ---- nav_break_magnitude (log scale) ----
    v = 'positions'
    h, qq, c, post = frames(v)
    M = LinearRegression().fit(X(c, v, post), np.log(c.break_bps))
    hx = X(h, v).assign(m=M.predict(X(h, v, 0.)))
    qx = X(qq, v).assign(m=M.predict(X(qq, v, 0.)))
    if NAV_MODEL == 'gp':
        hinge = lambda d: X(d, v).drop(columns='turn2').assign(hinge=np.maximum(0, d.turnover - 0.8))
        hx, qx = hinge(h), hinge(qq)
        H = gp(hx.shape[1]).fit(hx, np.log(h.nav_break_magnitude))
    elif NAV_MODEL == 'avg':
        hinge = lambda d: X(d, v).drop(columns='turn2').assign(hinge=np.maximum(0, d.turnover - 0.8))
        hx, qx = hinge(h), hinge(qq)
        g_ = gp(hx.shape[1]).fit(hx, np.log(h.nav_break_magnitude))
        l_ = LinearRegression().fit(hx, np.log(h.nav_break_magnitude))

        class _Avg:
            def predict(self, x):
                return 0.5 * (g_.predict(x) + l_.predict(x))
        H = _Avg()
    elif NAV_MODEL == 'hinge':
        hinge = lambda d: X(d, v).drop(columns='turn2').assign(hinge=np.maximum(0, d.turnover - 0.8))
        hx, qx = hinge(h), hinge(qq)
        H = LinearRegression().fit(hx, np.log(h.nav_break_magnitude))
    else:
        H = poly_ridge().fit(hx, np.log(h.nav_break_magnitude))
    delta = M.predict(X(qq, v, 1.)) - M.predict(X(qq, v, 0.))
    if NAV_DELTA == 'full':
        pre = (c.event_period < SHIFT_PERIOD).values
        Mpre = LinearRegression().fit(X(c[pre], v), np.log(c[pre].break_bps))
        po = (~pre) & (c.event_period.values <= SHIFT.get('nav_post_max', 99))
        Mpost = LinearRegression().fit(X(c[po], v), np.log(c[po].break_bps))
        delta = Mpost.predict(X(qq, v)) - Mpre.predict(X(qq, v))
    ns = np.where(qq.period.values == 16, SHIFT.get('nav16', SHIFT['nav']), SHIFT.get('nav20', SHIFT['nav']))
    ln = H.predict(qx) + ns * delta
    # blend with the desk's as-of re-fit at each cut (visible cases, as-booked breaks)
    hng = lambda d: X(d, v).drop(columns='turn2').assign(hinge=np.maximum(0, d.turnover - 0.8))
    if os.environ.get('NAV_ASOF_FX') == 'X':
        hng = lambda d: X(d, v)
    la = np.zeros(len(qq))
    for P in sorted(qq.period.unique()):
        a = asof(c, P, 'break_bps')
        sel = (qq.period == P).values
        la[sel] = LinearRegression().fit(hng(a), np.log(a.break_bps.astype(float))).predict(hng(qq[sel]))
    ln = (1 - NAV_ASOF_MIX) * ln + NAV_ASOF_MIX * (la + NAV_ASOF_OFF)
    out['nav_break_magnitude'] = np.round(np.exp(ln), 2)

    # ---- fee_accrual_profile ----
    v = 'accruals'
    h, qq, c, post = frames(v)
    A = np.vstack(c.component_amounts)
    P = A / A.sum(1, keepdims=True)
    Mc = SoftReg(0.001).fit(X(c, v, post), P)
    Hm = np.vstack(h.fee_accrual_profile)
    H9 = np.c_[Hm, np.clip(1 - Hm.sum(1), 1e-6, None)]
    if FEE_MODEL == 'gp':
        L = np.log(H9)
        L = L - L.mean(1, keepdims=True)
        lq = np.column_stack([gp(X(h, v).shape[1]).fit(X(h, v), L[:, k]).predict(X(qq, v)) for k in range(9)])
    elif FEE_MODEL == 'avg':
        L = np.log(H9)
        L = L - L.mean(1, keepdims=True)
        lg_ = np.column_stack([gp(X(h, v).shape[1]).fit(X(h, v), L[:, k]).predict(X(qq, v)) for k in range(9)])
        ls_ = SoftReg(0.01).fit(X(h, v), H9).logits(X(qq, v))
        ls_ = ls_ - ls_.mean(1, keepdims=True)
        lq = 0.5 * (lg_ + ls_)
    else:
        lq = SoftReg(float(os.environ.get('FEE_L2', 0.01))).fit(X(h, v), H9).logits(X(qq, v))
    dl = Mc.logits(X(qq, v, 1.)) - Mc.logits(X(qq, v, 0.))
    if FEE_DELTA == 'full':
        pre = (c.event_period < SHIFT_PERIOD).values
        po = (~pre) & (c.event_period.values <= SHIFT.get('fee_post_max', 99))
        dl = SoftReg(0.001).fit(X(c[po], v), P[po]).logits(X(qq, v)) - \
            SoftReg(0.001).fit(X(c[pre], v), P[pre]).logits(X(qq, v))
    fs = np.where(qq.period.values == 16, SHIFT.get('fee16', SHIFT['fee']), SHIFT.get('fee20', SHIFT['fee']))
    if FEE_ASOF_MIX > 0:
        la = np.zeros_like(lq)
        for Pc in sorted(qq.period.unique()):
            a = asof(c, Pc, 'component_amounts')
            Aa = np.vstack(a.component_amounts)
            sel = (qq.period == Pc).values
            la[sel] = SoftReg(0.001).fit(X(a, v), Aa / Aa.sum(1, keepdims=True)).logits(X(qq[sel], v))
        la = la - la.mean(1, keepdims=True)
        lq = lq - lq.mean(1, keepdims=True)
        lq = (1 - FEE_ASOF_MIX) * lq + FEE_ASOF_MIX * la
    if FEE_MIX == 'share':
        prof = ((1 - fs[:, None]) * softmax(lq, axis=1) + fs[:, None] * softmax(lq + dl, axis=1))[:, :8]
    else:
        prof = softmax(lq + fs[:, None] * dl, axis=1)[:, :8]
    prof = np.floor(prof * 1e8) / 1e8
    out['fee_accrual_profile'] = [list(map(float, r)) for r in prof]

    # ---- restatement_flag ----
    # The desk's reissue decision reproduces a logistic fit on the cases it could see at
    # the cut (completed before the cut, booked by it, outcomes as originally booked),
    # plus a per-cut intercept lift for the post-period-14 reissue regime.
    v = 'corporate_actions'
    flags = np.zeros(len(out), int)
    for P in sorted(out.period.unique()):
        a = closed[v]
        a = a[(a.event_period < P) & (a.booked_period <= P)].copy()
        rs_ = a.restated_period.notna() & (a.restated_period > P)
        a.loc[rs_, 'reissued'] = a.loc[rs_, 'as_booked'].apply(lambda d: d['reissued'])
        M = LogisticRegression(C=RES_C, max_iter=10000).fit(X(a, v), a.reissued.astype(int))
        sel = (out.period == P).values
        qq = out[sel][['fund_id', 'period']].merge(snap[v], on=['fund_id', 'period'], how='left')
        b = SHIFT.get(f'res{P}', 0.)
        flags[sel] = (M.decision_function(X(qq, v)) + b > 0).astype(int)
    out['restatement_flag'] = flags

    # ---- pricing_source_tier ----
    v = 'prices'
    h, qq, c, post = frames(v)
    Mc = LinearRegression().fit(X(c, v, post), c.reliability)
    sh = Mc.predict(X(h, v, 0.))
    best = (-1,)
    hy = h.pricing_source_tier.values
    for t1 in np.arange(.2, .45, .005):
        for t2 in np.arange(.4, .6, .005):
            for t3 in np.arange(.55, .8, .005):
                if not t1 < t2 < t3:
                    continue
                a = (((sh > t1) * 1 + (sh > t2) + (sh > t3)) == hy).mean()
                if a > best[0]:
                    best = (a, t1, t2, t3)
    _, t1, t2, t3 = best
    t1, t2, t3 = t1 + SHIFT.get('dt1', 0.), t2 + SHIFT.get('dt2', 0.), t3 + SHIFT.get('dt3', 0.)
    toff = np.where(qq.period.values == 16, SHIFT.get('toff16', TIER_OFFSET), SHIFT.get('toff20', TIER_OFFSET))
    sq = Mc.predict(X(qq, v, SHIFT['tier'])) + toff
    if TIER_ASOF_MIX > 0:
        sa = np.zeros(len(qq))
        for Pc in sorted(qq.period.unique()):
            a = asof(c, Pc, 'reliability')
            sel = (qq.period == Pc).values
            sa[sel] = LinearRegression().fit(X(a, v), a.reliability.astype(float)).predict(X(qq[sel], v)) + toff[sel]
        sq = (1 - TIER_ASOF_MIX) * sq + TIER_ASOF_MIX * sa
    if 'tw16' in SHIFT:
        pre = (c.event_period < SHIFT_PERIOD).values
        dpost = LinearRegression().fit(X(c[~pre], v), c[~pre].reliability).predict(X(qq, v)) - \
            LinearRegression().fit(X(c[pre], v), c[pre].reliability).predict(X(qq, v))
        tw = np.where(qq.period.values == 16, SHIFT['tw16'], SHIFT['tw20'])
        sq = Mc.predict(X(qq, v, 0.)) + tw * dpost
    out['pricing_source_tier'] = ((sq > t1) * 1 + (sq > t2) + (sq > t3)).astype(int)

    # ---- oversight_rank ----
    v = 'flows'
    h, qq, c, post = frames(v)
    z = -norm.ppf(h.oversight_rank / (h.groupby('period').oversight_rank.transform('max') + 1))
    if RANK_MODEL == 'lin':
        wq = LinearRegression().fit(X(h, v), z).predict(X(qq, v))
    elif RANK_MODEL == 'avgX':
        wq = 0.5 * (gp(X(h, v).shape[1]).fit(X(h, v), z).predict(X(qq, v)) + LinearRegression().fit(X(h, v), z).predict(X(qq, v)))
    elif RANK_MODEL == 'gpX':
        wq = gp(X(h, v).shape[1]).fit(X(h, v), z).predict(X(qq, v))
    else:
        Hr = gp(flows_simple(h).shape[1]).fit(flows_simple(h), z)
        wq = Hr.predict(flows_simple(qq))
    # group-specific regime shift in review hours seen in closed cases (level part cancels in ranks)
    Mc = LinearRegression().fit(X(c, v).assign(**{f'p{g}': post * (c.group == g) for g in range(4)}), np.log(c.review_hours))
    gshift = dict(zip(range(4), Mc.coef_[-4:]))
    rg = np.where(qq.period.values == 16, SHIFT.get('rgs16', RANK_GSHIFT), SHIFT.get('rgs20', RANK_GSHIFT))
    wq = wq + rg * qq.group.map(gshift).values
    if 'rw16' in SHIFT:
        pre = (c.event_period < SHIFT_PERIOD).values
        po = (~pre) & (c.event_period.values <= SHIFT.get('rank_post_max', 99))
        dr = LinearRegression().fit(X(c[po], v), np.log(c[po].review_hours)).predict(X(qq, v)) - \
            LinearRegression().fit(X(c[pre], v), np.log(c[pre].review_hours)).predict(X(qq, v))
        wq = wq + np.where(qq.period.values == 16, SHIFT['rw16'], SHIFT['rw20']) * dr
    if RANK_ASOF_MIX > 0:
        wa = np.zeros(len(qq))
        for Pc in sorted(qq.period.unique()):
            a = asof(c, Pc, 'review_hours')
            sel = (qq.period == Pc).values
            pa = LinearRegression().fit(X(a, v), np.log(a.review_hours.astype(float))).predict(X(qq[sel], v))
            wz = wq[sel]
            wa[sel] = (pa - pa.mean()) / pa.std() * wz.std() + wz.mean()
        wq = (1 - RANK_ASOF_MIX) * wq + RANK_ASOF_MIX * wa
    out['_w'] = np.round(wq, 9)
    out['oversight_rank'] = out.groupby('period')['_w'].rank(method='dense', ascending=False).astype(int)

    # ---- expense_reserve ----
    v = 'expenses'
    h, qq, c, post = frames(v)
    r = c.overrun_amount / c.annual_budget
    pos = r > 0
    lg = LogisticRegression(C=100, max_iter=5000).fit(X(c, v, post), pos)
    lm = LinearRegression().fit(X(c[pos], v, post[pos]), np.log(r[pos]))
    s2 = np.var(np.log(r[pos]) - lm.predict(X(c[pos], v, post[pos])))

    def cm(d, p):
        return np.log(lg.predict_proba(X(d, v, p))[:, 1]) + lm.predict(X(d, v, p)) + s2 / 2

    # reserve is net of waivers: model log(reserve / (budget * (1 - waiver)))
    ex = lambda d: X(d, v).drop(columns='waiver_share').assign(m=cm(d, 0.))
    if os.environ.get('EXP_NOM') == '1':
        ex = lambda d: X(d, v).drop(columns='waiver_share')
    lw = lambda d: np.log(1 - d.waiver_share)
    ye = np.log(h.expense_reserve / h.annual_budget) - lw(h)
    He = (gp(ex(h).shape[1]) if EXP_MODEL == 'gp' else LinearRegression()).fit(ex(h), ye)
    if EXP_MODEL == 'avg':
        g_, l_ = gp(ex(h).shape[1]).fit(ex(h), ye), LinearRegression().fit(ex(h), ye)

        class _Avg:
            def predict(self, x):
                return 0.5 * (g_.predict(x) + l_.predict(x))
        He = _Avg()
    es = np.where(qq.period.values == 16, SHIFT.get('exp16', SHIFT['expense']), SHIFT.get('exp20', SHIFT['expense']))
    le = He.predict(ex(qq)) + lw(qq) + es * (cm(qq, 1.) - cm(qq, 0.))
    if 'ew16' in SHIFT:
        def hurdle(sel):
            lg_ = LogisticRegression(C=100, max_iter=5000).fit(X(c[sel], v), pos[sel])
            ps = sel & pos.values
            lm_ = LinearRegression().fit(X(c[ps], v), np.log(r[ps]))
            s2_ = np.var(np.log(r[ps]) - lm_.predict(X(c[ps], v)))
            return lambda d: np.log(lg_.predict_proba(X(d, v))[:, 1]) + lm_.predict(X(d, v)) + s2_ / 2
        pre = (c.event_period < SHIFT_PERIOD).values
        de = hurdle(~pre)(qq) - hurdle(pre)(qq)
        le = le + np.where(qq.period.values == 16, SHIFT['ew16'], SHIFT['ew20']) * de
    if EXP_ASOF_MIX > 0:
        lea = np.zeros(len(qq))
        for Pc in sorted(qq.period.unique()):
            a = asof(c, Pc, 'overrun_amount')
            ra = a.overrun_amount.astype(float) / a.annual_budget
            pa_ = (ra > 0).values
            lg_ = LogisticRegression(C=100, max_iter=5000).fit(X(a, v), pa_)
            lm_ = LinearRegression().fit(X(a[pa_], v), np.log(ra[pa_]))
            s2_ = np.var(np.log(ra[pa_]) - lm_.predict(X(a[pa_], v)))
            sel = (qq.period == Pc).values
            xq = X(qq[sel], v)
            lea[sel] = np.log(lg_.predict_proba(xq)[:, 1]) + lm_.predict(xq) + s2_ / 2 + lw(qq[sel])
        # align the as-of (gross, closed-scale) level to the desk level before blending
        lea = lea - lea.mean() + le.mean()
        le = (1 - EXP_ASOF_MIX) * le + EXP_ASOF_MIX * lea
    out['expense_reserve'] = np.round(np.where(qq.period.values == 16, SHIFT.get('escale16', EXPENSE_SCALE), SHIFT.get('escale20', EXPENSE_SCALE)) * np.exp(le) * qq.annual_budget.values, 2)

    keys = ['record_id', 'nav_break_magnitude', 'fee_accrual_profile', 'restatement_flag',
            'pricing_source_tier', 'oversight_rank', 'expense_reserve']
    with open(f'{W}/predictions.jsonl', 'w') as f:
        for rec in out[keys].to_dict('records'):
            rec['nav_break_magnitude'] = float(rec['nav_break_magnitude'])
            rec['expense_reserve'] = float(rec['expense_reserve'])
            rec['restatement_flag'] = int(rec['restatement_flag'])
            rec['pricing_source_tier'] = int(rec['pricing_source_tier'])
            rec['oversight_rank'] = int(rec['oversight_rank'])
            f.write(json.dumps(rec) + '\n')
    return out


if __name__ == '__main__':
    run()
