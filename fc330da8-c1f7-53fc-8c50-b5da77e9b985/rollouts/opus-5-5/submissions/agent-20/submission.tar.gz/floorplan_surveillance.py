import json, glob, os, sys
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, GradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression

W = '/workspace'
def rj(p):
    return [json.loads(l) for l in open(p) if l.strip()]

def view(r, q):
    """closed row as known at q, or None"""
    if r['booked_period'] >= q: return None
    if 'restated_period' in r and r['restated_period'] >= q:
        r = dict(r); r.update(r['as_booked'])
    return r

per = {}
for d in ['aging', 'turns', 'reconciliations', 'lines']:
    per[d] = []
    for f in glob.glob(f'{W}/{d}/*.jsonl'):
        per[d] += rj(f)
for d in ['audits', 'repossessions']:
    per[d] = []
    for f in glob.glob(f'{W}/{d}/*.jsonl'):
        per[d] += rj(f)
reg = {os.path.basename(f)[:-5]: json.load(open(f)) for f in glob.glob(f'{W}/register/*.json')}

def snaps(d):
    return {(r['dealer_id'], r['period']): r for r in per[d] if r['kind'] == 'snapshot'}
S = {d: snaps(d) for d in per}

F = {
 'aging': ['aged_share', 'days_supply', 'demand_index', 'incentive_intensity', 'model_year_age', 'price_volatility', 'franchise', 'segment'],
 'turns': ['demand_index', 'lot_velocity', 'marketing_spend_log', 'pricing_discipline', 'stock_age_mix', 'region', 'segment'],
 'reconciliations': ['audit_stage', 'location_count', 'prior_findings', 'reconciliation_lag', 'staff_turnover', 'unit_count_log'],
 'lines': ['curtailment_backlog', 'inventory_days', 'oem_incentive_phase', 'payoff_lag', 'sales_momentum', 'franchise', 'region'],
 'audits': ['audit_variance_rate', 'cash_strain', 'curtailment_misses', 'days_since_audit', 'insurance_lapses', 'late_payoff_count', 'franchise'],
 'repossessions': ['collateral_coverage', 'curtailment_compliance', 'dealer_cash_score', 'market_stress', 'rating_band', 'segment', 'years_in_program'],
}
def X(rows, d): return np.array([[float(r[k]) for k in F[d]] for r in rows])
def closed(d, q): return [v for v in (view(r, q) for r in per[d] if r['kind'] == 'closed') if v]

def LG(p):
    p = min(max(p, 1e-3), 1 - 1e-3); return np.log(p / (1 - p))
def gbr(): return GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0)

def predict_period(q, dealers):
    out = {d: {'record_id': f'{d}:p{q}'} for d in dealers}
    # aging
    c = closed('aging', q); m = gbr().fit(X(c, 'aging'), [r['haircut_ratio'] for r in c], sample_weight=[0.95 ** (q - r['booked_period']) for r in c])
    s = [S['aging'][(d, q)] for d in dealers]; h = m.predict(X(s, 'aging'))
    for d, r, hh in zip(dealers, s, h):
        out[d]['aging_reserve'] = round(max(0.0, r['floored_balance'] * r['aged_share'] * hh), 2)
    # turns: discrete hazard (logistic)
    from sklearn.preprocessing import StandardScaler
    c = closed('turns', q); rows = []; ys = []; tw = []
    def tx(r):
        x = [float(r[k]) for k in F['turns'][:5]]
        return x + [1.0 * (r['region'] == i) for i in range(5)] + [1.0 * (r['segment'] == i) for i in range(5)]
    for r in c:
        last = r['sold_bucket'] if r['sold_bucket'] >= 0 else r['last_observed_bucket']
        for bb in range(last + 1):
            rows.append((tx(r), bb)); ys.append(1 if bb == r['sold_bucket'] else 0); tw.append(0.8 ** (q - r['booked_period']))
    sc = StandardScaler().fit([x for x, _ in rows])
    E = lambda x, bb: list(sc.transform([x])[0]) + [1.0 * (bb == i) for i in range(8)]
    m = LogisticRegression(C=1.0, max_iter=3000).fit([E(x, bb) for x, bb in rows], ys, sample_weight=tw)
    for d in dealers:
        x = tx(S['turns'][(d, q)])
        hz = m.predict_proba([E(x, bb) for bb in range(8)])[:, 1]
        surv = 1.0; prof = []
        for bb in range(8):
            prof.append(surv * hz[bb]); surv *= 1 - hz[bb]
        prof = [max(0.0, round(p, 8)) for p in prof]
        while sum(prof) > 1.0: prof = [round(p * 0.9999999, 8) for p in prof]
        out[d]['turn_profile'] = prof
    # sot
    c = closed('audits', q)
    m = GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0).fit(X(c, 'audits'), [r['sot_event'] for r in c], sample_weight=[0.9 ** (q - r['booked_period']) for r in c])
    s = [S['audits'][(d, q)] for d in dealers]; p = m.predict_proba(X(s, 'audits'))[:, 1]
    for d, pp in zip(dealers, p): out[d]['_sotp'] = pp
    # variance
    c = closed('reconciliations', q); m = gbr().fit(X(c, 'reconciliations'), [r['variance_fraction'] for r in c], sample_weight=[0.95 ** (q - r['booked_period']) for r in c])
    s = [S['reconciliations'][(d, q)] for d in dealers]; v = m.predict(X(s, 'reconciliations'))
    for d, vv in zip(dealers, v):
        out[d]['variance_tier'] = int(sum(vv > t for t in [0.02, 0.05, 0.1])); out[d]['_vf'] = vv
    # lines
    from sklearn.linear_model import LinearRegression
    c = closed('lines', q); m = LinearRegression().fit(X(c, 'lines'), [LG(r['available_fraction']) for r in c])
    res = {}
    for r, p in sorted(zip(c, m.predict(X(c, 'lines'))), key=lambda t: t[0]['event_period']): res.setdefault(r['dealer_id'], []).append(LG(r['available_fraction']) - p)
    s = [S['lines'][(d, q)] for d in dealers]; af = m.predict(X(s, 'lines'))
    af = [a + (len(res.get(d, [])) / (len(res.get(d, [])) + 8) * np.average(res[d], weights=0.85 ** np.arange(len(res[d]))[::-1]) if d in res else 0) for d, a in zip(dealers, af)]
    af = [1 / (1 + np.exp(-a)) for a in af]
    hr = {d: r['credit_line'] * a - r['outstanding'] - r['pending_payoffs'] for d, r, a in zip(dealers, s, af)}
    vals = sorted(set(round(v, 2) for v in hr.values()), reverse=True)
    for d in dealers: out[d]['headroom_rank'] = vals.index(round(hr[d], 2)) + 1
    # loss
    c = closed('repossessions', q)
    from sklearn.preprocessing import StandardScaler
    Xc = X(c, 'repossessions'); sc = StandardScaler().fit(Xc)
    pos = np.array([r['loss_amount'] > 0 for r in c])
    mc = LogisticRegression(max_iter=3000).fit(sc.transform(Xc), pos)
    from sklearn.linear_model import LinearRegression
    ms = LinearRegression().fit(sc.transform(Xc[pos]), [np.log(r['loss_amount'] / r['exposure']) for r, p in zip(c, pos) if p])
    s = [S['repossessions'][(d, q)] for d in dealers]; Xs = sc.transform(X(s, 'repossessions'))
    lr = mc.predict_proba(Xs)[:, 1] * np.exp(ms.predict(Xs))
    for d, r, l in zip(dealers, s, lr):
        out[d]['loss_reserve'] = round(max(0.0, r['exposure'] * l), 2)
    return out

def finalize(out, rate):
    ps = sorted(o['_sotp'] for o in out.values())
    k = int(round(rate * len(ps)))
    thr = ps[-k] if k > 0 else 2
    for o in out.values():
        o['sot_flag'] = int(o.pop('_sotp') >= thr); o.pop('_vf', None)
    return out

HV = {'aging_reserve': ('aging', lambda r: r['floored_balance'] * r['aged_share']),
      'loss_reserve': ('repossessions', lambda r: r['exposure'])}
_cache = {}
def hist_rows(hist, periods):
    X_, Y_ = {f: [] for f in HV}, {f: [] for f in HV}
    for q in periods:
        H = [h for h in hist if h['period'] == q]
        if q not in _cache: _cache[q] = predict_period(q, [h['dealer_id'] for h in H])
        o = _cache[q]
        for h in H:
            for f, (v, base) in HV.items():
                sr = S[v][(h['dealer_id'], q)]; bs = base(sr)
                X_[f].append(X([sr], v)[0].tolist() + [np.log(o[h['dealer_id']][f] / bs + 1e-4)])
                Y_[f].append(np.log(h[f] / bs + 1e-4))
    return X_, Y_
def calibrate(out, q, hist, periods):
    from sklearn.linear_model import LinearRegression
    Xh, Yh = hist_rows(hist, periods)
    for f, (v, base) in HV.items():
        m1 = LinearRegression().fit(Xh[f], Yh[f])
        m2s = [GradientBoostingRegressor(n_estimators=300, max_depth=2, learning_rate=0.03, subsample=0.8, random_state=i).fit(Xh[f], Yh[f]) for i in range(5)]
        class m2:
            predict = staticmethod(lambda z: np.mean([g.predict(z) for g in m2s], axis=0))
        class m:
            predict = staticmethod(lambda z: 0.5 * m1.predict(z) + 0.5 * m2.predict(z))
        for d, o in out.items():
            sr = S[v][(d, q)]; bs = base(sr)
            x = X([sr], v)[0].tolist() + [np.log(o[f] / bs + 1e-4)]
            o[f] = round(max(0.0, (np.exp(m.predict([x])[0]) - 1e-4) * bs), 2)
    from sklearn.linear_model import LogisticRegression as LR
    from sklearn.preprocessing import StandardScaler
    for f, v, key in [('variance_tier', 'reconciliations', '_vf'), ('sot_flag', 'audits', '_sotp')]:
        xs, ys = [], []
        for p in periods:
            for h in [h for h in hist if h['period'] == p]:
                xs.append(X([S[v][(h['dealer_id'], p)]], v)[0].tolist() + [_cache[p][h['dealer_id']][key]]); ys.append(h[f])
        sc = StandardScaler().fit(xs); m = LR(C=1.0, max_iter=3000).fit(sc.transform(xs), ys)
        for d, o in out.items():
            x = X([S[v][(d, q)]], v)[0].tolist() + [o[key]]
            pr = m.predict_proba(sc.transform([x]))[0]
            if f == 'sot_flag': o['_sotp'] = pr[1]
            else: o[f] = int(m.classes_[np.argmax(pr)])
    return out

KEYS = ['record_id', 'aging_reserve', 'turn_profile', 'sot_flag', 'variance_tier', 'headroom_rank', 'loss_reserve']

if __name__ == '__main__':
    hist = rj(f'{W}/history/surveillance.jsonl')
    rate = np.mean([h['sot_flag'] for h in hist])
    if len(sys.argv) > 1 and sys.argv[1] == 'eval':
        for q in [8, 10, 12]:
            H = {h['dealer_id']: h for h in hist if h['period'] == q}
            o = finalize(calibrate(predict_period(q, sorted(H)), q, hist, [p for p in [8,10,12] if p != q]), rate)
            for f in ['aging_reserve', 'loss_reserve']:
                a = np.array([o[d][f] for d in H]); b = np.array([H[d][f] for d in H])
                print(q, f, np.median(np.abs(a - b) / (b + 1)), np.corrcoef(a, b)[0, 1])
            for f in ['sot_flag', 'variance_tier', 'headroom_rank']:
                print(q, f, np.mean([o[d][f] == H[d][f] for d in H]), np.corrcoef([o[d][f] for d in H], [H[d][f] for d in H])[0, 1])
            print(q, 'turn L1', np.mean([np.abs(np.array(o[d]['turn_profile']) - H[d]['turn_profile']).sum() for d in H]))
        sys.exit()
    qs = rj(f'{W}/queries.jsonl'); res = {}
    for q in sorted(set(r['period'] for r in qs)):
        res.update({f'{d}:p{q}': v for d, v in finalize(calibrate(predict_period(q, [r['dealer_id'] for r in qs if r['period'] == q]), q, hist, [8, 10, 12]), rate).items()})
    with open(f'{W}/predictions.jsonl', 'w') as f:
        for r in qs:
            o = res[r['record_id']]; f.write(json.dumps({k: o[k] for k in KEYS}) + '\n')
