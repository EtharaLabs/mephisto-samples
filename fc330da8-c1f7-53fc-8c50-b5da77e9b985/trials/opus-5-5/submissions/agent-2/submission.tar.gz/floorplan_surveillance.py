import json, glob, os, sys
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, GradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression

W = '/workspace'
def rj(p):
    return [json.loads(l) for l in open(p) if l.strip()]

def view(r, q):
    """closed row as known at q, or None"""
    if r['booked_period'] >= q: return None
    if 'restated_period' in r and r['restated_period'] >= q:
        r = dict(r); r.update(r['as_booked'])
    return r

per = {}
for d in ['aging', 'turns', 'reconciliations', 'lines']:
    per[d] = []
    for f in glob.glob(f'{W}/{d}/*.jsonl'):
        per[d] += rj(f)
for d in ['audits', 'repossessions']:
    per[d] = []
    for f in glob.glob(f'{W}/{d}/*.jsonl'):
        per[d] += rj(f)
reg = {os.path.basename(f)[:-5]: json.load(open(f)) for f in glob.glob(f'{W}/register/*.json')}

def snaps(d):
    return {(r['dealer_id'], r['period']): r for r in per[d] if r['kind'] == 'snapshot'}
S = {d: snaps(d) for d in per}

F = {
 'aging': ['aged_share', 'days_supply', 'demand_index', 'incentive_intensity', 'model_year_age', 'price_volatility', 'franchise', 'segment'],
 'turns': ['demand_index', 'lot_velocity', 'marketing_spend_log', 'pricing_discipline', 'stock_age_mix', 'region', 'segment'],
 'reconciliations': ['audit_stage', 'location_count', 'prior_findings', 'reconciliation_lag', 'staff_turnover', 'unit_count_log'],
 'lines': ['curtailment_backlog', 'inventory_days', 'oem_incentive_phase', 'payoff_lag', 'sales_momentum', 'franchise', 'region'],
 'audits': ['audit_variance_rate', 'cash_strain', 'curtailment_misses', 'days_since_audit', 'insurance_lapses', 'late_payoff_count', 'franchise'],
 'repossessions': ['collateral_coverage', 'curtailment_compliance', 'dealer_cash_score', 'market_stress', 'rating_band', 'segment', 'years_in_program'],
}
def X(rows, d): return np.array([[float(r[k]) for k in F[d]] for r in rows])
def closed(d, q): return [v for v in (view(r, q) for r in per[d] if r['kind'] == 'closed') if v]

def gbr(): return GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0)

def predict_period(q, dealers):
    out = {d: {'record_id': f'{d}:p{q}'} for d in dealers}
    # aging
    c = closed('aging', q); m = gbr().fit(X(c, 'aging'), [r['haircut_ratio'] for r in c])
    s = [S['aging'][(d, q)] for d in dealers]; h = m.predict(X(s, 'aging'))
    for d, r, hh in zip(dealers, s, h):
        out[d]['aging_reserve'] = round(max(0.0, r['floored_balance'] * r['aged_share'] * hh), 2)
    # turns: discrete hazard
    c = closed('turns', q); rows = []; ys = []
    for r in c:
        x = [float(r[k]) for k in F['turns']]
        last = r['sold_bucket'] if r['sold_bucket'] >= 0 else r['last_observed_bucket']
        for b in range(last + 1):
            if r['sold_bucket'] < 0 and b == last and last < 7:
                pass
            rows.append(x + [b]); ys.append(1 if b == r['sold_bucket'] else 0)
    m = GradientBoostingClassifier(n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0).fit(np.array(rows), ys)
    s = [S['turns'][(d, q)] for d in dealers]
    for d, r in zip(dealers, s):
        x = [float(r[k]) for k in F['turns']]
        hz = m.predict_proba(np.array([x + [b] for b in range(8)]))[:, 1]
        surv = 1.0; prof = []
        for b in range(8):
            prof.append(surv * hz[b]); surv *= 1 - hz[b]
        prof = [max(0.0, round(p, 8)) for p in prof]
        while sum(prof) > 1.0: prof = [round(p * 0.9999999, 8) for p in prof]
        out[d]['turn_profile'] = prof
    # sot
    c = closed('audits', q)
    m = GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0).fit(X(c, 'audits'), [r['sot_event'] for r in c])
    s = [S['audits'][(d, q)] for d in dealers]; p = m.predict_proba(X(s, 'audits'))[:, 1]
    for d, pp in zip(dealers, p): out[d]['_sotp'] = pp
    # variance
    c = closed('reconciliations', q); m = gbr().fit(X(c, 'reconciliations'), [r['variance_fraction'] for r in c])
    s = [S['reconciliations'][(d, q)] for d in dealers]; v = m.predict(X(s, 'reconciliations'))
    for d, vv in zip(dealers, v):
        out[d]['variance_tier'] = int(sum(vv > t for t in [0.02, 0.05, 0.1]))
    # lines
    c = closed('lines', q); m = gbr().fit(X(c, 'lines'), [r['available_fraction'] for r in c])
    s = [S['lines'][(d, q)] for d in dealers]; af = m.predict(X(s, 'lines'))
    hr = {d: r['credit_line'] * a - r['outstanding'] - r['pending_payoffs'] for d, r, a in zip(dealers, s, af)}
    vals = sorted(set(round(v, 2) for v in hr.values()), reverse=True)
    for d in dealers: out[d]['headroom_rank'] = vals.index(round(hr[d], 2)) + 1
    # loss
    c = closed('repossessions', q)
    m = gbr().fit(X(c, 'repossessions'), [r['loss_amount'] / r['exposure'] for r in c])
    s = [S['repossessions'][(d, q)] for d in dealers]; lr = m.predict(X(s, 'repossessions'))
    for d, r, l in zip(dealers, s, lr):
        out[d]['loss_reserve'] = round(max(0.0, r['exposure'] * l), 2)
    return out

def finalize(out, rate):
    ps = sorted(o['_sotp'] for o in out.values())
    k = int(round(rate * len(ps)))
    thr = ps[-k] if k > 0 else 2
    for o in out.values():
        o['sot_flag'] = int(o.pop('_sotp') >= thr)
    return out

KEYS = ['record_id', 'aging_reserve', 'turn_profile', 'sot_flag', 'variance_tier', 'headroom_rank', 'loss_reserve']

if __name__ == '__main__':
    hist = rj(f'{W}/history/surveillance.jsonl')
    rate = np.mean([h['sot_flag'] for h in hist])
    if len(sys.argv) > 1 and sys.argv[1] == 'eval':
        for q in [8, 10, 12]:
            H = {h['dealer_id']: h for h in hist if h['period'] == q}
            o = finalize(predict_period(q, sorted(H)), rate)
            for f in ['aging_reserve', 'loss_reserve']:
                a = np.array([o[d][f] for d in H]); b = np.array([H[d][f] for d in H])
                print(q, f, np.median(np.abs(a - b) / (b + 1)), np.corrcoef(a, b)[0, 1])
            for f in ['sot_flag', 'variance_tier', 'headroom_rank']:
                print(q, f, np.mean([o[d][f] == H[d][f] for d in H]), np.corrcoef([o[d][f] for d in H], [H[d][f] for d in H])[0, 1])
            print(q, 'turn L1', np.mean([np.abs(np.array(o[d]['turn_profile']) - H[d]['turn_profile']).sum() for d in H]))
        sys.exit()
    qs = rj(f'{W}/queries.jsonl'); res = {}
    for q in sorted(set(r['period'] for r in qs)):
        res.update({f'{d}:p{q}': v for d, v in finalize(predict_period(q, [r['dealer_id'] for r in qs if r['period'] == q]), rate).items()})
    with open(f'{W}/predictions.jsonl', 'w') as f:
        for r in qs:
            o = res[r['record_id']]; f.write(json.dumps({k: o[k] for k in KEYS}) + '\n')
