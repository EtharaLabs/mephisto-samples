"""Documentary credit examination records.

Approach
--------
The desk's record for period P behaves like a model fitted to the closed external
cases known at P (booked_period <= P, with the as-booked outcome where the
restatement came after P), applied to the beneficiary's period-P snapshot.  We
reproduce that per period, then calibrate a small mapping from model output to
the published figures on history/examination.jsonl (reference beneficiaries,
periods 8, 10, 12) and apply the same mapping to the query periods.

Per view the desk's training set differs: a rolling window, recency weights, or a
cap at period 13 (before the event-period-14 regime shift), set in WINDOW / DECAY /
CAP below.  The remaining module-level switches are experiment toggles read from
the environment; their defaults reproduce the filed predictions.
"""
import glob
import json
import os
import sys
import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import SplineTransformer, StandardScaler
from sklearn.linear_model import (GammaRegressor, LinearRegression, LogisticRegression, Ridge,
                                  PoissonRegressor, TweedieRegressor)

warnings.filterwarnings('ignore')
W = os.environ.get('DCE_ROOT', '/workspace')
VIEWS = ['presentation_documents', 'discrepancy_logs', 'refusal_notices',
         'amendment_histories', 'correspondent_banks', 'settlement_payments']
TENOR_CUTS = [45, 95, 160]
# experiment switches and post-calibration adjustments (defaults = filed configuration)
DISC_MULT = float(os.environ.get('DISC_MULT', 1.015))
DISC_MULT20 = float(os.environ.get('DISC_MULT20', DISC_MULT))
PEND_SHIFT = float(os.environ.get('PEND_SHIFT', 0.0))
RANK_REFINE = int(os.environ.get('RANK_REFINE', 1))
REF_ET = float(os.environ.get('REF_ET', 0))
RANK_GBK = int(os.environ.get('RANK_GBK', 0))
DISC_GLMK = int(os.environ.get('DISC_GLMK', 0))
DISC_GBK = int(os.environ.get('DISC_GBK', 1))
DISC_ETK = int(os.environ.get('DISC_ETK', 1))
TENOR_ET = float(os.environ.get('TENOR_ET', 0))
DISC_ET2 = int(os.environ.get('DISC_ET2', 0))
RANK_ET = int(os.environ.get('RANK_ET', 0))
CHG_ET = float(os.environ.get('CHG_ET', 0))
DISC_ET = int(os.environ.get('DISC_ET', 1))
CHG_RF = float(os.environ.get('CHG_RF', 0))
DISC_RF = int(os.environ.get('DISC_RF', 0))
RANK_ABS = int(os.environ.get('RANK_ABS', 0))
CHG_GB2 = float(os.environ.get('CHG_GB2', 0))
DISC_GB3 = int(os.environ.get('DISC_GB3', 1))
DISC_GB2 = int(os.environ.get('DISC_GB2', 1))
PROF_GB = int(os.environ.get('PROF_GB', 2))
DISC_GBBASE = int(os.environ.get('DISC_GBBASE', 0))
REF_STD = int(os.environ.get('REF_STD', 0))
RANK_XV = int(os.environ.get('RANK_XV', 0))
REF_ENS = float(os.environ.get('REF_ENS', 0))
TENOR_GBF = int(os.environ.get('TENOR_GBF', 0))
DISC_NOINT = int(os.environ.get('DISC_NOINT', 0))
PROF_SSE = float(os.environ.get('PROF_SSE', 0))
RANK_SCALE = float(os.environ.get('RANK_SCALE', 1))
RANK_NOFEAT = int(os.environ.get('RANK_NOFEAT', 0))
RANK_STD = int(os.environ.get('RANK_STD', 0))
RANK_SQ = int(os.environ.get('RANK_SQ', 0))
PROF_BLEND = float(os.environ.get('PROF_BLEND', 0))
REF_GB = float(os.environ.get('REF_GB', 0))
TENOR_GB = float(os.environ.get('TENOR_GB', 0))
CHG_GB = float(os.environ.get('CHG_GB', 1))
DISC_GB = float(os.environ.get('DISC_GB', 5))
RANK_MULTI = int(os.environ.get('RANK_MULTI', 3))
DISC_BLEND = float(os.environ.get('DISC_BLEND', 0))
PROF_SQ = int(os.environ.get('PROF_SQ', 0))
CHARGE_MULT = float(os.environ.get('CHARGE_MULT', 1.02))
CHARGE_MULT20 = float(os.environ.get('CHARGE_MULT20', CHARGE_MULT))
REFUSAL_STACK = int(os.environ.get('REFUSAL_STACK', 0))
TENOR_QUAD = int(os.environ.get('TENOR_QUAD', 0))
TIER_SHIFTS = json.loads(os.environ.get('TIER_SHIFTS', '[-1, 5, -4.5]'))
TENOR_SHIFT = float(os.environ.get('TENOR_SHIFT', 0.0))
REFUSAL_SHIFT = float(os.environ.get('REFUSAL_SHIFT', 0.0))
REFUSAL_SHIFT20 = float(os.environ.get('REFUSAL_SHIFT20', REFUSAL_SHIFT))


def log(*a):
    print(*a, file=sys.stderr)


def load():
    reg = pd.DataFrame([json.load(open(f)) for f in glob.glob(W + '/credit_register/*.json')])
    reg = reg.set_index('beneficiary_id')
    snap, closed = {}, {}
    for v in VIEWS:
        S, C = [], []
        for f in glob.glob(f'{W}/{v}/*.jsonl'):
            for line in open(f):
                r = json.loads(line)
                (S if r['kind'] == 'snapshot' else C).append(r)
        snap[v] = pd.DataFrame(S).drop_duplicates(['beneficiary_id', 'period'], keep='last')
        closed[v] = pd.DataFrame(C).drop_duplicates('case_id', keep='last')
    hist = pd.DataFrame([json.loads(l) for l in open(W + '/history/examination.jsonl')])
    q = pd.DataFrame([json.loads(l) for l in open(W + '/queries.jsonl')]).drop_duplicates('record_id')
    return reg, snap, closed, hist, q


# rolling booking window and latest training period per view
WINDOW = json.loads(os.environ.get('WINDOW', '{"discrepancy_logs": 7}'))
DECAY = json.loads(os.environ.get('DECAY', '{"presentation_documents": 14, "refusal_notices": 30, "correspondent_banks": 4}'))
KNOWN = json.loads(os.environ.get('KNOWN', '{}'))
CAP = json.loads(os.environ.get('CAP', '{"amendment_histories": 13, "settlement_payments": 14}'))


def asof(c, P, target, known=True, window=99, cap=99):
    """Closed cases as the desk knew them at period P, over its rolling booking window."""
    P = min(P, cap)
    d = c[(c.booked_period <= P) & (c.booked_period > P - window)].copy()
    if known and 'restated_period' in d:
        late = d.restated_period.notna() & (d.restated_period > P)
        if late.any():
            d.loc[late, target] = d.loc[late, 'as_booked'].apply(lambda a: a[target]).values
    return d


def design(d, feats, g, extra=None):
    X = d[feats].astype(float).copy()
    for k in range(1, 4):
        X[f'g{k}'] = (d[g] == k).astype(float)
    if extra:
        extra(X, d)
    return X


class View:
    """Per-period model on one data view, with snapshots for history and queries."""

    def __init__(self, ctx, v, g, target, feats, extra=None, known=True):
        reg, snap, closed, hist, q = ctx
        self.c, self.g, self.t, self.F, self.ex, self.known = closed[v], g, target, feats, extra, known
        self.window, self.cap = WINDOW.get(v, 99), CAP.get(v, 99)
        self.known = bool(KNOWN.get(v, known))
        self.decay = DECAY.get(v)
        self.hs = self._snap(reg, snap[v], hist)
        self.qs = self._snap(reg, snap[v], q)

    def _snap(self, reg, s, rows):
        s = rows[['beneficiary_id', 'period']].merge(s, on=['beneficiary_id', 'period'], how='left')
        s[self.g] = reg.loc[s.beneficiary_id, self.g].values
        return s

    def X(self, d):
        return design(d, self.F, self.g, self.ex)

    def run(self, fit, predict):
        """fit(X, y, w) -> model; predict(model, X) -> array. Returns (hist_pred, query_pred).

        w are recency weights exp(-(P - booked_period) / decay) when the view has a decay."""
        out = []
        for s in (self.hs, self.qs):
            pred = None
            for P in sorted(s.period.unique()):
                d = asof(self.c, P, self.t, self.known, self.window, self.cap)
                w = np.exp(-(P - d.booked_period.values) / self.decay) if self.decay else None
                m = fit(self.X(d), d[self.t], w)
                idx = (s.period == P).values
                p = predict(m, self.X(s[idx]))
                if pred is None:
                    pred = np.zeros((len(s),) + p.shape[1:])
                pred[idx] = p
            out.append(pred)
        return out


class PerGroup:
    """One model per group code (columns g1..g3 of the design)."""

    def __init__(self, feats, make):
        self.F, self.make = feats, make

    def fit(self, X, y):
        g = (X.g1 + 2 * X.g2 + 3 * X.g3).values
        y = np.asarray(y)
        self.m = {k: self.make().fit(X[self.F][g == k], y[g == k]) for k in range(4)}
        return self

    def predict(self, X):
        g = (X.g1 + 2 * X.g2 + 3 * X.g3).values
        out = np.zeros(len(X))
        for k in range(4):
            if (g == k).any():
                out[g == k] = self.m[k].predict(X[self.F][g == k])
        return out


def two_dec(x):
    return float(np.round(max(float(x), 0.0) + 1e-12, 2))


def main(out=W + '/predictions.jsonl'):
    ctx = load()
    reg, snap, closed, hist, q = ctx
    res = {}

    # ---- discrepancy count: gamma GLM on the as-of cases, then a desk-specific
    # spline/route correction calibrated on history
    ex = lambda X, d: X.__setitem__('logdoc', np.log(d.document_count.clip(lower=1e-6)))
    V = View(ctx, 'presentation_documents', 'document_route', 'observed_discrepancies',
             ['data_conflict_share', 'document_count', 'expiry_margin_days',
              'missing_original_share', 'presentation_lag_days'], ex, known=False)
    ph, pq = V.run(lambda X, y, w: GammaRegressor(alpha=0, max_iter=5000).fit(X, y, sample_weight=w),
                   lambda m, X: np.log(m.predict(X)))
    if DISC_BLEND:
        rh, rq = V.run(lambda X, y, w: PerGroup(V.F, lambda: make_pipeline(
            StandardScaler(), GammaRegressor(alpha=1e-4, max_iter=10000))).fit(X, y),
                       lambda m, X: np.log(m.predict(X)))
        ph, pq = (1 - DISC_BLEND) * ph + DISC_BLEND * rh, (1 - DISC_BLEND) * pq + DISC_BLEND * rq
    y = np.log(hist.discrepancy_count.values)
    b = LinearRegression().fit(ph[:, None], y).coef_[0]
    # desk-specific correction on top of the scaled as-of model: splines + route-specific slopes
    F = V.F
    splines = [SplineTransformer(n_knots=int(os.environ.get('DISC_KNOTS', 6)), degree=3, extrapolation='linear').fit(V.hs[[f]]) for f in F]

    def corr_feats(s):
        G = np.c_[[(s.document_route == k).astype(float) for k in range(1, 4)]].T
        S = np.hstack([sp.transform(s[[f]]) for sp, f in zip(splines, F)])
        if DISC_NOINT:
            return np.c_[S, G]
        return np.c_[S, G, np.hstack([s[F].values * G[:, [j]] for j in range(3)])]

    Ch, Cq = corr_feats(V.hs), corr_feats(V.qs)
    if DISC_GB:
        if os.environ.get('DGB_DECAY'):
            V.decay = float(os.environ['DGB_DECAY'])
        gh, gq = V.run(lambda X, y, w: HistGradientBoostingRegressor(
            loss='poisson', max_iter=int(os.environ.get('DGB_IT', 250)), learning_rate=0.03, max_depth=(int(os.environ.get('DGB_D', 8)) or None), min_samples_leaf=int(os.environ.get('DGB_LEAF', 20)), random_state=0).fit(X, y, sample_weight=(w if int(os.environ.get('DGB_W', 1)) else None)),
                       lambda m, X: np.log(m.predict(X)))
        Ch, Cq = np.c_[Ch, (gh - ph) * DISC_GB], np.c_[Cq, (gq - pq) * DISC_GB]
        if DISC_GB2:
            g2h, g2q = V.run(lambda X, y, w: HistGradientBoostingRegressor(
                max_iter=int(os.environ.get('DGB2_IT', 250)), learning_rate=0.03, max_depth=(int(os.environ.get('DGB2_D', 0)) or None), min_samples_leaf=int(os.environ.get('DGB2_LEAF', 50)), random_state=0).fit(X, np.log(y), sample_weight=(w if int(os.environ.get('DGB2_W', 1)) else None)),
                             lambda m, X: m.predict(X))
            Ch, Cq = np.c_[Ch, (g2h - ph) * DISC_GB], np.c_[Cq, (g2q - pq) * DISC_GB]
        if DISC_GB3:
            g3h, g3q = V.run(lambda X, y, w: HistGradientBoostingRegressor(
                loss='gamma', max_iter=250, learning_rate=0.03, max_depth=(int(os.environ.get('DGB3_D', 8)) or None), random_state=0).fit(X, y, sample_weight=w),
                             lambda m, X: np.log(m.predict(X)))
            Ch, Cq = np.c_[Ch, (g3h - ph) * DISC_GB], np.c_[Cq, (g3q - pq) * DISC_GB]
        if DISC_RF:
            from sklearn.ensemble import RandomForestRegressor
            g4h, g4q = V.run(lambda X, y, w: RandomForestRegressor(300, min_samples_leaf=int(os.environ.get('DRF_LEAF', 5)), max_features=float(os.environ.get('DRF_MF', 0.5)), n_jobs=-1, random_state=0).fit(
                X, np.log(y), sample_weight=w), lambda m, X: m.predict(X))
            Ch, Cq = np.c_[Ch, (g4h - ph) * DISC_GB], np.c_[Cq, (g4q - pq) * DISC_GB]
        if DISC_ET:
            from sklearn.ensemble import ExtraTreesRegressor
            g6h, g6q = V.run(lambda X, y, w: ExtraTreesRegressor(int(os.environ.get('DET_N', 300)), min_samples_leaf=int(os.environ.get('DET_LEAF', 5)), max_features=float(os.environ.get('DET_MF', 0.5)), n_jobs=-1,
                                                                 random_state=int(os.environ.get('DET_SEED', 0))).fit(X, np.log(y), sample_weight=(w if int(os.environ.get('DET_W', 1)) else None)),
                             lambda m, X: m.predict(X))
            Ch, Cq = np.c_[Ch, (g6h - ph) * DISC_GB], np.c_[Cq, (g6q - pq) * DISC_GB]
        if DISC_ET2:
            from sklearn.ensemble import ExtraTreesRegressor
            g8h, g8q = V.run(lambda X, y, w: ExtraTreesRegressor(300, min_samples_leaf=5, max_features=0.5, n_jobs=-1,
                                                                 random_state=1).fit(X, y, sample_weight=w),
                             lambda m, X: np.log(np.clip(m.predict(X), 0.05, None)))
            Ch, Cq = np.c_[Ch, (g8h - ph) * DISC_GB], np.c_[Cq, (g8q - pq) * DISC_GB]
        if DISC_ETK:
            from sklearn.ensemble import ExtraTreesRegressor
            V.known = True
            g9h, g9q = V.run(lambda X, y, w: ExtraTreesRegressor(300, min_samples_leaf=5, max_features=0.5, n_jobs=-1,
                                                                 random_state=0).fit(X, np.log(y), sample_weight=w),
                             lambda m, X: m.predict(X))
            if DISC_ETK > 1:
                g9bh, g9bq = V.run(lambda X, y, w: ExtraTreesRegressor(
                    300, min_samples_leaf=5, max_features=0.5, n_jobs=-1, random_state=1).fit(
                    X, np.log(y), sample_weight=w), lambda m, X: m.predict(X))
                g9h, g9q = (g9h + g9bh) / 2, (g9q + g9bq) / 2
            V.known = False
            Ch, Cq = np.c_[Ch, (g9h - ph) * DISC_GB], np.c_[Cq, (g9q - pq) * DISC_GB]
        if DISC_GBK:
            V.known = True
            gkh, gkq = V.run(lambda X, y, w: HistGradientBoostingRegressor(
                max_iter=250, learning_rate=0.03, max_depth=None, min_samples_leaf=50, random_state=0).fit(
                X, np.log(y), sample_weight=w), lambda m, X: m.predict(X))
            V.known = False
            Ch, Cq = np.c_[Ch, (gkh - ph) * DISC_GB], np.c_[Cq, (gkq - pq) * DISC_GB]
        if DISC_GLMK:
            V.known = True
            gmh, gmq = V.run(lambda X, y, w: GammaRegressor(alpha=0, max_iter=5000).fit(X, y, sample_weight=w),
                             lambda m, X: np.log(m.predict(X)))
            V.known = False
            Ch, Cq = np.c_[Ch, (gmh - ph) * DISC_GB], np.c_[Cq, (gmq - pq) * DISC_GB]
        if DISC_GBBASE:
            b = LinearRegression().fit(gh[:, None], y).coef_[0]
            Ch, Cq = np.c_[Ch[:, :-1], (ph - gh) * DISC_GB], np.c_[Cq[:, :-1], (pq - gq) * DISC_GB]
            ph, pq = gh, gq
    m = Ridge(alpha=float(os.environ.get('DISC_ALPHA', 6.0))).fit(Ch, y - b * ph, sample_weight=np.exp(y * float(os.environ.get('DISC_WPOW', 0))))
    hd = np.exp(m.predict(Ch) + b * ph)
    log('disc b', b, 'hist MAE (in-sample)', np.abs(hd - hist.discrepancy_count).mean())
    res['discrepancy_count'] = np.exp(m.predict(Cq) + b * pq) * np.where(
        V.qs.period.values >= 20, DISC_MULT20, DISC_MULT)

    # ---- class profile: multinomial on class counts, temperature + bias calibrated on history
    V = View(ctx, 'discrepancy_logs', 'trade_corridor', 'class_counts',
             ['inconsistency_share', 'insurance_gap', 'late_share', 'missing_share',
              'transport_complexity'], known=True)

    def fit_mn(X, y, w):
        cc = np.array(y.tolist(), dtype=float)
        if w is not None:
            cc = cc * w[:, None]
        ii, kk = np.nonzero(cc > 0)
        return LogisticRegression(C=1.0, max_iter=20000).fit(X.values[ii], kk, sample_weight=cc[ii, kk])

    Lh, Lq = V.run(fit_mn, lambda m, X: m.predict_log_proba(X.values))
    if PROF_BLEND:
        V.window = 99
        L2h, L2q = V.run(fit_mn, lambda m, X: m.predict_log_proba(X.values))
        Lh, Lq = (1 - PROF_BLEND) * Lh + PROF_BLEND * L2h, (1 - PROF_BLEND) * Lq + PROF_BLEND * L2q
    H = np.array(hist.discrepancy_class_profile.tolist())
    Hf = np.c_[H, np.clip(1 - H.sum(1), 0, 1)]

    # softmax on history: temperature-scaled as-of logits plus a ridge-penalised linear correction
    Xh, Xq = V.X(V.hs).values, V.X(V.qs).values
    if PROF_SQ:
        Xh = np.c_[Xh, V.hs[V.F].values ** 2]
        Xq = np.c_[Xq, V.qs[V.F].values ** 2]
    if PROF_GB:
        class GBShares:
            def fit(self, X, y, w):
                cc = np.array(y.tolist(), dtype=float)
                tot = cc.sum(1)
                ok = tot > 0
                if PROF_GB == 2:
                    from sklearn.ensemble import ExtraTreesRegressor
                    mk = lambda: ExtraTreesRegressor(200, min_samples_leaf=10, max_features=0.5, n_jobs=-1, random_state=0)
                else:
                    mk = lambda: HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_depth=3,
                                                               random_state=0)
                self.m = [mk().fit(X[ok], cc[ok, k] / tot[ok], sample_weight=tot[ok]) for k in range(9)]
                return self

            def predict(self, X):
                P = np.clip(np.c_[[m.predict(X) for m in self.m]].T, 1e-3, None)
                return np.log(P / P.sum(1, keepdims=True))

        gh, gq = V.run(lambda X, y, w: GBShares().fit(X, y, w), lambda m, X: m.predict(X))
        Xh, Xq = np.c_[Xh, gh], np.c_[Xq, gq]
    mu, sd = Xh.mean(0), Xh.std(0)
    Xh, Xq = (Xh - mu) / sd, (Xq - mu) / sd
    K, d = 9, Xh.shape[1]

    def soft(L, X, th):
        z = L * th[0] + np.c_[X @ th[K:].reshape(d, K - 1) + th[1:K], np.zeros(len(X))]
        z -= z.max(1, keepdims=True)
        e = np.exp(z)
        return e / e.sum(1, keepdims=True)

    def obj(th):
        P = soft(Lh, Xh, th)
        loss = -(Hf * np.log(P + 1e-300)).sum()
        if PROF_SSE:
            loss = loss + PROF_SSE * ((P[:, :8] - H) ** 2).sum()
        return loss + float(os.environ.get('PROF_LAM', 0.3)) * (th[K:] ** 2).sum()
    th = minimize(obj, np.r_[0.5, np.zeros(K - 1 + d * (K - 1))], method='L-BFGS-B').x
    log('profile temp', th[0], 'hist MAE (in-sample)', np.abs(soft(Lh, Xh, th)[:, :8] - H).mean())
    Pq = soft(Lq, Xq, th)
    if PEND_SHIFT:
        z = np.log(Pq + 1e-300)
        z[:, 8] += PEND_SHIFT
        Pq = np.exp(z - z.max(1, keepdims=True))
        Pq /= Pq.sum(1, keepdims=True)
    res['profile'] = Pq

    # ---- refusal: logistic on closed (as-booked outcomes, recency-weighted)
    def REF_EXTRA(X, d):
        if os.environ.get('REF_INT'):
            X['mxt'] = d.material_conflict_share * d.notice_time_left
            X['mxw'] = d.material_conflict_share * d.waiver_reliability
        if os.environ.get('REF_SQ'):
            for f in ['applicant_response_days', 'material_conflict_share', 'notice_time_left',
                      'unwaived_items', 'waiver_reliability']:
                X[f + '2'] = d[f] ** 2

    V = View(ctx, 'refusal_notices', 'credit_form', 'notice_refused',
             ['applicant_response_days', 'material_conflict_share', 'notice_time_left',
              'unwaived_items', 'waiver_reliability'], REF_EXTRA, known=True)
    ref_model = lambda: (make_pipeline(StandardScaler(), LogisticRegression(C=float(os.environ.get('REF_C', 0.2)),
                                                                           max_iter=10000))
                         if REF_STD else LogisticRegression(C=float(os.environ.get('REF_C', 0.2)), max_iter=10000))
    zh, zq = V.run(lambda X, y, w: ref_model().fit(
        X, y, **({'logisticregression__sample_weight': w} if REF_STD else {'sample_weight': w})),
                   lambda m, X: m.decision_function(X))
    if REF_ENS:
        z2h, z2q = V.run(lambda X, y, w: LogisticRegression(C=REF_ENS, max_iter=10000).fit(X, y, sample_weight=w),
                         lambda m, X: m.decision_function(X))
        zh, zq = (zh + z2h) / 2, (zq + z2q) / 2
    if REF_ET:
        from sklearn.ensemble import ExtraTreesClassifier
        def et_z(m, X):
            p = np.clip(m.predict_proba(X)[:, 1], 0.01, 0.99)
            return np.log(p / (1 - p))
        eh, eq = V.run(lambda X, y, w: ExtraTreesClassifier(300, min_samples_leaf=10, max_features=0.5, n_jobs=-1,
                                                            random_state=0).fit(X, y, sample_weight=w), et_z)
        zh, zq = (1 - REF_ET) * zh + REF_ET * eh, (1 - REF_ET) * zq + REF_ET * eq
    if REF_GB:
        gh, gq = V.run(lambda X, y, w: HistGradientBoostingClassifier(
            max_iter=200, learning_rate=0.03, max_depth=2, random_state=0).fit(X, y, sample_weight=w),
                       lambda m, X: m.decision_function(X))
        zh, zq = (1 - REF_GB) * zh + REF_GB * gh, (1 - REF_GB) * zq + REF_GB * gq
    log('refusal raw hist acc', ((zh > 0) == hist.refusal_flag).mean())
    if REFUSAL_STACK:
        # logistic on the desk's own flags, with the as-of score as an input so period drift carries over
        Xh, Xq = V.X(V.hs).values, V.X(V.qs).values
        mu, sd = Xh.mean(0), Xh.std(0)
        m = LogisticRegression(C=10, max_iter=5000).fit(np.c_[zh, (Xh - mu) / sd], hist.refusal_flag)
        zq = m.decision_function(np.c_[zq, (Xq - mu) / sd])
    res['refusal_flag'] = (zq + np.where(V.qs.period.values >= 20, REFUSAL_SHIFT20, REFUSAL_SHIFT) > 0).astype(int)

    # ---- tenor tier: settled-tenor model, desk mapping a + b*p fitted interval-censored on history.
    # Tenor runs from the draft/acceptance basis, so the acceptance delay is excluded from the estimate.
    # Maturity extension only applies to the deferred share; draft slope differs by tenor basis.
    sp_am = SplineTransformer(n_knots=int(os.environ.get('AM_KNOTS', 8)), degree=3).fit(np.linspace(0, 7, 50)[:, None])

    def ex(X, d):
        for k in range(1, 4):
            X[f'dr{k}'] = X[f'g{k}'] * d.draft_tenor_days
        X['dxe'] = d.deferred_share * d.maturity_extension_days
        S = sp_am.transform(d[['amendment_count']].clip(0, 7))
        for j in range(S.shape[1]):
            X[f'am{j}'] = S[:, j]

    V = View(ctx, 'amendment_histories', 'tenor_basis', 'settled_tenor_days',
             ['acceptance_delay_days', 'amendment_count', 'deferred_share', 'draft_tenor_days',
              'maturity_extension_days'], ex, known=False)

    def no_acc(m, X):
        X = X.copy()
        X['acceptance_delay_days'] = 0.0
        return m.predict(X)

    ph, pq = V.run(lambda X, y, w: LinearRegression().fit(X, y, sample_weight=w), lambda m, X: m.predict(X))
    if TENOR_GB or TENOR_GBF:
        gh, gq = V.run(lambda X, y, w: HistGradientBoostingRegressor(
            max_iter=600, learning_rate=0.03, max_depth=3, random_state=0).fit(X, y), lambda m, X: m.predict(X))
    if TENOR_ET:
        from sklearn.ensemble import ExtraTreesRegressor
        eh, eq = V.run(lambda X, y, w: ExtraTreesRegressor(300, min_samples_leaf=5, max_features=0.5, n_jobs=-1,
                                                           random_state=0).fit(X, y), lambda m, X: m.predict(X))
        ph, pq = (1 - TENOR_ET) * ph + TENOR_ET * eh, (1 - TENOR_ET) * pq + TENOR_ET * eq
    if TENOR_GB:
        ph, pq = (1 - TENOR_GB) * ph + TENOR_GB * gh, (1 - TENOR_GB) * pq + TENOR_GB * gq
    y = hist.tenor_tier.values
    lo = np.array([-1e9] + TENOR_CUTS)[y]
    hi = np.array(TENOR_CUTS + [1e9])[y]

    # desk tenor = a + b*p (+ c*(p - 100)^2 / 100 when TENOR_QUAD is on)
    desk = lambda t, p: t[0] + t[1] * p + t[2] * (p - 100) ** 2 / 100

    def nll(t):
        mu = desk(t, ph)
        s = np.exp(t[3])
        return -np.log(np.clip(norm.cdf((hi - mu) / s) - norm.cdf((lo - mu) / s), 1e-12, 1)).sum()

    t = min((minimize(nll, t0, method='L-BFGS-B') for t0 in
             ([30.0, 0.7, 0.0, np.log(10)], [35.0, 0.7, 0.1, np.log(10)], [40.0, 0.6, 0.0, np.log(15)])),
            key=lambda r: r.fun).x
    if TENOR_GBF:
        dh, dq = gh - ph, gq - pq

        def nll2(u):
            mu = u[0] + u[1] * ph + u[2] * dh
            sg = np.exp(u[3])
            return -np.log(np.clip(norm.cdf((hi - mu) / sg) - norm.cdf((lo - mu) / sg), 1e-12, 1)).sum()

        u = minimize(nll2, [34.8, 0.7, 0.0, np.log(10)], method='Nelder-Mead', options={'maxiter': 20000}).x
        log('tenor gbf map', u)
        ph, pq = ph + u[2] / u[1] * dh, pq + u[2] / u[1] * dq
    if not TENOR_QUAD:
        t = min((minimize(lambda u: nll(np.r_[u[:2], 0.0, u[2]]), t0, method='Nelder-Mead',
                          options={'maxiter': 20000}) for t0 in ([30.0, 0.7, np.log(10)], [40.0, 0.6, np.log(15)])),
                key=lambda r: r.fun).x
        t = np.r_[t[:2], 0.0, t[2]]
    tier = lambda x: np.digitize(x, TENOR_CUTS, right=True)
    log('tenor map', t, 'hist acc', (tier(desk(t, ph)) == y).mean(), 'raw acc', (tier(ph) == y).mean())
    est = desk(t, pq) + TENOR_SHIFT
    cuts = np.array(TENOR_CUTS, float) + np.array(TIER_SHIFTS)
    res['tenor_tier'] = np.digitize(est, cuts, right=True)

    # ---- priority: handling urgency model, dense rank within period cohort
    # urgency peaks at a cycle phase that shifts with the service band; corridor delay
    # interacts with document complexity
    def ex(X, d):
        band = d.service_band.values
        for b in range(4):
            m = (band == b).astype(float)
            X[f's{b}'] = m * np.sin(2 * np.pi * d.cycle_phase)
            X[f'c{b}'] = m * np.cos(2 * np.pi * d.cycle_phase)
        for f in ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 'document_complexity']:
            X[f + '2'] = d[f] ** 2
        X['cxd'] = d.corridor_delay_days * d.document_complexity
        X.drop(columns='cycle_phase', inplace=True)

    V = View(ctx, 'correspondent_banks', 'service_band', 'handling_urgency',
             ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 'cycle_phase',
              'document_complexity'], ex, known=False)
    uh, uq = V.run(lambda X, y, w: LinearRegression().fit(X, y, sample_weight=w), lambda m, X: m.predict(X))
    # refine on the desk's own orderings: normal scores of history ranks on the same features
    z = np.zeros(len(hist))
    for P in hist.period.unique():
        i = (hist.period == P).values
        u = (hist.examiner_priority_rank.values[i] - 0.5) / i.sum()
        z[i] = (0.5 - u) * 3.4 if int(os.environ.get('RANK_LIN', 1)) else -norm.ppf(u)
    Zh, Zq = V.X(V.hs).values, V.X(V.qs).values
    if RANK_XV:
        pd_cols = ['presentation_lag_days', 'expiry_margin_days', 'document_count']
        xs = [rows[['beneficiary_id', 'period']].merge(snap['presentation_documents'], on=['beneficiary_id', 'period'],
                                                       how='left')[pd_cols].values for rows in (hist, q)]
        Zh, Zq = np.c_[Zh, xs[0]], np.c_[Zq, xs[1]]
    if RANK_NOFEAT:
        Zh, Zq = Zh[:, :0], Zq[:, :0]
    if RANK_STD:
        zm, zs = Zh.mean(0), Zh.std(0) + 1e-12
        Zh, Zq = (Zh - zm) / zs, (Zq - zm) / zs
    sh, sq = uh / uh.std(), uq / uh.std()
    if RANK_MULTI:
        V.decay = None
        u2h, u2q = V.run(lambda X, y, w: LinearRegression().fit(X, y), lambda m, X: m.predict(X))
        sh, sq = np.c_[sh, u2h / u2h.std()], np.c_[sq, u2q / u2h.std()]
        if RANK_MULTI > 1:
            cols = ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 's0', 'c0', 's1', 'c1',
                    's2', 'c2', 's3', 'c3', 'document_complexity', 'g1', 'g2', 'g3']
            gb = lambda X, y, w: HistGradientBoostingRegressor(max_iter=int(os.environ.get('GB_IT', 600)), learning_rate=0.03, max_depth=int(os.environ.get('GB_D', 3)),
                                                               random_state=0).fit(X[cols], y, sample_weight=w)
            V.decay = float(os.environ['GB_DECAY']) if os.environ.get('GB_DECAY') else None
            u3h, u3q = V.run(gb, lambda m, X: m.predict(X[cols]))
            sh, sq = np.c_[sh, u3h / u3h.std()], np.c_[sq, u3q / u3h.std()]
        if RANK_MULTI > 2:
            raw = ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 'document_complexity',
                   's0', 'c0', 's1', 'c1', 's2', 'c2', 's3', 'c3']

            def gb2(X, y, w):
                Z = X[raw].copy()
                Z['band'] = X.g1 + 2 * X.g2 + 3 * X.g3
                Z['sin'] = X.s0 + X.s1 + X.s2 + X.s3
                Z['cos'] = X.c0 + X.c1 + X.c2 + X.c3
                return HistGradientBoostingRegressor(max_iter=int(os.environ.get('GB2_IT', 800)), learning_rate=0.03, max_depth=int(os.environ.get('GB2_D', 5)),
                                                     random_state=1).fit(Z[['bank_queue_hours', 'corridor_delay_days',
                                                     'cutoff_margin_hours', 'document_complexity', 'band', 'sin', 'cos']], y)

            def pr2(m, X):
                Z = X[raw].copy()
                Z['band'] = X.g1 + 2 * X.g2 + 3 * X.g3
                Z['sin'] = X.s0 + X.s1 + X.s2 + X.s3
                Z['cos'] = X.c0 + X.c1 + X.c2 + X.c3
                return m.predict(Z[['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours',
                                    'document_complexity', 'band', 'sin', 'cos']])

            u4h, u4q = V.run(gb2, pr2)
            sh, sq = np.c_[sh, u4h / u4h.std()], np.c_[sq, u4q / u4h.std()]
        if RANK_GBK:
            V.known, V.decay = True, None
            ukh, ukq = V.run(gb, lambda m, X: m.predict(X[cols]))
            V.known = False
            sh, sq = np.c_[sh, ukh / ukh.std()], np.c_[sq, ukq / ukh.std()]
        if RANK_ET:
            from sklearn.ensemble import ExtraTreesRegressor
            et = lambda X, y, w: ExtraTreesRegressor(300, min_samples_leaf=5, max_features=0.5, n_jobs=-1,
                                                     random_state=0).fit(X[cols], y)
            u7h, u7q = V.run(et, lambda m, X: m.predict(X[cols]))
            sh, sq = np.c_[sh, u7h / u7h.std()], np.c_[sq, u7q / u7h.std()]
        if RANK_ABS:
            ga = lambda X, y, w: HistGradientBoostingRegressor(loss='absolute_error', max_iter=600, learning_rate=0.05,
                                                               max_depth=4, random_state=0).fit(X[cols], y)
            u6h, u6q = V.run(ga, lambda m, X: m.predict(X[cols]))
            sh, sq = np.c_[sh, u6h / u6h.std()], np.c_[sq, u6q / u6h.std()]
        if RANK_MULTI > 3:
            from sklearn.ensemble import RandomForestRegressor
            rf = lambda X, y, w: RandomForestRegressor(300, min_samples_leaf=5, n_jobs=-1, random_state=0).fit(X[cols], y)
            u5h, u5q = V.run(rf, lambda m, X: m.predict(X[cols]))
            sh, sq = np.c_[sh, u5h / u5h.std()], np.c_[sq, u5q / u5h.std()]
    sh, sq = sh * RANK_SCALE, sq * RANK_SCALE
    if RANK_SQ:
        sh, sq = np.c_[sh, sh ** 2 / 3], np.c_[sq, sq ** 2 / 3]
    m = Ridge(alpha=float(os.environ.get('RANK_ALPHA', 44.0))).fit(np.c_[Zh, sh], z)
    if RANK_REFINE:
        uh, uq = m.predict(np.c_[Zh, sh]), m.predict(np.c_[Zq, sq])
    rk = lambda u, per: pd.Series(np.round(u, 9)).groupby(per.values).rank(
        method='dense', ascending=False).astype(int).values
    rh = rk(uh, hist.period)
    log('rank hist spearman', pd.Series(rh).corr(hist.examiner_priority_rank, method='spearman'),
        'MAE', np.abs(rh - hist.examiner_priority_rank).mean())
    res['rank'] = rk(uq, q.period)

    # ---- charge reserve: Tweedie GLM (cap 13), plus a desk-specific correction fitted on history
    ex = lambda X, d: X.__setitem__('logface', np.log(d.face_amount_usd))
    V = View(ctx, 'settlement_payments', 'charge_schedule', 'charges_usd',
             ['claim_complexity', 'message_count', 'relationship_years', 'unpaid_fee_share'], ex, known=False)
    ph, pq = V.run(lambda X, y, w: TweedieRegressor(power=float(os.environ.get('CHG_POW', 1.9)), alpha=0, link='log', max_iter=20000).fit(X, y, sample_weight=w),
                   lambda m, X: np.log(m.predict(X)))
    y = np.log(hist.charge_reserve.values)
    b = LinearRegression().fit(ph[:, None], y).coef_[0]
    F = V.F
    splines = [SplineTransformer(n_knots=int(os.environ.get('CHG_KNOTS', 4)), degree=3, extrapolation='linear').fit(V.hs[[f]]) for f in F]

    def corr_feats(s):
        G = np.c_[[(s.charge_schedule == k).astype(float) for k in range(1, 4)]].T
        X = np.c_[s[F].values, np.log(s.face_amount_usd)]
        S = np.hstack([sp.transform(s[[f]]) for sp, f in zip(splines, F)])
        return np.c_[S, G, np.log(s.face_amount_usd), np.hstack([X * G[:, [j]] for j in range(3)])]

    Ch, Cq = corr_feats(V.hs), corr_feats(V.qs)
    if CHG_GB:
        gh, gq = V.run(lambda X, y, w: HistGradientBoostingRegressor(
            loss='poisson', max_iter=400, learning_rate=0.03, max_depth=(int(os.environ.get('CGB_D', 3)) or None), random_state=0).fit(X, y),
                       lambda m, X: np.log(m.predict(X)))
        Ch, Cq = np.c_[Ch, (gh - ph) * CHG_GB], np.c_[Cq, (gq - pq) * CHG_GB]
        if CHG_RF:
            from sklearn.ensemble import RandomForestRegressor
            g5h, g5q = V.run(lambda X, y, w: RandomForestRegressor(300, min_samples_leaf=5, n_jobs=-1, random_state=0).fit(
                X, np.log1p(y)), lambda m, X: m.predict(X))
            Ch, Cq = np.c_[Ch, (g5h - ph) * CHG_RF], np.c_[Cq, (g5q - pq) * CHG_RF]
        if CHG_ET:
            from sklearn.ensemble import ExtraTreesRegressor
            g7h, g7q = V.run(lambda X, y, w: ExtraTreesRegressor(300, min_samples_leaf=5, max_features=0.5, n_jobs=-1,
                                                                 random_state=0).fit(X, np.log1p(y)),
                             lambda m, X: m.predict(X))
            Ch, Cq = np.c_[Ch, (g7h - ph) * CHG_ET], np.c_[Cq, (g7q - pq) * CHG_ET]
        if CHG_GB2:
            g2h, g2q = V.run(lambda X, y, w: HistGradientBoostingRegressor(
                max_iter=300, learning_rate=0.03, max_depth=6, random_state=0).fit(X, np.log1p(y)),
                             lambda m, X: m.predict(X))
            Ch, Cq = np.c_[Ch, (g2h - ph) * CHG_GB2], np.c_[Cq, (g2q - pq) * CHG_GB2]
    m = Ridge(alpha=float(os.environ.get('CHG_ALPHA', 1.0))).fit(Ch, y - b * ph, sample_weight=np.exp(y * float(os.environ.get('CHG_WPOW', 0))))
    hc = np.exp(m.predict(Ch) + b * ph)
    log('charge b', b, 'hist MAE (in-sample)', np.abs(hc - hist.charge_reserve).mean())
    res['charge_reserve'] = np.exp(m.predict(Cq) + b * pq) * np.where(
        V.qs.period.values >= 20, CHARGE_MULT20, CHARGE_MULT)

    with open(out, 'w') as f:
        for i, r in enumerate(q.itertuples()):
            prof = [float(np.floor(x * 1e8) / 1e8) for x in res['profile'][i, :8]]
            rec = {
                'record_id': r.record_id,
                'discrepancy_count': two_dec(res['discrepancy_count'][i]),
                'discrepancy_class_profile': prof,
                'refusal_flag': int(res['refusal_flag'][i]),
                'tenor_tier': int(res['tenor_tier'][i]),
                'examiner_priority_rank': int(res['rank'][i]),
                'charge_reserve': two_dec(res['charge_reserve'][i]),
            }
            f.write(json.dumps(rec) + '\n')


if __name__ == '__main__':
    main()
