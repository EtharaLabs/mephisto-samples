"""Documentary credit examination records.

Approach
--------
The desk's record for period P behaves like a model fitted to the closed external
cases known at P (booked_period <= P, with the as-booked outcome where the
restatement came after P), applied to the beneficiary's period-P snapshot.  We
reproduce that per period, then calibrate a small mapping from model output to
the published figures on history/examination.jsonl (reference beneficiaries,
periods 8, 10, 12) and apply the same mapping to the query periods.
"""
import glob
import json
import os
import sys
import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import SplineTransformer
from sklearn.linear_model import (LinearRegression, LogisticRegression, Ridge,
                                  PoissonRegressor, TweedieRegressor)

warnings.filterwarnings('ignore')
W = os.environ.get('DCE_ROOT', '/workspace')
VIEWS = ['presentation_documents', 'discrepancy_logs', 'refusal_notices',
         'amendment_histories', 'correspondent_banks', 'settlement_payments']
TENOR_CUTS = [45, 95, 160]
# post-calibration multipliers for the query periods (tuned against desk feedback)
DISC_MULT = float(os.environ.get('DISC_MULT', 1.0))
CHARGE_MULT = float(os.environ.get('CHARGE_MULT', 1.0))


def log(*a):
    print(*a, file=sys.stderr)


def load():
    reg = pd.DataFrame([json.load(open(f)) for f in glob.glob(W + '/credit_register/*.json')])
    reg = reg.set_index('beneficiary_id')
    snap, closed = {}, {}
    for v in VIEWS:
        S, C = [], []
        for f in glob.glob(f'{W}/{v}/*.jsonl'):
            for line in open(f):
                r = json.loads(line)
                (S if r['kind'] == 'snapshot' else C).append(r)
        snap[v] = pd.DataFrame(S).drop_duplicates(['beneficiary_id', 'period'], keep='last')
        closed[v] = pd.DataFrame(C).drop_duplicates('case_id', keep='last')
    hist = pd.DataFrame([json.loads(l) for l in open(W + '/history/examination.jsonl')])
    q = pd.DataFrame([json.loads(l) for l in open(W + '/queries.jsonl')]).drop_duplicates('record_id')
    return reg, snap, closed, hist, q


# rolling booking window and latest training period per view
WINDOW = json.loads(os.environ.get('WINDOW', '{"presentation_documents": 12, "discrepancy_logs": 6}'))
CAP = json.loads(os.environ.get('CAP', '{"amendment_histories": 13}'))


def asof(c, P, target, known=True, window=99, cap=99):
    """Closed cases as the desk knew them at period P, over its rolling booking window."""
    P = min(P, cap)
    d = c[(c.booked_period <= P) & (c.booked_period > P - window)].copy()
    if known and 'restated_period' in d:
        late = d.restated_period.notna() & (d.restated_period > P)
        if late.any():
            d.loc[late, target] = d.loc[late, 'as_booked'].apply(lambda a: a[target]).values
    return d


def design(d, feats, g, extra=None):
    X = d[feats].astype(float).copy()
    for k in range(1, 4):
        X[f'g{k}'] = (d[g] == k).astype(float)
    if extra:
        extra(X, d)
    return X


class View:
    """Per-period model on one data view, with snapshots for history and queries."""

    def __init__(self, ctx, v, g, target, feats, extra=None, known=True):
        reg, snap, closed, hist, q = ctx
        self.c, self.g, self.t, self.F, self.ex, self.known = closed[v], g, target, feats, extra, known
        self.window, self.cap = WINDOW.get(v, 99), CAP.get(v, 99)
        self.hs = self._snap(reg, snap[v], hist)
        self.qs = self._snap(reg, snap[v], q)

    def _snap(self, reg, s, rows):
        s = rows[['beneficiary_id', 'period']].merge(s, on=['beneficiary_id', 'period'], how='left')
        s[self.g] = reg.loc[s.beneficiary_id, self.g].values
        return s

    def X(self, d):
        return design(d, self.F, self.g, self.ex)

    def run(self, fit, predict):
        """fit(X, y) -> model; predict(model, X) -> array. Returns (hist_pred, query_pred)."""
        out = []
        for s in (self.hs, self.qs):
            pred = None
            for P in sorted(s.period.unique()):
                d = asof(self.c, P, self.t, self.known, self.window, self.cap)
                m = fit(self.X(d), d[self.t])
                idx = (s.period == P).values
                p = predict(m, self.X(s[idx]))
                if pred is None:
                    pred = np.zeros((len(s),) + p.shape[1:])
                pred[idx] = p
            out.append(pred)
        return out


def two_dec(x):
    return float(np.round(max(float(x), 0.0) + 1e-12, 2))


def main(out=W + '/predictions.jsonl'):
    ctx = load()
    reg, snap, closed, hist, q = ctx
    res = {}

    # ---- discrepancy count: Poisson GLM, log-linear calibration on history
    ex = lambda X, d: X.__setitem__('logdoc', np.log(d.document_count.clip(lower=1e-6)))
    V = View(ctx, 'presentation_documents', 'document_route', 'observed_discrepancies',
             ['data_conflict_share', 'document_count', 'expiry_margin_days',
              'missing_original_share', 'presentation_lag_days'], ex, known=False)
    ph, pq = V.run(lambda X, y: PoissonRegressor(alpha=0, max_iter=5000).fit(X, y),
                   lambda m, X: np.log(m.predict(X)))
    y = np.log(hist.discrepancy_count.values)
    b = LinearRegression().fit(ph[:, None], y).coef_[0]
    # desk-specific correction on top of the scaled as-of model: splines + route-specific slopes
    F = V.F
    splines = [SplineTransformer(n_knots=6, degree=3, extrapolation='linear').fit(V.hs[[f]]) for f in F]

    def corr_feats(s):
        G = np.c_[[(s.document_route == k).astype(float) for k in range(1, 4)]].T
        S = np.hstack([sp.transform(s[[f]]) for sp, f in zip(splines, F)])
        return np.c_[S, G, np.hstack([s[F].values * G[:, [j]] for j in range(3)])]

    m = Ridge(alpha=1.0).fit(corr_feats(V.hs), y - b * ph)
    hd = np.exp(m.predict(corr_feats(V.hs)) + b * ph)
    log('disc b', b, 'hist MAE (in-sample)', np.abs(hd - hist.discrepancy_count).mean())
    res['discrepancy_count'] = np.exp(m.predict(corr_feats(V.qs)) + b * pq) * DISC_MULT

    # ---- class profile: multinomial on class counts, temperature + bias calibrated on history
    V = View(ctx, 'discrepancy_logs', 'trade_corridor', 'class_counts',
             ['inconsistency_share', 'insurance_gap', 'late_share', 'missing_share',
              'transport_complexity'], known=True)

    def fit_mn(X, y):
        cc = np.array(y.tolist(), dtype=float)
        ii, kk = np.nonzero(cc > 0)
        return LogisticRegression(C=1.0, max_iter=20000).fit(X.values[ii], kk, sample_weight=cc[ii, kk])

    Lh, Lq = V.run(fit_mn, lambda m, X: m.predict_log_proba(X.values))
    H = np.array(hist.discrepancy_class_profile.tolist())
    Hf = np.c_[H, np.clip(1 - H.sum(1), 0, 1)]

    # softmax on history: temperature-scaled as-of logits plus a ridge-penalised linear correction
    Xh, Xq = V.X(V.hs).values, V.X(V.qs).values
    mu, sd = Xh.mean(0), Xh.std(0)
    Xh, Xq = (Xh - mu) / sd, (Xq - mu) / sd
    K, d = 9, Xh.shape[1]

    def soft(L, X, th):
        z = L * th[0] + np.c_[X @ th[K:].reshape(d, K - 1) + th[1:K], np.zeros(len(X))]
        z -= z.max(1, keepdims=True)
        e = np.exp(z)
        return e / e.sum(1, keepdims=True)

    obj = lambda th: -(Hf * np.log(soft(Lh, Xh, th) + 1e-300)).sum() + 0.1 * (th[K:] ** 2).sum()
    th = minimize(obj, np.r_[0.5, np.zeros(K - 1 + d * (K - 1))], method='L-BFGS-B').x
    log('profile temp', th[0], 'hist MAE (in-sample)', np.abs(soft(Lh, Xh, th)[:, :8] - H).mean())
    res['profile'] = soft(Lq, Xq, th)

    # ---- refusal: logistic on closed, intercept/scale calibrated on history
    V = View(ctx, 'refusal_notices', 'credit_form', 'notice_refused',
             ['applicant_response_days', 'material_conflict_share', 'notice_time_left',
              'unwaived_items', 'waiver_reliability'], known=False)
    zh, zq = V.run(lambda X, y: LogisticRegression(C=100, max_iter=10000).fit(X, y),
                   lambda m, X: m.decision_function(X))
    log('refusal raw hist acc', ((zh > 0) == hist.refusal_flag).mean())
    res['refusal_flag'] = (zq > 0).astype(int)

    # ---- tenor tier: linear tenor model, desk mapping a + b*p fitted interval-censored on history
    V = View(ctx, 'amendment_histories', 'tenor_basis', 'settled_tenor_days',
             ['acceptance_delay_days', 'amendment_count', 'deferred_share', 'draft_tenor_days',
              'maturity_extension_days'], known=False)
    ph, pq = V.run(lambda X, y: LinearRegression().fit(X, y), lambda m, X: m.predict(X))
    y = hist.tenor_tier.values
    lo = np.array([-1e9] + TENOR_CUTS)[y]
    hi = np.array(TENOR_CUTS + [1e9])[y]

    def nll(t):
        mu = t[0] + t[1] * ph
        s = np.exp(t[2])
        return -np.log(np.clip(norm.cdf((hi - mu) / s) - norm.cdf((lo - mu) / s), 1e-12, 1)).sum()

    t = minimize(nll, [0.0, 1.0, np.log(10)], method='Nelder-Mead', options={'maxiter': 20000}).x
    tier = lambda x: np.digitize(x, TENOR_CUTS, right=True)
    log('tenor map', t, 'hist acc', (tier(t[0] + t[1] * ph) == y).mean(), 'raw acc', (tier(ph) == y).mean())
    res['tenor_tier'] = tier(t[0] + t[1] * pq)

    # ---- priority: handling urgency model, dense rank within period cohort
    # urgency peaks at a cycle phase that shifts with the service band; corridor delay
    # interacts with document complexity
    def ex(X, d):
        band = d.service_band.values
        for b in range(4):
            m = (band == b).astype(float)
            X[f's{b}'] = m * np.sin(2 * np.pi * d.cycle_phase)
            X[f'c{b}'] = m * np.cos(2 * np.pi * d.cycle_phase)
        for f in ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 'document_complexity']:
            X[f + '2'] = d[f] ** 2
        X['cxd'] = d.corridor_delay_days * d.document_complexity
        X.drop(columns='cycle_phase', inplace=True)

    V = View(ctx, 'correspondent_banks', 'service_band', 'handling_urgency',
             ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 'cycle_phase',
              'document_complexity'], ex, known=False)
    uh, uq = V.run(lambda X, y: LinearRegression().fit(X, y), lambda m, X: m.predict(X))
    # refine on the desk's own orderings: normal scores of history ranks on the same features
    z = np.zeros(len(hist))
    for P in hist.period.unique():
        i = (hist.period == P).values
        z[i] = -norm.ppf((hist.examiner_priority_rank.values[i] - 0.5) / i.sum())
    Zh, Zq = V.X(V.hs).values, V.X(V.qs).values
    sh, sq = uh / uh.std(), uq / uh.std()
    m = Ridge(alpha=10.0).fit(np.c_[Zh, sh], z)
    uh, uq = m.predict(np.c_[Zh, sh]), m.predict(np.c_[Zq, sq])
    rk = lambda u, per: pd.Series(np.round(u, 9)).groupby(per.values).rank(
        method='dense', ascending=False).astype(int).values
    rh = rk(uh, hist.period)
    log('rank hist spearman', pd.Series(rh).corr(hist.examiner_priority_rank, method='spearman'),
        'MAE', np.abs(rh - hist.examiner_priority_rank).mean())
    res['rank'] = rk(uq, q.period)

    # ---- charge reserve: Tweedie GLM, log-linear calibration on history
    ex = lambda X, d: X.__setitem__('logface', np.log(d.face_amount_usd))
    V = View(ctx, 'settlement_payments', 'charge_schedule', 'charges_usd',
             ['claim_complexity', 'message_count', 'relationship_years', 'unpaid_fee_share'], ex, known=False)
    ph, pq = V.run(lambda X, y: TweedieRegressor(power=1.5, alpha=0, link='log', max_iter=10000).fit(X, y),
                   lambda m, X: np.log(m.predict(X)))
    y = np.log(hist.charge_reserve.values)
    b = LinearRegression().fit(ph[:, None], y).coef_[0]
    F = V.F
    splines = [SplineTransformer(n_knots=6, degree=3, extrapolation='linear').fit(V.hs[[f]]) for f in F]

    def corr_feats(s):
        G = np.c_[[(s.charge_schedule == k).astype(float) for k in range(1, 4)]].T
        X = np.c_[s[F].values, np.log(s.face_amount_usd)]
        S = np.hstack([sp.transform(s[[f]]) for sp, f in zip(splines, F)])
        return np.c_[S, G, np.log(s.face_amount_usd), np.hstack([X * G[:, [j]] for j in range(3)])]

    m = Ridge(alpha=0.1).fit(corr_feats(V.hs), y - b * ph)
    hc = np.exp(m.predict(corr_feats(V.hs)) + b * ph)
    log('charge b', b, 'hist MAE (in-sample)', np.abs(hc - hist.charge_reserve).mean())
    res['charge_reserve'] = np.exp(m.predict(corr_feats(V.qs)) + b * pq) * CHARGE_MULT

    with open(out, 'w') as f:
        for i, r in enumerate(q.itertuples()):
            prof = [float(np.floor(x * 1e8) / 1e8) for x in res['profile'][i, :8]]
            rec = {
                'record_id': r.record_id,
                'discrepancy_count': two_dec(res['discrepancy_count'][i]),
                'discrepancy_class_profile': prof,
                'refusal_flag': int(res['refusal_flag'][i]),
                'tenor_tier': int(res['tenor_tier'][i]),
                'examiner_priority_rank': int(res['rank'][i]),
                'charge_reserve': two_dec(res['charge_reserve'][i]),
            }
            f.write(json.dumps(rec) + '\n')


if __name__ == '__main__':
    main()
