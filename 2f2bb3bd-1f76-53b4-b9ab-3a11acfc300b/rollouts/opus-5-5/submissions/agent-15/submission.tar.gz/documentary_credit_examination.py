"""Documentary credit examination records.

Approach: each data view's closed cases give (features, group code) -> outcome.
We fit a model per view on closed cases (corrected outcomes, with a regime flag
for event_period >= 14), apply it to the beneficiary snapshot of the query
period, then calibrate a small mapping from model output to the desk's published
figures using history/examination.jsonl (reference beneficiaries, periods 8-12).
"""
import glob
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import (LinearRegression, LogisticRegression,
                                  PoissonRegressor, TweedieRegressor)

W = os.environ.get('DCE_ROOT', '/workspace')
VIEWS = ['presentation_documents', 'discrepancy_logs', 'refusal_notices',
         'amendment_histories', 'correspondent_banks', 'settlement_payments']
REGIME_START = 14
TENOR_CUTS = [45, 95, 160]


def load():
    reg = pd.DataFrame([json.load(open(f)) for f in glob.glob(W + '/credit_register/*.json')])
    reg = reg.set_index('beneficiary_id')
    snap, closed = {}, {}
    for v in VIEWS:
        S, C = [], []
        for f in glob.glob(f'{W}/{v}/*.jsonl'):
            for line in open(f):
                r = json.loads(line)
                (S if r['kind'] == 'snapshot' else C).append(r)
        s = pd.DataFrame(S).drop_duplicates(['beneficiary_id', 'period'], keep='last')
        c = pd.DataFrame(C).drop_duplicates('case_id', keep='last')
        c['post'] = (c.event_period >= REGIME_START).astype(int)
        snap[v], closed[v] = s, c
    hist = pd.DataFrame([json.loads(l) for l in open(W + '/history/examination.jsonl')])
    q = pd.DataFrame([json.loads(l) for l in open(W + '/queries.jsonl')])
    return reg, snap, closed, hist, q


def design(d, feats, g, extra=None):
    X = d[feats].astype(float).copy()
    for k in range(1, 4):
        X[f'g{k}'] = (d[g] == k).astype(float)
    if extra:
        extra(X, d)
    X['post'] = d['post'].astype(float)
    return X


def targets_frame(reg, snap, v, g, rows, post):
    """Snapshot rows for (beneficiary_id, period) pairs, with group code and regime."""
    s = rows[['beneficiary_id', 'period']].merge(snap[v], on=['beneficiary_id', 'period'], how='left')
    s[g] = reg.loc[s.beneficiary_id, g].values
    s['post'] = post
    return s


def two_dec(x):
    return float(np.round(max(float(x), 0.0) + 1e-12, 2))


def main(out=W + '/predictions.jsonl', verbose=True):
    reg, snap, closed, hist, q = load()
    q = q.drop_duplicates('record_id')
    hpost = (hist.period >= REGIME_START).astype(int).values
    qpost = np.zeros(len(q), dtype=int) if os.environ.get("NOPOST") else (q.period >= REGIME_START).astype(int).values
    res = {}

    def log(*a):
        if verbose:
            print(*a, file=sys.stderr)

    # ---- discrepancy count: Poisson GLM, log-linear calibration on history
    v, g = 'presentation_documents', 'document_route'
    F = ['data_conflict_share', 'document_count', 'expiry_margin_days',
         'missing_original_share', 'presentation_lag_days']
    ex = lambda X, d: X.__setitem__('logdoc', np.log(d.document_count.clip(lower=1e-6)))
    c = closed[v]
    m = PoissonRegressor(alpha=0, max_iter=5000).fit(design(c, F, g, ex), c.observed_discrepancies)
    hs = targets_frame(reg, snap, v, g, hist, hpost)
    qs = targets_frame(reg, snap, v, g, q, qpost)
    ph, pq = np.log(m.predict(design(hs, F, g, ex))), np.log(m.predict(design(qs, F, g, ex)))
    cal = LinearRegression().fit(ph[:, None], np.log(hist.discrepancy_count))
    log('disc cal', cal.coef_, cal.intercept_)
    hd = np.exp(cal.predict(ph[:, None]))
    log('disc hist MAE', np.abs(hd - hist.discrepancy_count).mean())
    res['discrepancy_count'] = np.exp(cal.predict(pq[:, None]))

    # ---- class profile: multinomial on class counts, temperature + bias calibrated on history
    v, g = 'discrepancy_logs', 'trade_corridor'
    F = ['inconsistency_share', 'insurance_gap', 'late_share', 'missing_share', 'transport_complexity']
    c = closed[v]
    cc = np.array(c.class_counts.tolist(), dtype=float)
    Xc = design(c, F, g).values
    ii, kk = np.nonzero(cc > 0)
    m = LogisticRegression(C=1.0, max_iter=20000).fit(Xc[ii], kk, sample_weight=cc[ii, kk])
    hs = targets_frame(reg, snap, v, g, hist, hpost)
    qs = targets_frame(reg, snap, v, g, q, qpost)
    Lh = m.predict_log_proba(design(hs, F, g).values)
    Lq = m.predict_log_proba(design(qs, F, g).values)
    H = np.array(hist.discrepancy_class_profile.tolist())
    Hf = np.c_[H, np.clip(1 - H.sum(1), 0, 1)]

    def soft(L, th):
        z = L * th[0] + np.r_[th[1:], 0.0]
        z -= z.max(1, keepdims=True)
        e = np.exp(z)
        return e / e.sum(1, keepdims=True)

    obj = lambda th: -(Hf * np.log(soft(Lh, th) + 1e-12)).sum()
    th = minimize(obj, np.r_[1.0, np.zeros(8)], method='BFGS').x
    log('profile temp', th[0], 'hist MAE', np.abs(soft(Lh, th)[:, :8] - H).mean())
    res['profile'] = soft(Lq, th)

    # ---- refusal: logistic on closed, threshold 0.5 on calibrated probability
    v, g = 'refusal_notices', 'credit_form'
    F = ['applicant_response_days', 'material_conflict_share', 'notice_time_left',
         'unwaived_items', 'waiver_reliability']
    c = closed[v]
    m = LogisticRegression(C=100, max_iter=10000).fit(design(c, F, g), c.notice_refused)
    hs = targets_frame(reg, snap, v, g, hist, hpost)
    qs = targets_frame(reg, snap, v, g, q, qpost)
    zh = m.decision_function(design(hs, F, g))
    zq = m.decision_function(design(qs, F, g))
    cal = LogisticRegression(C=100).fit(zh[:, None], hist.refusal_flag)
    log('refusal cal', cal.coef_, cal.intercept_, 'hist acc', (cal.predict(zh[:, None]) == hist.refusal_flag).mean(),
        'raw acc', ((zh > 0) == hist.refusal_flag).mean())
    res['refusal_flag'] = (cal.decision_function(zq[:, None]) > 0).astype(int)

    # ---- tenor tier: linear tenor model, desk mapping a + b*p fitted as interval-censored on history
    v, g = 'amendment_histories', 'tenor_basis'
    F = ['acceptance_delay_days', 'amendment_count', 'deferred_share', 'draft_tenor_days',
         'maturity_extension_days']
    c = closed[v]
    m = LinearRegression().fit(design(c, F, g), c.settled_tenor_days)
    hs = targets_frame(reg, snap, v, g, hist, hpost)
    qs = targets_frame(reg, snap, v, g, q, qpost)
    ph, pq = m.predict(design(hs, F, g)), m.predict(design(qs, F, g))
    y = hist.tenor_tier.values
    lo = np.array([-1e9] + TENOR_CUTS)[y]
    hi = np.array(TENOR_CUTS + [1e9])[y]

    def nll(t):
        mu = t[0] + t[1] * ph
        s = np.exp(t[2])
        return -np.log(np.clip(norm.cdf((hi - mu) / s) - norm.cdf((lo - mu) / s), 1e-12, 1)).sum()

    t = minimize(nll, [0.0, 1.0, np.log(10)], method='Nelder-Mead', options={'maxiter': 20000}).x
    tier = lambda x: np.digitize(x, TENOR_CUTS, right=True)
    log('tenor map', t, 'hist acc', (tier(t[0] + t[1] * ph) == y).mean(), 'raw acc', (tier(ph) == y).mean())
    res['tenor_tier'] = tier(t[0] + t[1] * pq)

    # ---- priority: handling urgency model, dense rank within period cohort
    v, g = 'correspondent_banks', 'service_band'
    F = ['bank_queue_hours', 'corridor_delay_days', 'cutoff_margin_hours', 'cycle_phase',
         'document_complexity']

    def ex(X, d):
        X['sin'] = np.sin(2 * np.pi * d.cycle_phase)
        X['cos'] = np.cos(2 * np.pi * d.cycle_phase)

    c = closed[v]
    m = HistGradientBoostingRegressor(max_iter=400, learning_rate=0.05, max_depth=4,
                                      random_state=0).fit(design(c, F, g, ex), c.handling_urgency)
    hs = targets_frame(reg, snap, v, g, hist, hpost)
    qs = targets_frame(reg, snap, v, g, q, qpost)
    uh = m.predict(design(hs, F, g, ex))
    uq = m.predict(design(qs, F, g, ex))
    rk = lambda u, per: pd.Series(np.round(u, 9)).groupby(per.values).rank(method='dense', ascending=False).astype(int).values
    rh = rk(uh, hist.period)
    log('rank hist spearman', pd.Series(rh).corr(hist.examiner_priority_rank, method='spearman'),
        'MAE', np.abs(rh - hist.examiner_priority_rank).mean())
    res['rank'] = rk(uq, q.period)

    # ---- charge reserve: Tweedie GLM, log-linear calibration on history
    v, g = 'settlement_payments', 'charge_schedule'
    F = ['claim_complexity', 'message_count', 'relationship_years', 'unpaid_fee_share']
    ex = lambda X, d: X.__setitem__('logface', np.log(d.face_amount_usd))
    c = closed[v]
    m = TweedieRegressor(power=1.5, alpha=0, link='log', max_iter=10000).fit(design(c, F, g, ex), c.charges_usd)
    hs = targets_frame(reg, snap, v, g, hist, hpost)
    qs = targets_frame(reg, snap, v, g, q, qpost)
    ph, pq = np.log(m.predict(design(hs, F, g, ex))), np.log(m.predict(design(qs, F, g, ex)))
    cal = LinearRegression().fit(ph[:, None], np.log(hist.charge_reserve))
    log('charge cal', cal.coef_, cal.intercept_)
    hc = np.exp(cal.predict(ph[:, None]))
    log('charge hist MAE', np.abs(hc - hist.charge_reserve).mean(), 'raw', np.abs(np.exp(ph) - hist.charge_reserve).mean())
    res['charge_reserve'] = np.exp(cal.predict(pq[:, None]))

    with open(out, 'w') as f:
        for i, r in enumerate(q.itertuples()):
            prof = [float(np.floor(x * 1e8) / 1e8) for x in res['profile'][i, :8]]
            rec = {
                'record_id': r.record_id,
                'discrepancy_count': two_dec(res['discrepancy_count'][i]),
                'discrepancy_class_profile': prof,
                'refusal_flag': int(res['refusal_flag'][i]),
                'tenor_tier': int(res['tenor_tier'][i]),
                'examiner_priority_rank': int(res['rank'][i]),
                'charge_reserve': two_dec(res['charge_reserve'][i]),
            }
            f.write(json.dumps(rec) + '\n')


if __name__ == '__main__':
    main()
