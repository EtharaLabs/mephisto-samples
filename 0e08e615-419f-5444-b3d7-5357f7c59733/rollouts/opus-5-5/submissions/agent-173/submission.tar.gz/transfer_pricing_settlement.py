"""Reproduce the transfer pricing desk's review records for the queried entity-pair-periods.

Central finding: at each review date the desk refits its models on the closed-case ledger it
knows at that date -- cases booked before the review month, restatements applied only once
restated before it (otherwise the as-booked outcome), over a trailing WINDOW of event periods. History (periods 8-12) predates
a level break in closed invoice and settlement outcomes at event period 14, so the query periods
(16, 20) inherit that break only to the extent the desk's known ledger contains it.

- challenge_flag: logistic regression refit on the known ledger at the review date
- method_tier: RBF kernel logistic regression refit on the known ledger (the desk's method
  rule is nonlinear); method tier is reviewed per class, so the rare tiers (CUP 0, profit
  split 3) are called when their probability exceeds RARE_TIER_P (validated on history)
- uncertain_tax_reserve: centred RBF kernel-ridge known-ledger refit on the desk's scale
  (slope fitted on history) plus a history-learnt correction; x tax_exposure
- adjustment_magnitude: 0.8 x (centred kernel-ridge known-ledger refit + history-learnt
  correction) + 0.2 x (history model with closed-case augmentation + known-ledger drift);
  x charge_base
- allocation_key_profile: 0.75 x (centred kernel-ridge known-ledger refit on the desk's scale +
  correction) + 0.25 x (share/composition model + known-ledger drift); residual kept
- review_rank: priority = least-squares known-ledger settlement-ratio refit (quadratic,
  seasonality as sin/cos(2*pi*s)) x settlement_base - paid_on_account, dense-ranked per period

Kernel ridge has no intercept, so every kernel-ridge target is mean-centred; otherwise it
shrinks towards zero and under-states the drift the desk's ledger has absorbed.
"""
import glob
import json
import os

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from sklearn.kernel_approximation import Nystroem
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import LinearRegression, LogisticRegression, RidgeCV
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.svm import SVC

# trailing window (event periods) over which the desk measures drift in its known ledger
WINDOW = 13
# the desk's ledger at review date p holds cases booked (and restatements made) up to p - LAG:
# the review month's own bookings are not yet in it
LAG = 1
RARE_TIER_P = 0.3
HALFLIFE = float(os.environ.get("HALFLIFE", "4"))
HL_RANK = int(os.environ.get("HL_RANK", "0"))
HL_CLS = int(os.environ.get("HL_CLS", "0"))
W = os.environ.get("TP_WORKSPACE", "/workspace")
VIEWS = ["invoices", "allocation_drivers", "tax_audits", "comparables", "settlements", "tax_positions"]
PREFIX = dict(invoices="inv", allocation_drivers="all", tax_audits="aud",
              comparables="com", settlements="set", tax_positions="pos")

meta = json.load(open(f"{W}/dataset_metadata.json"))
FEATS = meta["features"]


def load_snapshots():
    snap = {}
    for v in VIEWS:
        rows = []
        for f in glob.glob(f"{W}/{v}/*.jsonl"):
            for line in open(f):
                r = json.loads(line)
                if r.get("kind") == "snapshot":
                    rows.append(r)
        snap[v] = pd.DataFrame(rows).drop(columns="kind").drop_duplicates(["pair_id", "period"], keep="last")
    return snap


def build(df, snap, reg):
    out = df[["pair_id", "period"]].copy()
    for v in VIEWS:
        s = snap[v].rename(columns={c: f"{PREFIX[v]}_{c}" for c in snap[v].columns if c not in ("pair_id", "period")})
        out = out.merge(s, on=["pair_id", "period"], how="left")
    out = out.merge(reg[["pair_id", "jurisdiction_band"]], on="pair_id", how="left")
    out["jurisdiction_band"] = out["jurisdiction_band"].fillna(0).astype(int)
    return out


def view_X(df, v):
    cols = [f"{PREFIX[v]}_{c}" for c in FEATS[v]]
    X = df[cols].astype(float)
    return X.fillna(X.mean()).values


def band_onehot(df):
    return np.eye(4)[df["jurisdiction_band"].clip(0, 3).values]


def own_band(df, v):
    return np.hstack([view_X(df, v), band_onehot(df)])


def ridge(deg):
    return make_pipeline(PolynomialFeatures(deg), StandardScaler(), RidgeCV(alphas=np.logspace(-4, 3, 30)))


def rbf_krr():
    from sklearn.compose import TransformedTargetRegressor
    grid = {"alpha": [3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 1e-1], "gamma": [0.01, 0.02, 0.05, 0.1, 0.2]}
    m = make_pipeline(StandardScaler(), GridSearchCV(KernelRidge(kernel="rbf"), grid, cv=3))
    # centre the target: kernel ridge has no intercept
    return TransformedTargetRegressor(regressor=m, transformer=StandardScaler(with_std=False))


def closed_xy(view, reg, last_period):
    """Closed cases from before the regime break, as extra (noisy, offset) training data."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    c = c[c["event_period"] <= last_period]
    return own_band(c, view), c["outcome"].astype(float).values


class AugmentedKRR:
    """RBF kernel ridge on history labels plus down-weighted closed cases; an indicator
    column lets the closed cases sit at their own level relative to desk labels."""

    def __init__(self, weight=0.3, alpha=0.01, gamma=0.02):
        self.weight, self.alpha, self.gamma = weight, alpha, gamma

    def fit(self, X, y, closed):
        Xc, yc = closed
        Xt = np.vstack([np.hstack([X, np.zeros((len(X), 1))]), np.hstack([Xc, np.ones((len(Xc), 1))])])
        w = np.concatenate([np.ones(len(X)), self.weight * np.ones(len(Xc))])
        self.scaler = StandardScaler().fit(Xt)
        yt = np.concatenate([y, yc])
        self.mu = np.average(yt, weights=w)
        self.model = KernelRidge(kernel="rbf", alpha=self.alpha, gamma=self.gamma).fit(
            self.scaler.transform(Xt), yt - self.mu, sample_weight=w)
        return self

    def predict(self, X):
        return self.model.predict(self.scaler.transform(np.hstack([X, np.zeros((len(X), 1))]))) + self.mu


def load_closed(view, reg):
    rows = []
    for f in glob.glob(f"{W}/{view}/*.jsonl"):
        for line in open(f):
            r = json.loads(line)
            if r.get("kind") == "closed":
                rows.append(r)
    c = pd.DataFrame(rows).drop_duplicates("case_id", keep="last")
    c = c.rename(columns={k: f"{PREFIX[view]}_{k}" for k in FEATS[view]})
    return c.merge(reg[["pair_id", "jurisdiction_band"]], on="pair_id", how="left").fillna({"jurisdiction_band": 0})


def known_shift(view, reg, design, hist_last, review_period, window):
    """Level drift of closed outcomes as known to the desk at its review date.

    A model is fitted on closed cases from the history era. At review date p the desk sees
    only cases booked by p, with restatements applied only once restated by p (otherwise
    the as-booked outcome). The mean residual of those known cases over the trailing
    `window` event periods is the drift the desk carries into its estimate."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = design(c)
    y = c["outcome"].astype(float).values
    ep = c["event_period"].values
    base = ep <= hist_last
    m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[base], y[base])
    booked = np.array([b["outcome"] if isinstance(b, dict) else np.nan for b in c.get("as_booked", pd.Series([np.nan] * len(c)))], dtype=float)
    rp = c["restated_period"].values.astype(float) if "restated_period" in c else np.full(len(c), np.nan)
    val = np.where(np.isnan(rp) | (rp <= review_period - LAG), y, booked)
    r = val - m.predict(Xc)
    known = (c["booked_period"].values <= review_period - LAG) & (ep > review_period - window)
    base_level = r[base & (c["booked_period"].values <= hist_last)].mean()
    return float(r[known].mean() - base_level) if known.any() else 0.0


def alloc_known_shift(reg, hist_last, review_period, window):
    """Per-key drift of closed allocation studies as known at the review date (see known_shift)."""
    c = load_closed("allocation_drivers", reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = own_band(c, "allocation_drivers")
    y = np.array(c["outcome"].tolist(), dtype=float)
    ep = c["event_period"].values
    base = ep <= hist_last
    m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[base], y[base])
    booked = np.array([b["outcome"] if isinstance(b, dict) else [np.nan] * 8 for b in c["as_booked"]], dtype=float)
    rp = c["restated_period"].values.astype(float)
    val = np.where((np.isnan(rp) | (rp <= review_period - LAG))[:, None], y, booked)
    r = val - m.predict(Xc)
    known = (c["booked_period"].values <= review_period - LAG) & (ep > review_period - window)
    base_level = r[base & (c["booked_period"].values <= hist_last)].mean(0)
    return r[known].mean(0) - base_level if known.any() else np.zeros(8)


def known_ledger_classify(view, reg, Q, C, window=None, model=None):
    """The desk refits its classifier at each review date on the closed cases it knows then:
    booked by the review date, with restatements applied only once restated (else as booked)."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = own_band(c, view)
    booked = np.array([b["outcome"] if isinstance(b, dict) else np.nan for b in c["as_booked"]], dtype=float)
    rp = c["restated_period"].values.astype(float)
    out = np.zeros(len(Q), dtype=int)
    for p in Q["period"].unique():
        val = np.where(np.isnan(rp) | (rp <= p - LAG), c["outcome"].astype(float).values, booked).astype(int)
        k = c["booked_period"].values <= p - LAG
        if window is not None:
            k &= c["event_period"].values > p - window
        m = (model() if model is not None else make_pipeline(StandardScaler(), LogisticRegression(C=C, max_iter=10000))).fit(Xc[k], val[k])
        idx = Q["period"].values == p
        out[idx] = m.predict(own_band(Q[idx], view))
    return out


class CenteredKRR:
    """RBF kernel ridge on a mean-centred target: kernel ridge has no intercept, so without
    centring it shrinks towards zero and under-states level drift in the ledger."""

    def __init__(self, alpha, gamma):
        self.alpha, self.gamma = alpha, gamma

    def fit(self, X, y, sample_weight=None):
        self.mu = np.average(y, axis=0, weights=sample_weight)
        self.m = make_pipeline(StandardScaler(), KernelRidge(kernel="rbf", alpha=self.alpha, gamma=self.gamma)).fit(
            X, y - self.mu, kernelridge__sample_weight=sample_weight)
        return self

    def predict(self, X):
        return self.m.predict(X) + self.mu


class KernelLogit:
    """RBF kernel logistic regression (Nystroem features), probabilities averaged over seeds."""

    def __init__(self, gamma, C, n_components, seeds):
        self.ms = [make_pipeline(StandardScaler(), Nystroem(gamma=gamma, n_components=n_components, random_state=r),
                                 LogisticRegression(C=C, max_iter=10000)) for r in seeds]

    def fit(self, X, y):
        for m in self.ms:
            m.fit(X, y)
        self.classes_ = self.ms[0].classes_
        return self

    def predict(self, X):
        p = np.mean([m.predict_proba(X) for m in self.ms], 0)
        pred = self.classes_[p.argmax(1)]
        # method tier is reviewed per class, so rare tiers (CUP 0, profit split 3) are called
        # when their probability clears RARE_TIER_P; in history this flags exactly its one CUP
        for rare in (0, 3):
            if len(self.classes_) > 2 and rare in self.classes_:
                col = list(self.classes_).index(rare)
                pred = np.where(p[:, col] > RARE_TIER_P, rare, pred)
        return pred


def settle_basis(Xb):
    """Settlement features + band one-hot -> ratio basis (quadratic, seasonality as sin/cos)."""
    Xs, s = Xb[:, :6], Xb[:, 5:6]
    return np.hstack([PolynomialFeatures(2).fit_transform(Xs[:, :5]),
                      np.sin(2 * np.pi * s), np.cos(2 * np.pi * s), Xb[:, 7:10]])


def known_ledger_regress(view, reg, D, window, basis=None, model=None):
    """Per-row prediction of the closed-outcome model the desk refits at each review date on
    its known ledger (booked by then, restatements applied once restated, trailing window)."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = own_band(c, view)
    y = np.array(c["outcome"].tolist(), dtype=float)
    blank = np.full(y.shape[1:], np.nan)
    booked = np.array([b["outcome"] if isinstance(b, dict) else blank for b in c["as_booked"]], dtype=float)
    rp = c["restated_period"].values.astype(float)
    out = np.zeros((len(D),) + y.shape[1:])
    for p in D["period"].unique():
        known_restated = np.isnan(rp) | (rp <= p - LAG)
        val = np.where(known_restated.reshape((-1,) + (1,) * (y.ndim - 1)), y, booked)
        k = (c["booked_period"].values <= p - LAG) & (c["event_period"].values > p - window)
        idx = D["period"].values == p
        if model is not None and HALFLIFE:
            k = c["booked_period"].values <= p - LAG
            w = 0.5 ** ((p - LAG - c["event_period"].values[k]) / HALFLIFE)
            m = model().fit(Xc[k], val[k], sample_weight=w)
            out[idx] = m.predict(own_band(D[idx], view))
        elif model is not None:
            m = model().fit(Xc[k], val[k])
            out[idx] = m.predict(own_band(D[idx], view))
        elif basis is None:
            m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[k], val[k])
            out[idx] = m.predict(own_band(D[idx], view))
        elif HL_RANK:
            k = c["booked_period"].values <= p - LAG
            w = 0.5 ** ((p - LAG - c["event_period"].values[k]) / HALFLIFE)
            m = LinearRegression().fit(basis(Xc[k]), val[k], sample_weight=w)
            out[idx] = m.predict(basis(own_band(D[idx], view)))
        else:
            m = LinearRegression().fit(basis(Xc[k]), val[k])
            out[idx] = m.predict(basis(own_band(D[idx], view)))
    return out


def dense_rank_desc(x):
    x = np.round(x, 6)
    uniq = np.unique(x)[::-1]
    pos = {u: i + 1 for i, u in enumerate(uniq)}
    return np.array([pos[u] for u in x], dtype=int)


def main():
    snap = load_snapshots()
    reg = pd.DataFrame([json.load(open(f)) for f in glob.glob(f"{W}/register/*.json")])
    hist = pd.DataFrame([json.loads(l) for l in open(f"{W}/history/review.jsonl")])
    queries = pd.DataFrame([json.loads(l) for l in open(f"{W}/queries.jsonl")])

    H = build(hist, snap, reg).merge(hist, on=["pair_id", "period"])
    Q = build(queries, snap, reg).merge(queries[["pair_id", "period", "record_id"]], on=["pair_id", "period"])

    # adjustment magnitude
    ar = H["adjustment_magnitude"] / H["inv_charge_base"]
    m = AugmentedKRR().fit(own_band(H, "invoices"), ar.values, closed_xy("invoices", reg, H["period"].max() + 1))
    sh = {p: known_shift("invoices", reg, lambda d: own_band(d, "invoices"), H["period"].max(), p, WINDOW) for p in Q["period"].unique()}
    shift = Q["period"].map(sh).values
    print("invoice shift", np.unique(shift))
    ar_shift = m.predict(own_band(Q, "invoices")) + shift
    # second view: the desk's known-ledger refit plus a history-learnt correction
    krr = lambda: CenteredKRR(alpha=0.3, gamma=0.1)
    f_h = known_ledger_regress("invoices", reg, H, WINDOW, model=krr)
    f_q = known_ledger_regress("invoices", reg, Q, WINDOW, model=krr)
    ar_kl = f_q + rbf_krr().fit(own_band(H, "invoices"), ar.values - f_h).predict(own_band(Q, "invoices"))
    adj = np.clip(0.2 * ar_shift + 0.8 * ar_kl, 0, None) * Q["inv_charge_base"].fillna(0).values

    # uncertain tax reserve
    rr = H["uncertain_tax_reserve"] / H["pos_tax_exposure"]
    # desk reserves track the refitted known-ledger loss model on their own scale
    krr_t = lambda: CenteredKRR(alpha=10.0, gamma=0.02)
    f_h = known_ledger_regress("tax_positions", reg, H, WINDOW, model=krr_t)
    f_q = known_ledger_regress("tax_positions", reg, Q, WINDOW, model=krr_t)
    slope = np.polyfit(f_h, rr.values, 1)[0]
    m = rbf_krr().fit(own_band(H, "tax_positions"), rr.values - slope * f_h)
    res = np.clip(slope * f_q + m.predict(own_band(Q, "tax_positions")), 0, None) * Q["pos_tax_exposure"].fillna(0).values

    # challenge flag
    chal = known_ledger_classify("tax_audits", reg, Q, C=1.0, window=WINDOW)

    # method tier
    # the desk's method rule is nonlinear: kernel (Nystroem RBF) logistic regression
    klr = lambda: KernelLogit(gamma=0.4, C=0.3, n_components=1000, seeds=range(5))
    tier = known_ledger_classify("comparables", reg, Q, C=None, window=WINDOW, model=klr)

    # allocation key profile
    A = np.array(H["allocation_key_profile"].tolist(), dtype=float)
    A = np.clip(A, 1e-6, None)
    s = A.sum(1)
    clr = np.log(A / s[:, None])
    clr -= clr.mean(1, keepdims=True)
    Xa_h, Xa_q = own_band(H, "allocation_drivers"), own_band(Q, "allocation_drivers")
    ms = rbf_krr().fit(Xa_h, logit(np.clip(s, 1e-4, 1 - 1e-4)))
    mc = rbf_krr().fit(Xa_h, clr)
    comp = np.exp(mc.predict(Xa_q))
    comp /= comp.sum(1, keepdims=True)
    alloc = comp * expit(ms.predict(Xa_q))[:, None]
    ashift = {p: alloc_known_shift(reg, H["period"].max(), p, WINDOW) for p in Q["period"].unique()}
    # second view: the desk's known-ledger refit (on its own scale) plus a history-learnt correction
    krr_a = lambda: CenteredKRR(alpha=1.0, gamma=0.4)
    f_h = known_ledger_regress("allocation_drivers", reg, H, WINDOW, model=krr_a)
    f_q = known_ledger_regress("allocation_drivers", reg, Q, WINDOW, model=krr_a)
    slope = np.array([np.polyfit(f_h[:, k], A[:, k], 1)[0] for k in range(8)])
    alloc_shift = np.clip(alloc + slope * np.vstack([ashift[p] for p in Q["period"]]), 0, None)
    alloc_kl = np.clip(slope * f_q + rbf_krr().fit(Xa_h, A - slope * f_h).predict(Xa_q), 0, None)
    alloc = 0.25 * alloc_shift + 0.75 * alloc_kl

    # review rank: priority = the desk's known-ledger settlement ratio x base - paid on account
    g = known_ledger_regress("settlements", reg, Q, WINDOW, basis=settle_basis)
    prio = g * Q["set_settlement_base"].fillna(0).values - Q["set_paid_on_account"].fillna(0).values
    ranks = np.zeros(len(Q), dtype=int)
    for p in Q["period"].unique():
        idx = np.where(Q["period"].values == p)[0]
        ranks[idx] = dense_rank_desc(prio[idx])

    with open(f"{W}/predictions.jsonl", "w") as fh:
        for i, r in Q.reset_index(drop=True).iterrows():
            a = [float(np.floor(max(x, 0.0) * 1e8) / 1e8) for x in alloc[i]]
            if sum(a) > 1.0:
                a = [float(np.floor(x / sum(a) * 0.999999 * 1e8) / 1e8) for x in a]
            fh.write(json.dumps({
                "record_id": r["record_id"],
                "adjustment_magnitude": round(float(max(adj[i], 0.0)), 2),
                "allocation_key_profile": a,
                "challenge_flag": int(chal[i]),
                "method_tier": int(tier[i]),
                "review_rank": int(ranks[i]),
                "uncertain_tax_reserve": round(float(max(res[i], 0.0)), 2),
            }) + "\n")


if __name__ == "__main__":
    main()
