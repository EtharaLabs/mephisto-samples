"""Reproduce the transfer pricing desk's review records for the queried entity-pair-periods.

Every field is learnt from the desk's published history (history/review.jsonl) joined to
the current-period snapshots of the relevant operational view plus the register's
jurisdiction band:

- adjustment_magnitude: adjustment ratio (poly-3 ridge on invoice features) x charge_base
- uncertain_tax_reserve: reserve ratio (poly-3 ridge on tax-position features) x tax_exposure
- challenge_flag: poly-2 logistic regression on audit features
- method_tier: logistic regression on comparables features
- allocation_key_profile: retained share (logit) and composition (centred log-ratio)
  modelled separately from allocation drivers, so the residual is kept
- review_rank: settlement-priority ratio g(x) x settlement_base - paid_on_account, where g
  is learnt from pairwise rank order in history (seasonality enters as sin/cos(2*pi*s))
"""
import glob
import json
import os

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from sklearn.linear_model import LogisticRegression, RidgeCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

SHIFT_ADJ = float(os.environ.get("SHIFT_ADJ", "1"))
SHIFT_RANK = float(os.environ.get("SHIFT_RANK", "1"))
SHIFT_PERIODS = [int(x) for x in os.environ.get("SHIFT_PERIODS", "16,20").split(",") if x]
WINDOW = int(os.environ.get("WINDOW", "6"))
W = os.environ.get("TP_WORKSPACE", "/workspace")
VIEWS = ["invoices", "allocation_drivers", "tax_audits", "comparables", "settlements", "tax_positions"]
PREFIX = dict(invoices="inv", allocation_drivers="all", tax_audits="aud",
              comparables="com", settlements="set", tax_positions="pos")

meta = json.load(open(f"{W}/dataset_metadata.json"))
FEATS = meta["features"]


def load_snapshots():
    snap = {}
    for v in VIEWS:
        rows = []
        for f in glob.glob(f"{W}/{v}/*.jsonl"):
            for line in open(f):
                r = json.loads(line)
                if r.get("kind") == "snapshot":
                    rows.append(r)
        snap[v] = pd.DataFrame(rows).drop(columns="kind").drop_duplicates(["pair_id", "period"], keep="last")
    return snap


def build(df, snap, reg):
    out = df[["pair_id", "period"]].copy()
    for v in VIEWS:
        s = snap[v].rename(columns={c: f"{PREFIX[v]}_{c}" for c in snap[v].columns if c not in ("pair_id", "period")})
        out = out.merge(s, on=["pair_id", "period"], how="left")
    out = out.merge(reg[["pair_id", "jurisdiction_band"]], on="pair_id", how="left")
    out["jurisdiction_band"] = out["jurisdiction_band"].fillna(0).astype(int)
    return out


def view_X(df, v):
    cols = [f"{PREFIX[v]}_{c}" for c in FEATS[v]]
    X = df[cols].astype(float)
    return X.fillna(X.mean()).values


def band_onehot(df):
    return np.eye(4)[df["jurisdiction_band"].clip(0, 3).values]


def own_band(df, v):
    return np.hstack([view_X(df, v), band_onehot(df)])


def ridge(deg):
    return make_pipeline(PolynomialFeatures(deg), StandardScaler(), RidgeCV(alphas=np.logspace(-4, 3, 30)))


def rank_design(df):
    Xs = view_X(df, "settlements")
    s = Xs[:, 5:6]
    Z = np.hstack([PolynomialFeatures(2).fit_transform(Xs[:, :5]),
                   np.sin(2 * np.pi * s), np.cos(2 * np.pi * s), band_onehot(df)[:, 1:]])
    B = df["set_settlement_base"].fillna(0).values[:, None]
    paid = df["set_paid_on_account"].fillna(0).values[:, None]
    return np.hstack([Z * B, paid]) / 1e5


def fit_rank(H, rng):
    Z = rank_design(H)
    sd = Z.std(0) + 1e-12
    diffs, labs = [], []
    for p in H["period"].unique():
        idx = np.where(H["period"].values == p)[0]
        i = rng.choice(idx, 80000)
        j = rng.choice(idx, 80000)
        k = i != j
        i, j = i[k], j[k]
        diffs.append((Z[i] - Z[j]) / sd)
        labs.append((H["review_rank"].values[i] < H["review_rank"].values[j]).astype(int))
    m = LogisticRegression(C=100, fit_intercept=False, max_iter=20000).fit(np.vstack(diffs), np.concatenate(labs))
    return m.coef_[0] / sd


def load_closed(view, reg):
    rows = []
    for f in glob.glob(f"{W}/{view}/*.jsonl"):
        for line in open(f):
            r = json.loads(line)
            if r.get("kind") == "closed":
                rows.append(r)
    c = pd.DataFrame(rows).drop_duplicates("case_id", keep="last")
    c = c.rename(columns={k: f"{PREFIX[view]}_{k}" for k in FEATS[view]})
    return c.merge(reg[["pair_id", "jurisdiction_band"]], on="pair_id", how="left").fillna({"jurisdiction_band": 0})


def known_shift(view, reg, design, hist_last, review_period, window):
    """Level drift of closed outcomes as known to the desk at its review date.

    A model is fitted on closed cases from the history era. At review date p the desk sees
    only cases booked by p, with restatements applied only once restated by p (otherwise
    the as-booked outcome). The mean residual of those known cases over the trailing
    `window` event periods is the drift the desk carries into its estimate."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = design(c)
    y = c["outcome"].astype(float).values
    ep = c["event_period"].values
    base = ep <= hist_last
    m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[base], y[base])
    booked = np.array([b["outcome"] if isinstance(b, dict) else np.nan for b in c.get("as_booked", pd.Series([np.nan] * len(c)))], dtype=float)
    rp = c["restated_period"].values.astype(float) if "restated_period" in c else np.full(len(c), np.nan)
    val = np.where(np.isnan(rp) | (rp <= review_period), y, booked)
    r = val - m.predict(Xc)
    known = (c["booked_period"].values <= review_period) & (ep > review_period - window)
    base_level = r[base & (c["booked_period"].values <= hist_last)].mean()
    return float(r[known].mean() - base_level) if known.any() else 0.0


def dense_rank_desc(x):
    x = np.round(x, 6)
    uniq = np.unique(x)[::-1]
    pos = {u: i + 1 for i, u in enumerate(uniq)}
    return np.array([pos[u] for u in x], dtype=int)


def main():
    snap = load_snapshots()
    reg = pd.DataFrame([json.load(open(f)) for f in glob.glob(f"{W}/register/*.json")])
    hist = pd.DataFrame([json.loads(l) for l in open(f"{W}/history/review.jsonl")])
    queries = pd.DataFrame([json.loads(l) for l in open(f"{W}/queries.jsonl")])

    H = build(hist, snap, reg).merge(hist, on=["pair_id", "period"])
    Q = build(queries, snap, reg).merge(queries[["pair_id", "period", "record_id"]], on=["pair_id", "period"])

    # adjustment magnitude
    ar = H["adjustment_magnitude"] / H["inv_charge_base"]
    m = ridge(3).fit(own_band(H, "invoices"), ar)
    sh = {p: known_shift("invoices", reg, lambda d: own_band(d, "invoices"), H["period"].max(), p, WINDOW) for p in Q["period"].unique()}
    shift = Q["period"].map(sh).values
    print("invoice shift", np.unique(shift))
    adj = np.clip(m.predict(own_band(Q, "invoices")) + SHIFT_ADJ * shift, 0, None) * Q["inv_charge_base"].fillna(0).values

    # uncertain tax reserve
    rr = H["uncertain_tax_reserve"] / H["pos_tax_exposure"]
    m = ridge(3).fit(own_band(H, "tax_positions"), rr)
    res = np.clip(m.predict(own_band(Q, "tax_positions")), 0, None) * Q["pos_tax_exposure"].fillna(0).values

    # challenge flag
    m = make_pipeline(PolynomialFeatures(2), StandardScaler(), LogisticRegression(C=1, max_iter=10000))
    m.fit(own_band(H, "tax_audits"), H["challenge_flag"].values)
    chal = m.predict(own_band(Q, "tax_audits"))

    # method tier
    m = make_pipeline(StandardScaler(), LogisticRegression(C=100, max_iter=10000))
    m.fit(own_band(H, "comparables"), H["method_tier"].values)
    tier = m.predict(own_band(Q, "comparables"))

    # allocation key profile
    A = np.array(H["allocation_key_profile"].tolist(), dtype=float)
    A = np.clip(A, 1e-6, None)
    s = A.sum(1)
    clr = np.log(A / s[:, None])
    clr -= clr.mean(1, keepdims=True)
    Xa_h, Xa_q = own_band(H, "allocation_drivers"), own_band(Q, "allocation_drivers")
    ms = ridge(3).fit(Xa_h, logit(np.clip(s, 1e-4, 1 - 1e-4)))
    mc = ridge(3).fit(Xa_h, clr)
    comp = np.exp(mc.predict(Xa_q))
    comp /= comp.sum(1, keepdims=True)
    alloc = comp * expit(ms.predict(Xa_q))[:, None]

    # review rank
    w = fit_rank(H, np.random.default_rng(0))
    sd_set = lambda d: np.hstack([own_band(d, "settlements"), np.sin(2 * np.pi * view_X(d, "settlements")[:, 5:6])])
    sh = {p: known_shift("settlements", reg, sd_set, H["period"].max(), p, WINDOW) for p in Q["period"].unique()}
    gshift = Q["period"].map(sh).values * Q["period"].isin(SHIFT_PERIODS).values
    print("settlement shift", np.unique(gshift))
    # w[-1] is the (negative) weight on paid_on_account; priority in USD is g*B - paid
    scale = -w[-1] / 1e5
    prio = rank_design(Q) @ w + SHIFT_RANK * scale * gshift * Q["set_settlement_base"].fillna(0).values
    ranks = np.zeros(len(Q), dtype=int)
    for p in Q["period"].unique():
        idx = np.where(Q["period"].values == p)[0]
        ranks[idx] = dense_rank_desc(prio[idx])

    with open(f"{W}/predictions.jsonl", "w") as fh:
        for i, r in Q.reset_index(drop=True).iterrows():
            a = [float(np.floor(max(x, 0.0) * 1e8) / 1e8) for x in alloc[i]]
            if sum(a) > 1.0:
                a = [float(np.floor(x / sum(a) * 0.999999 * 1e8) / 1e8) for x in a]
            fh.write(json.dumps({
                "record_id": r["record_id"],
                "adjustment_magnitude": round(float(max(adj[i], 0.0)), 2),
                "allocation_key_profile": a,
                "challenge_flag": int(chal[i]),
                "method_tier": int(tier[i]),
                "review_rank": int(ranks[i]),
                "uncertain_tax_reserve": round(float(max(res[i], 0.0)), 2),
            }) + "\n")


if __name__ == "__main__":
    main()
