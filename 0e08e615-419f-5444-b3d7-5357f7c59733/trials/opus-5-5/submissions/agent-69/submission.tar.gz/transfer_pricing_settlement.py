"""Reproduce the transfer pricing desk's review records for the queried entity-pair-periods.

Every field is learnt from the desk's published history (history/review.jsonl) joined to
the current-period snapshots of the relevant operational view plus the register's
jurisdiction band:

- adjustment_magnitude: adjustment ratio x charge_base; RBF kernel ridge on invoice features,
  with pre-break closed invoice cases added at low weight behind an indicator column
- uncertain_tax_reserve: reserve ratio (RBF kernel ridge on tax-position features) x tax_exposure
- challenge_flag: poly-2 logistic regression on audit features
- method_tier: RBF support vector classifier on comparables features
- allocation_key_profile: retained share (logit) and composition (centred log-ratio)
  modelled separately (RBF kernel ridge) from allocation drivers, so the residual is kept
- review_rank: settlement-priority ratio g(x) x settlement_base - paid_on_account, where g
  is learnt from pairwise rank order in history (seasonality enters as sin/cos(2*pi*s))

History only covers periods before a level break in closed invoice and settlement outcomes
(event period 14). The desk carries drift into its estimates only as far as its ledger knows it
at the review date: cases booked by then, restatements applied only once restated, averaged
over a trailing 13-period window. That known-ledger drift is added to the adjustment ratio, the
settlement-priority ratio and the allocation keys.
"""
import glob
import json
import os

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import LogisticRegression, RidgeCV
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.svm import SVC

# trailing window (event periods) over which the desk measures drift in its known ledger
WINDOW = 13
W = os.environ.get("TP_WORKSPACE", "/workspace")
VIEWS = ["invoices", "allocation_drivers", "tax_audits", "comparables", "settlements", "tax_positions"]
PREFIX = dict(invoices="inv", allocation_drivers="all", tax_audits="aud",
              comparables="com", settlements="set", tax_positions="pos")

meta = json.load(open(f"{W}/dataset_metadata.json"))
FEATS = meta["features"]


def load_snapshots():
    snap = {}
    for v in VIEWS:
        rows = []
        for f in glob.glob(f"{W}/{v}/*.jsonl"):
            for line in open(f):
                r = json.loads(line)
                if r.get("kind") == "snapshot":
                    rows.append(r)
        snap[v] = pd.DataFrame(rows).drop(columns="kind").drop_duplicates(["pair_id", "period"], keep="last")
    return snap


def build(df, snap, reg):
    out = df[["pair_id", "period"]].copy()
    for v in VIEWS:
        s = snap[v].rename(columns={c: f"{PREFIX[v]}_{c}" for c in snap[v].columns if c not in ("pair_id", "period")})
        out = out.merge(s, on=["pair_id", "period"], how="left")
    out = out.merge(reg[["pair_id", "jurisdiction_band"]], on="pair_id", how="left")
    out["jurisdiction_band"] = out["jurisdiction_band"].fillna(0).astype(int)
    return out


def view_X(df, v):
    cols = [f"{PREFIX[v]}_{c}" for c in FEATS[v]]
    X = df[cols].astype(float)
    return X.fillna(X.mean()).values


def band_onehot(df):
    return np.eye(4)[df["jurisdiction_band"].clip(0, 3).values]


def own_band(df, v):
    return np.hstack([view_X(df, v), band_onehot(df)])


def ridge(deg):
    return make_pipeline(PolynomialFeatures(deg), StandardScaler(), RidgeCV(alphas=np.logspace(-4, 3, 30)))


def rbf_krr():
    grid = {"alpha": [3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 1e-1], "gamma": [0.01, 0.02, 0.05, 0.1, 0.2]}
    return make_pipeline(StandardScaler(), GridSearchCV(KernelRidge(kernel="rbf"), grid, cv=3))


def closed_xy(view, reg, last_period):
    """Closed cases from before the regime break, as extra (noisy, offset) training data."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    c = c[c["event_period"] <= last_period]
    return own_band(c, view), c["outcome"].astype(float).values


class AugmentedKRR:
    """RBF kernel ridge on history labels plus down-weighted closed cases; an indicator
    column lets the closed cases sit at their own level relative to desk labels."""

    def __init__(self, weight=0.3, alpha=0.01, gamma=0.02):
        self.weight, self.alpha, self.gamma = weight, alpha, gamma

    def fit(self, X, y, closed):
        Xc, yc = closed
        Xt = np.vstack([np.hstack([X, np.zeros((len(X), 1))]), np.hstack([Xc, np.ones((len(Xc), 1))])])
        w = np.concatenate([np.ones(len(X)), self.weight * np.ones(len(Xc))])
        self.scaler = StandardScaler().fit(Xt)
        self.model = KernelRidge(kernel="rbf", alpha=self.alpha, gamma=self.gamma).fit(
            self.scaler.transform(Xt), np.concatenate([y, yc]), sample_weight=w)
        return self

    def predict(self, X):
        return self.model.predict(self.scaler.transform(np.hstack([X, np.zeros((len(X), 1))])))


def rank_design(df):
    Xs = view_X(df, "settlements")
    s = Xs[:, 5:6]
    Z = np.hstack([PolynomialFeatures(2).fit_transform(Xs[:, :5]),
                   np.sin(2 * np.pi * s), np.cos(2 * np.pi * s), band_onehot(df)[:, 1:]])
    B = df["set_settlement_base"].fillna(0).values[:, None]
    paid = df["set_paid_on_account"].fillna(0).values[:, None]
    return np.hstack([Z * B, paid]) / 1e5


def fit_rank(H):
    Z = rank_design(H)
    sd = Z.std(0) + 1e-12
    diffs, labs = [], []
    for p in H["period"].unique():
        idx = np.where(H["period"].values == p)[0]
        I, J = np.triu_indices(len(idx), 1)
        i, j = idx[I], idx[J]
        diffs.append((Z[i] - Z[j]) / sd)
        labs.append((H["review_rank"].values[i] < H["review_rank"].values[j]).astype(int))
    m = LogisticRegression(C=100, fit_intercept=False, max_iter=20000).fit(np.vstack(diffs), np.concatenate(labs))
    return m.coef_[0] / sd


def load_closed(view, reg):
    rows = []
    for f in glob.glob(f"{W}/{view}/*.jsonl"):
        for line in open(f):
            r = json.loads(line)
            if r.get("kind") == "closed":
                rows.append(r)
    c = pd.DataFrame(rows).drop_duplicates("case_id", keep="last")
    c = c.rename(columns={k: f"{PREFIX[view]}_{k}" for k in FEATS[view]})
    return c.merge(reg[["pair_id", "jurisdiction_band"]], on="pair_id", how="left").fillna({"jurisdiction_band": 0})


def known_shift(view, reg, design, hist_last, review_period, window):
    """Level drift of closed outcomes as known to the desk at its review date.

    A model is fitted on closed cases from the history era. At review date p the desk sees
    only cases booked by p, with restatements applied only once restated by p (otherwise
    the as-booked outcome). The mean residual of those known cases over the trailing
    `window` event periods is the drift the desk carries into its estimate."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = design(c)
    y = c["outcome"].astype(float).values
    ep = c["event_period"].values
    base = ep <= hist_last
    m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[base], y[base])
    booked = np.array([b["outcome"] if isinstance(b, dict) else np.nan for b in c.get("as_booked", pd.Series([np.nan] * len(c)))], dtype=float)
    rp = c["restated_period"].values.astype(float) if "restated_period" in c else np.full(len(c), np.nan)
    val = np.where(np.isnan(rp) | (rp <= review_period), y, booked)
    r = val - m.predict(Xc)
    known = (c["booked_period"].values <= review_period) & (ep > review_period - window)
    base_level = r[base & (c["booked_period"].values <= hist_last)].mean()
    return float(r[known].mean() - base_level) if known.any() else 0.0


def alloc_known_shift(reg, hist_last, review_period, window):
    """Per-key drift of closed allocation studies as known at the review date (see known_shift)."""
    c = load_closed("allocation_drivers", reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = own_band(c, "allocation_drivers")
    y = np.array(c["outcome"].tolist(), dtype=float)
    ep = c["event_period"].values
    base = ep <= hist_last
    m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[base], y[base])
    booked = np.array([b["outcome"] if isinstance(b, dict) else [np.nan] * 8 for b in c["as_booked"]], dtype=float)
    rp = c["restated_period"].values.astype(float)
    val = np.where((np.isnan(rp) | (rp <= review_period))[:, None], y, booked)
    r = val - m.predict(Xc)
    known = (c["booked_period"].values <= review_period) & (ep > review_period - window)
    base_level = r[base & (c["booked_period"].values <= hist_last)].mean(0)
    return r[known].mean(0) - base_level if known.any() else np.zeros(8)


def known_ledger_classify(view, reg, Q, C):
    """The desk refits its classifier at each review date on the closed cases it knows then:
    booked by the review date, with restatements applied only once restated (else as booked)."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = own_band(c, view)
    booked = np.array([b["outcome"] if isinstance(b, dict) else np.nan for b in c["as_booked"]], dtype=float)
    rp = c["restated_period"].values.astype(float)
    out = np.zeros(len(Q), dtype=int)
    for p in Q["period"].unique():
        val = np.where(np.isnan(rp) | (rp <= p), c["outcome"].astype(float).values, booked).astype(int)
        k = c["booked_period"].values <= p
        m = make_pipeline(StandardScaler(), LogisticRegression(C=C, max_iter=10000)).fit(Xc[k], val[k])
        idx = Q["period"].values == p
        out[idx] = m.predict(own_band(Q[idx], view))
    return out


def settle_basis(Xb):
    """Settlement features + band one-hot -> ratio basis (quadratic, seasonality as sin/cos)."""
    Xs, s = Xb[:, :6], Xb[:, 5:6]
    return np.hstack([PolynomialFeatures(2).fit_transform(Xs[:, :5]),
                      np.sin(2 * np.pi * s), np.cos(2 * np.pi * s), Xb[:, 7:10]])


def known_ledger_regress(view, reg, D, window, basis=None):
    """Per-row prediction of the closed-outcome model the desk refits at each review date on
    its known ledger (booked by then, restatements applied once restated, trailing window)."""
    c = load_closed(view, reg)
    c["jurisdiction_band"] = c["jurisdiction_band"].astype(int)
    Xc = own_band(c, view)
    y = np.array(c["outcome"].tolist(), dtype=float)
    blank = np.full(y.shape[1:], np.nan)
    booked = np.array([b["outcome"] if isinstance(b, dict) else blank for b in c["as_booked"]], dtype=float)
    rp = c["restated_period"].values.astype(float)
    out = np.zeros((len(D),) + y.shape[1:])
    for p in D["period"].unique():
        known_restated = np.isnan(rp) | (rp <= p)
        val = np.where(known_restated.reshape((-1,) + (1,) * (y.ndim - 1)), y, booked)
        k = (c["booked_period"].values <= p) & (c["event_period"].values > p - window)
        idx = D["period"].values == p
        if basis is None:
            m = make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 20))).fit(Xc[k], val[k])
            out[idx] = m.predict(own_band(D[idx], view))
        else:
            m = RidgeCV(alphas=np.logspace(-4, 2, 20)).fit(basis(Xc[k]), val[k])
            out[idx] = m.predict(basis(own_band(D[idx], view)))
    return out


def dense_rank_desc(x):
    x = np.round(x, 6)
    uniq = np.unique(x)[::-1]
    pos = {u: i + 1 for i, u in enumerate(uniq)}
    return np.array([pos[u] for u in x], dtype=int)


def main():
    snap = load_snapshots()
    reg = pd.DataFrame([json.load(open(f)) for f in glob.glob(f"{W}/register/*.json")])
    hist = pd.DataFrame([json.loads(l) for l in open(f"{W}/history/review.jsonl")])
    queries = pd.DataFrame([json.loads(l) for l in open(f"{W}/queries.jsonl")])

    H = build(hist, snap, reg).merge(hist, on=["pair_id", "period"])
    Q = build(queries, snap, reg).merge(queries[["pair_id", "period", "record_id"]], on=["pair_id", "period"])

    # adjustment magnitude
    ar = H["adjustment_magnitude"] / H["inv_charge_base"]
    m = AugmentedKRR().fit(own_band(H, "invoices"), ar.values, closed_xy("invoices", reg, H["period"].max() + 1))
    sh = {p: known_shift("invoices", reg, lambda d: own_band(d, "invoices"), H["period"].max(), p, WINDOW) for p in Q["period"].unique()}
    shift = Q["period"].map(sh).values
    print("invoice shift", np.unique(shift))
    adj = np.clip(m.predict(own_band(Q, "invoices")) + shift, 0, None) * Q["inv_charge_base"].fillna(0).values

    # uncertain tax reserve
    rr = H["uncertain_tax_reserve"] / H["pos_tax_exposure"]
    # desk reserves track the refitted known-ledger loss model on their own scale
    f_h = known_ledger_regress("tax_positions", reg, H, WINDOW)
    f_q = known_ledger_regress("tax_positions", reg, Q, WINDOW)
    slope = np.polyfit(f_h, rr.values, 1)[0]
    m = rbf_krr().fit(own_band(H, "tax_positions"), rr.values - slope * f_h)
    res = np.clip(slope * f_q + m.predict(own_band(Q, "tax_positions")), 0, None) * Q["pos_tax_exposure"].fillna(0).values

    # challenge flag
    chal = known_ledger_classify("tax_audits", reg, Q, C=1.0)

    # method tier
    tier = known_ledger_classify("comparables", reg, Q, C=0.1)

    # allocation key profile
    A = np.array(H["allocation_key_profile"].tolist(), dtype=float)
    A = np.clip(A, 1e-6, None)
    s = A.sum(1)
    clr = np.log(A / s[:, None])
    clr -= clr.mean(1, keepdims=True)
    Xa_h, Xa_q = own_band(H, "allocation_drivers"), own_band(Q, "allocation_drivers")
    ms = rbf_krr().fit(Xa_h, logit(np.clip(s, 1e-4, 1 - 1e-4)))
    mc = rbf_krr().fit(Xa_h, clr)
    comp = np.exp(mc.predict(Xa_q))
    comp /= comp.sum(1, keepdims=True)
    alloc = comp * expit(ms.predict(Xa_q))[:, None]
    ashift = {p: alloc_known_shift(reg, H["period"].max(), p, WINDOW) for p in Q["period"].unique()}
    alloc = np.clip(alloc + np.vstack([ashift[p] for p in Q["period"]]), 0, None)

    # review rank: the desk's settlement-priority ratio is its known-ledger refit
    g = known_ledger_regress("settlements", reg, Q, WINDOW, basis=settle_basis)
    prio = g * Q["set_settlement_base"].fillna(0).values - Q["set_paid_on_account"].fillna(0).values
    ranks = np.zeros(len(Q), dtype=int)
    for p in Q["period"].unique():
        idx = np.where(Q["period"].values == p)[0]
        ranks[idx] = dense_rank_desc(prio[idx])

    with open(f"{W}/predictions.jsonl", "w") as fh:
        for i, r in Q.reset_index(drop=True).iterrows():
            a = [float(np.floor(max(x, 0.0) * 1e8) / 1e8) for x in alloc[i]]
            if sum(a) > 1.0:
                a = [float(np.floor(x / sum(a) * 0.999999 * 1e8) / 1e8) for x in a]
            fh.write(json.dumps({
                "record_id": r["record_id"],
                "adjustment_magnitude": round(float(max(adj[i], 0.0)), 2),
                "allocation_key_profile": a,
                "challenge_flag": int(chal[i]),
                "method_tier": int(tier[i]),
                "review_rank": int(ranks[i]),
                "uncertain_tax_reserve": round(float(max(res[i], 0.0)), 2),
            }) + "\n")


if __name__ == "__main__":
    main()
