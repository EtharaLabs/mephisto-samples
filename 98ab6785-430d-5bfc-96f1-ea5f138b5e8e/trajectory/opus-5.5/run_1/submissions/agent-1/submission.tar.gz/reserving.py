#!/usr/bin/env python3
# Claims methods laboratory: five deterministic estimators.
# CLI:  python3 reserving.py --data /workspace/data --out /workspace/reserving_results.json
# Pure standard library (no requirements).
import json, math, collections, argparse

LAGS = 10
REP_LAGS = 6
REOPEN_DELAY = 4


def load(path):
    with open(path) as f:
        return [json.loads(l) for l in f if l.strip()]


def pctile_within(groups, scores):
    """groups: key->list of ids; scores: id->value. returns id->peer percentile"""
    out = {}
    for g, ids in groups.items():
        n = len(ids)
        for i in ids:
            below = sum(1 for j in ids if scores[j] < scores[i])
            tied = sum(1 for j in ids if scores[j] == scores[i])
            out[i] = (below + 0.5 * tied) / n
    return out


class Model:
    def __init__(self, train, queries, cfg):
        self.cfg = cfg
        recs = collections.defaultdict(list)
        for r in train:
            recs[r['record_id']].append(r)
        for k in recs:
            recs[k].sort(key=lambda r: r['development_lag'])
        self.recs = recs
        self.queries = queries
        infl = {}
        for r in train:
            infl[r['calendar_period']] = r['inflation_index']
        for qq in queries:
            for r in qq['history']:
                infl[r['calendar_period']] = r['inflation_index']
        self.infl = infl
        self.by_cohort = collections.defaultdict(list)
        for k, v in recs.items():
            self.by_cohort[v[0]['cohort']].append(v)
        self.lob_of = {v[0]['cohort']: v[0]['lob'] for v in recs.values()}
        self.fit()

    # ---------------------------------------------------------------- fit
    def fit(self):
        recs = self.recs
        # reporting pattern per cohort, frequency per exposure
        self.rep_pat = {}
        self.freq = {}
        for c, R in self.by_cohort.items():
            s = [0.0] * LAGS
            for v in R:
                for j in range(LAGS):
                    s[j] += v[j]['new_reported_count']
            T = sum(s)
            self.rep_pat[c] = [x / T for x in s]
            self.freq[c] = T / sum(v[0]['exposure'] for v in R)
        # deflated severity by line, Buhlmann-Straub with record units
        self.sev_mu = {}
        self.sev_K = {}
        self.sev_var = {}
        for lob in sorted(set(self.lob_of.values())):
            units = []
            for v in recs.values():
                if v[0]['lob'] != lob:
                    continue
                u = [(r['primary_paid'] / r['inflation_index'] / r['new_reported_count'], r['new_reported_count'])
                     for r in v if r['new_reported_count'] > 0]
                units.append(u)
            num = den = 0.0
            mi = []
            for u in units:
                wi = sum(w for _, w in u)
                xi = sum(x * w for x, w in u) / wi
                num += sum(w * (x - xi) ** 2 for x, w in u)
                den += len(u) - 1
                mi.append((xi, wi))
            epv = num / den
            W = sum(w for _, w in mi)
            xb = sum(x * w for x, w in mi) / W
            vhm = (sum(w * (x - xb) ** 2 for x, w in mi) - (len(units) - 1) * epv) / (W - sum(w * w for _, w in mi) / W)
            self.sev_mu[lob] = xb
            self.sev_K[lob] = epv / vhm if vhm > 0 else 1e12
            # per-claim variance for standardization
            cells = [(x, w) for u in units for x, w in u]
            self.sev_var[lob] = sum(w * (x - xb) ** 2 for x, w in cells) / len(cells)
        # deflated payment pattern per cohort (all types)
        self.pay_pat = {}
        for c, R in self.by_cohort.items():
            s = [0.0] * LAGS
            for v in R:
                for j in range(LAGS):
                    r = v[j]
                    s[j] += (r['primary_paid'] + r['settlement_paid'] + r['reopening_paid']) / r['inflation_index']
            T = sum(s)
            self.pay_pat[c] = [x / T for x in s]
        # reopening: delayed binomial per cohort, beta prior per line
        self.reop = {}
        for c, R in self.by_cohort.items():
            ev = el = 0
            for v in R:
                for j in range(REOPEN_DELAY, LAGS):
                    ev += v[j]['reopened_count'] - v[j - 1]['reopened_count']
                    el += v[j - REOPEN_DELAY]['new_reported_count']
            self.reop[c] = (ev, el)
        self.reop_prior = {}
        for lob in sorted(set(self.lob_of.values())):
            ps = [self.reop[c][0] / self.reop[c][1] for c in self.reop if self.lob_of[c] == lob]
            m = sum(ps) / len(ps)
            v = sum((p - m) ** 2 for p in ps) / (len(ps) - 1)
            ab = max(m * (1 - m) / max(v, 1e-9) - 1, 1.0)
            self.reop_prior[lob] = (m * ab, (1 - m) * ab)

    # ------------------------------------------------------------ helpers
    def growth(self, t):
        """trailing average log growth of inflation index at calendar t"""
        n = self.cfg.get('infl_window', 4)
        pts = [s for s in range(t - n, t + 1) if s in self.infl]
        if len(pts) < 2:
            return 0.0
        return math.log(self.infl[pts[-1]] / self.infl[pts[0]]) / (pts[-1] - pts[0])

    # ---------------------------------------------------------- estimators
    def severity(self, H):
        lob = H[0]['lob']
        n = sum(r['new_reported_count'] for r in H)
        s = sum(r['primary_paid'] / r['inflation_index'] for r in H)
        mu = self.sev_mu[lob]
        if n == 0:
            return mu
        Z = n / (n + self.sev_K[lob])
        return Z * s / n + (1 - Z) * mu

    def reporting(self, H):
        c = H[0]['cohort']
        k = len(H)
        p = self.rep_pat[c]
        lam = H[0]['exposure'] * self.freq[c]
        out = [float(r['new_reported_count']) for r in H] + [lam * p[j] for j in range(k, LAGS)]
        T = sum(out)
        return [x / T for x in out]

    def cash(self, H):
        c = H[0]['cohort']
        k = len(H)
        ap = H[0]['accident_period']
        tcut = ap + k
        g = self.growth(tcut)
        base = self.infl[tcut]
        p = self.pay_pat[c]
        out = [0.0] * LAGS
        for j in range(k, LAGS):
            t = ap + j + 1
            out[j] = p[j] * base * math.exp(g * (t - tcut))
        T = sum(out)
        if T <= 0:
            out = [0.0] * LAGS
            out[LAGS - 1] = 1.0
            return out
        return [x / T for x in out]

    def reopen_rate(self, H):
        c = H[0]['cohort']
        lob = H[0]['lob']
        a, b = self.reop_prior[lob]
        ev, el = self.reop[c]
        k = len(H)
        qev = H[-1]['reopened_count']
        qel = sum(H[j]['new_reported_count'] for j in range(0, max(0, k - REOPEN_DELAY)))
        return (a + ev + qev) / (a + b + el + qel)

    def large(self, H):
        lob = H[0]['lob']
        mu = self.sev_mu[lob]
        sd = math.sqrt(self.sev_var[lob])
        thr = self.cfg.get('ll_thr', 1.645)
        ex = cells = 0
        zs = 0.0
        for r in H:
            n = r['new_reported_count']
            if n > 0:
                z = (r['primary_paid'] / r['inflation_index'] - n * mu) / (math.sqrt(n) * sd)
                cells += 1
                ex += z > thr
                zs += z
        a = 0.3; b = 4.7
        return (a + ex) / (a + b + cells) + 1e-6 * zs / max(cells, 1)

    # ---------------------------------------------------------------- run
    def run(self):
        preds = []
        peers = collections.defaultdict(list)
        rr = {}
        ll = {}
        for qq in self.queries:
            H = sorted(qq['history'], key=lambda r: r['development_lag'])
            rid = qq['record_id']
            peers[(H[0]['accident_period'], H[0]['lob'])].append(rid)
            rr[rid] = self.reopen_rate(H)
            ll[rid] = self.large(H)
            preds.append({
                'record_id': rid,
                'ultimate_severity': self.severity(H),
                'reporting_pattern': self.reporting(H),
                'cash_pattern': self.cash(H),
            })
        rp = pctile_within(peers, rr)
        lp = pctile_within(peers, ll)
        for p in preds:
            p['reopening_flag'] = bool(rp[p['record_id']] >= 0.8)
            p['large_loss_score'] = lp[p['record_id']]
        return preds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', default='/workspace/data')
    ap.add_argument('--out', default='/workspace/reserving_results.json')
    a = ap.parse_args()
    train = load(a.data + '/train.jsonl')
    queries = load(a.data + '/queries.jsonl')
    m = Model(train, queries, {})
    preds = m.run()
    for p in preds:
        p['reporting_pattern'] = [round(x, 10) for x in p['reporting_pattern']]
        p['cash_pattern'] = [round(x, 10) for x in p['cash_pattern']]
    with open(a.out, 'w') as f:
        json.dump({'predictions': preds, 'self_reported_metrics': {'record_count': len(preds)}}, f)


if __name__ == '__main__':
    main()
