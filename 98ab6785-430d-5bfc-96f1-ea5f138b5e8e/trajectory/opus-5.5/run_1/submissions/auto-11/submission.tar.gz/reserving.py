#!/usr/bin/env python3
# Claims methods laboratory: five deterministic estimators.
# CLI:  python3 reserving.py --data /workspace/data --out /workspace/reserving_results.json
# Pure standard library (no requirements).
import json, math, collections, argparse


def solve(A,b):
    n=len(A); M=[row[:]+[b[i]] for i,row in enumerate(A)]
    for i in range(n):
        p=max(range(i,n),key=lambda r:abs(M[r][i])); M[i],M[p]=M[p],M[i]
        if abs(M[i][i])<1e-15: continue
        for r in range(n):
            if r!=i:
                f=M[r][i]/M[i][i]
                for c in range(i,n+1): M[r][c]-=f*M[i][c]
    return [M[i][n]/M[i][i] if abs(M[i][i])>1e-15 else 0 for i in range(n)]
def lstsq(X,y,w=None):
    p=len(X[0]); w=w or [1]*len(y)
    A=[[sum(w[k]*X[k][i]*X[k][j] for k in range(len(y))) for j in range(p)] for i in range(p)]
    b=[sum(w[k]*X[k][i]*y[k] for k in range(len(y))) for i in range(p)]
    return solve(A,b)
def nnls(X,y,w=None):
    p=len(X[0]); act=list(range(p))
    while True:
        Xa=[[x[i] for i in act] for x in X]
        b=lstsq(Xa,y,w) if act else []
        if all(c>=0 for c in b): break
        worst=min(range(len(b)),key=lambda i:b[i]); act.pop(worst)
    out=[0.0]*p
    for i,c in zip(act,b): out[i]=c
    return out


LAGS = 10
# best-known estimator options (selected with judge feedback)
BEST = {'sev': 'K', 'K': 40}
REP_LAGS = 6
REOPEN_DELAY = 4


def load(path):
    with open(path) as f:
        return [json.loads(l) for l in f if l.strip()]


def pctile_within(groups, scores):
    """groups: key->list of ids; scores: id->value. returns id->peer percentile"""
    out = {}
    for g, ids in groups.items():
        n = len(ids)
        for i in ids:
            below = sum(1 for j in ids if scores[j] < scores[i])
            tied = sum(1 for j in ids if scores[j] == scores[i])
            out[i] = (below + 0.5 * tied) / n
    return out


class Model:
    def __init__(self, train, queries, cfg):
        self.cfg = cfg
        recs = collections.defaultdict(list)
        for r in train:
            recs[r['record_id']].append(r)
        for k in recs:
            recs[k].sort(key=lambda r: r['development_lag'])
        self.recs = recs
        self.queries = queries
        infl = {}
        for r in train:
            infl[r['calendar_period']] = r['inflation_index']
        for qq in queries:
            for r in qq['history']:
                infl[r['calendar_period']] = r['inflation_index']
        self.infl = infl
        self.by_cohort = collections.defaultdict(list)
        for k, v in recs.items():
            self.by_cohort[v[0]['cohort']].append(v)
        self.lob_of = {v[0]['cohort']: v[0]['lob'] for v in recs.values()}
        self.fit()

    # ---------------------------------------------------------------- fit
    def fit(self):
        recs = self.recs
        # reporting pattern per cohort, frequency per exposure
        self.rep_pat = {}
        self.freq = {}
        for c, R in self.by_cohort.items():
            s = [0.0] * LAGS
            for v in R:
                for j in range(LAGS):
                    s[j] += v[j]['new_reported_count']
            T = sum(s)
            self.rep_pat[c] = [x / T for x in s]
            self.freq[c] = T / sum(v[0]['exposure'] for v in R)
        # deflated severity by line, Buhlmann-Straub with record units
        self.sev_mu = {}
        self.sev_K = {}
        self.sev_var = {}
        for lob in sorted(set(self.lob_of.values())):
            units = []
            for v in recs.values():
                if v[0]['lob'] != lob:
                    continue
                u = [(r['primary_paid'] / r['inflation_index'] / r['new_reported_count'], r['new_reported_count'])
                     for r in v if r['new_reported_count'] > 0]
                units.append(u)
            num = den = 0.0
            mi = []
            for u in units:
                wi = sum(w for _, w in u)
                xi = sum(x * w for x, w in u) / wi
                num += sum(w * (x - xi) ** 2 for x, w in u)
                den += len(u) - 1
                mi.append((xi, wi))
            epv = num / den
            W = sum(w for _, w in mi)
            xb = sum(x * w for x, w in mi) / W
            vhm = (sum(w * (x - xb) ** 2 for x, w in mi) - (len(units) - 1) * epv) / (W - sum(w * w for _, w in mi) / W)
            self.sev_mu[lob] = xb
            self.sev_K[lob] = epv / vhm if vhm > 0 else 1e12
            # per-claim variance for standardization
            cells = [(x, w) for u in units for x, w in u]
            self.sev_var[lob] = sum(w * (x - xb) ** 2 for x, w in cells) / len(cells)
        # deflated payment pattern per cohort (all types)
        self.pay_pat = {}
        for c, R in self.by_cohort.items():
            s = [0.0] * LAGS
            for v in R:
                for j in range(LAGS):
                    r = v[j]
                    s[j] += (r['primary_paid'] + r['settlement_paid'] + r['reopening_paid']) / r['inflation_index']
            T = sum(s)
            self.pay_pat[c] = [x / T for x in s]
        # reopening: delayed binomial per cohort, beta prior per line
        self.reop = {}
        for c, R in self.by_cohort.items():
            ev = el = 0
            for v in R:
                for j in range(REOPEN_DELAY, LAGS):
                    ev += v[j]['reopened_count'] - v[j - 1]['reopened_count']
                    el += v[j - REOPEN_DELAY]['new_reported_count']
            self.reop[c] = (ev, el)
        # structural payment model: settlement kernel on deflated primary (delays 1 and 4),
        # reopening paid per reopened count
        self.st_coef = {}
        self.reop_sev = {}
        for lob in sorted(set(self.lob_of.values())):
            X = []; y = []; rc = rp = 0.0
            for v in recs.values():
                if v[0]['lob'] != lob:
                    continue
                pr = [r['primary_paid'] / r['inflation_index'] for r in v]
                for j in range(1, LAGS):
                    X.append([pr[j - 1] if j - 1 < REP_LAGS else 0.0,
                              pr[j - 4] if 0 <= j - 4 < REP_LAGS else 0.0])
                    y.append(v[j]['settlement_paid'] / v[j]['inflation_index'])
                    rc += v[j]['reopened_count'] - v[j - 1]['reopened_count']
                    rp += v[j]['reopening_paid'] / v[j]['inflation_index']
            self.st_coef[lob] = nnls(X, y)
            self.reop_sev[lob] = rp / rc
        # exact settlement structure: nominal settlement at lag j equals ratio_c x deflated primary
        # of lag j-d times inflation at j, with d = 1 (fast) or 4 (slow) per record
        self.st_ratio = {}
        self.fast_share = {}
        self.reop_sev_c = {}
        for c, R in self.by_cohort.items():
            sd = sum(r['settlement_paid'] / r['inflation_index'] for v in R for r in v)
            pd = sum(r['primary_paid'] / r['inflation_index'] for v in R for r in v)
            ratio = sd / pd
            self.st_ratio[c] = ratio
            nf = 0
            for v in R:
                nf += self.regime(v, ratio) == 'F'
            self.fast_share[c] = nf / len(R)
            for reg in ('F', 'S'):
                acc = [0.0] * LAGS
                for v in R:
                    if self.regime(v, ratio) == reg:
                        for j in range(LAGS):
                            r = v[j]
                            acc[j] += (r['primary_paid'] + r['settlement_paid'] + r['reopening_paid']) / r['inflation_index']
                T = sum(acc)
                self.pay_pat[(c, reg)] = [x / T for x in acc] if T > 0 else self.pay_pat[c]
            rc = sum(v[-1]['reopened_count'] for v in R)
            rp = sum(r['reopening_paid'] / r['inflation_index'] for v in R for r in v)
            self.reop_sev_c[c] = rp / rc if rc else 0.0
        self.reop_q = collections.defaultdict(lambda: [0, 0])
        for qq in self.queries:
            H = qq['history']
            if len(H) > REOPEN_DELAY and 'cohort' in H[0]:
                H = sorted(H, key=lambda r: r['development_lag'])
                self.reop_q[H[0]['cohort']][0] += H[-1]['reopened_count']
                self.reop_q[H[0]['cohort']][1] += sum(H[j]['new_reported_count'] for j in range(len(H) - REOPEN_DELAY))
        self.reop_prior = {}
        for lob in sorted(set(self.lob_of.values())):
            ps = [self.reop[c][0] / self.reop[c][1] for c in self.reop if self.lob_of[c] == lob]
            m = sum(ps) / len(ps)
            v = sum((p - m) ** 2 for p in ps) / (len(ps) - 1)
            ab = max(m * (1 - m) / max(v, 1e-9) - 1, 1.0)
            self.reop_prior[lob] = (m * ab, (1 - m) * ab)

    # ------------------------------------------------------------ helpers
    def growth(self, t):
        """trailing average log growth of inflation index at calendar t"""
        n = self.cfg.get('infl_window', 4)
        pts = [s for s in range(t - n, t + 1) if s in self.infl]
        if len(pts) < 2:
            return 0.0
        return math.log(self.infl[pts[-1]] / self.infl[pts[0]]) / (pts[-1] - pts[0])

    def proj(self, tcut, t):
        """projected inflation index at calendar t using only indices at or before tcut"""
        if t <= tcut and t in self.infl:
            return self.infl[t]
        mode = self.cfg.get('infl', 'trail')
        if mode == 'seasonal':
            L = math.log
            if all(s in self.infl for s in (tcut, tcut - 4)):
                drift = L(self.infl[tcut]) - L(self.infl[tcut - 4])
                prev = self.proj(tcut, t - 4) if (t - 4 > tcut or (t - 4) in self.infl) else None
                if prev is not None:
                    return prev * math.exp(drift)
        g = self.growth(tcut)
        return self.infl[tcut] * math.exp(g * (t - tcut))

    # ---------------------------------------------------------- estimators
    def severity(self, H):
        lob = H[0]['lob']
        n = sum(r['new_reported_count'] for r in H)
        s = sum(r['primary_paid'] / r['inflation_index'] for r in H)
        mu = self.sev_mu[lob]
        if n == 0:
            return mu
        mode = self.cfg.get('sev', 'bs')
        if mode == 'obs':
            return s / n
        if mode == 'bf':
            N = self.future_reports(H)
            fut = sum(N[len(H):REP_LAGS])
            return (s + fut * mu) / (n + fut)
        if mode == 'lf':
            Z = min(1.0, math.sqrt(n / self.cfg.get('lf_full', 1082)))
        elif mode == 'K':
            Z = n / (n + self.cfg.get('K', 100))
        else:
            Z = n / (n + self.sev_K[lob])
        return Z * s / n + (1 - Z) * mu

    def reporting(self, H):
        c = H[0]['cohort']
        k = len(H)
        p = self.rep_pat[c]
        lam = H[0]['exposure'] * self.freq[c]
        obs = [float(r['new_reported_count']) for r in H]
        if self.cfg.get('rep', 'bf') == 'cl':
            P = sum(p[:k])
            lam = sum(obs) / P if P > 0 else lam
        elif self.cfg.get('rep') == 'cred':
            P = sum(p[:k])
            Z = P
            lam = Z * (sum(obs) / P) + (1 - Z) * lam
        out = obs + [lam * p[j] for j in range(k, LAGS)]
        T = sum(out)
        return [x / T for x in out]

    def cash(self, H):
        c = H[0]['cohort']
        k = len(H)
        ap = H[0]['accident_period']
        tcut = ap + k
        g = self.growth(tcut)
        base = self.infl[tcut]
        p = self.pay_pat[c]
        if self.cfg.get('cash') == 'clreg':
            reg = self.regime(H, self.st_ratio[c])
            if reg: p = self.pay_pat[(c, reg)]
        out = [0.0] * LAGS
        for j in range(k, LAGS):
            t = ap + j + 1
            out[j] = p[j] * base * math.exp(g * (t - tcut))
        T = sum(out)
        if T <= 0:
            out = [0.0] * LAGS
            out[LAGS - 1] = 1.0
            return out
        return [x / T for x in out]

    def future_reports(self, H, mode='bf'):
        c = H[0]['cohort']
        k = len(H)
        p = self.rep_pat[c]
        lam = H[0]['exposure'] * self.freq[c]
        if mode == 'cl':
            P = sum(p[:k]); n = sum(r['new_reported_count'] for r in H)
            if P > 0 and n > 0:
                lam = n / P
        return [float(r['new_reported_count']) for r in H] + [lam * p[j] for j in range(k, LAGS)]

    @staticmethod
    def regime(H, ratio):
        k = len(H)
        pr = [r['primary_paid'] / r['inflation_index'] for r in H]
        ef = es = 0.0
        for j in range(1, k):
            st = H[j]['settlement_paid']
            f = ratio * pr[j - 1] * H[j]['inflation_index']
            sl = ratio * pr[j - 4] * H[j]['inflation_index'] if j >= 4 else 0.0
            ef += abs(st - f)
            es += abs(st - sl)
        if abs(ef - es) < 1e-6 * (1 + ef + es):
            return None
        return 'F' if ef < es else 'S'

    def cash_exact(self, H):
        c = H[0]['cohort']; lob = H[0]['lob']
        k = len(H)
        ap = H[0]['accident_period']
        tcut = ap + k
        g = self.growth(tcut)
        base = self.infl[tcut]
        N = self.future_reports(H, self.cfg.get('cash_rep', 'bf'))
        mu = self.sev_mu[lob] if self.cfg.get('cash_mu', 'line') == 'line' else self.severity(H)
        pr = [H[j]['primary_paid'] / H[j]['inflation_index'] if j < k else N[j] * mu for j in range(LAGS)]
        for j in range(REP_LAGS, LAGS):
            pr[j] = 0.0; N[j] = 0.0
        ratio = self.st_ratio[c]
        reg = self.regime(H, ratio) if not self.cfg.get('no_regime') else None
        wf = self.fast_share[c] if reg is None else (1.0 if reg == 'F' else 0.0)
        ev, el = self.reop[c]
        prate = ev / el
        rsev = self.reop_sev_c[c] if self.cfg.get('reop_sev', 'c') == 'c' else self.reop_sev[lob]
        out = [0.0] * LAGS
        for j in range(k, LAGS):
            st = wf * ratio * pr[j - 1] + (1 - wf) * (ratio * pr[j - 4] if j >= 4 else 0.0)
            ro = prate * N[j - 4] * rsev if j >= 4 else 0.0
            t = ap + j + 1
            if self.cfg.get('no_reop'): ro = 0.0
            out[j] = (pr[j] + st + ro) * (self.proj(tcut, t) if self.cfg.get('infl') != 'none' else 1.0)
        T = sum(out)
        if T <= 0:
            return [0.0] * k + [1.0 / (LAGS - k)] * (LAGS - k)
        return [x / T for x in out]

    def cash_struct(self, H):
        if self.cfg.get('cash', 'exact') == 'exact':
            return self.cash_exact(H)
        c = H[0]['cohort']; lob = H[0]['lob']
        k = len(H)
        ap = H[0]['accident_period']
        tcut = ap + k
        g = self.growth(tcut)
        base = self.infl[tcut]
        N = self.future_reports(H)
        mu = self.sev_mu[lob]
        pr = [H[j]['primary_paid'] / H[j]['inflation_index'] if j < k else N[j] * mu for j in range(LAGS)]
        for j in range(REP_LAGS, LAGS):
            pr[j] = 0.0
        a1, a4 = self.st_coef[lob]
        ev, el = self.reop[c]
        prate = ev / el
        out = [0.0] * LAGS
        for j in range(k, LAGS):
            st = (a1 * pr[j - 1] if j >= 1 else 0.0) + (a4 * pr[j - 4] if j >= 4 else 0.0)
            ro = prate * N[j - 4] * self.reop_sev[lob] if j >= 4 else 0.0
            t = ap + j + 1
            out[j] = (pr[j] + st + ro) * self.proj(tcut, t)
        T = sum(out)
        return [x / T for x in out]

    def reopen_rate(self, H):
        c = H[0]['cohort']
        lob = H[0]['lob']
        a, b = self.reop_prior[lob]
        ev, el = self.reop[c]
        k = len(H)
        qev = H[-1]['reopened_count']
        qel = sum(H[j]['new_reported_count'] for j in range(0, max(0, k - REOPEN_DELAY)))
        if self.cfg.get('reop_pool'):
            pev, pel = self.reop_q[c]
            ev += pev; el += pel
        S = self.cfg.get('reop_strength')
        if S:
            p = (a + ev) / (a + b + el)
            return (S * p + qev) / (S + qel)
        return (a + ev + qev) / (a + b + el + qel)

    def cellz(self, r):
        lob = r['lob']
        n = r['new_reported_count']
        mu = self.sev_mu[lob]
        sd = math.sqrt(self.sev_var[lob])
        if self.cfg.get('ll_z') == 'log':
            return math.log(max(r['primary_paid'], 1e-9) / r['inflation_index'] / (n * mu)) * math.sqrt(n)
        return (r['primary_paid'] / r['inflation_index'] - n * mu) / (math.sqrt(n) * sd)

    def ll_train(self, c):
        if not hasattr(self, '_llt'):
            self._llt = {}
            thr = self.cfg.get('ll_thr', 1.645)
            for cc, R in self.by_cohort.items():
                ex = cells = 0
                for v in R:
                    for r in v:
                        if r['new_reported_count'] > 0:
                            cells += 1; ex += self.cellz(r) > thr
                self._llt[cc] = (ex, cells)
        return self._llt[c]

    def large(self, H):
        thr = self.cfg.get('ll_thr', 1.645)
        mode = self.cfg.get('ll', 'beta')
        ex = cells = 0
        zs = []
        for r in H:
            if r['new_reported_count'] > 0:
                z = self.cellz(r)
                cells += 1
                ex += z > thr
                zs.append(z)
        mz = sum(zs) / len(zs) if zs else 0.0
        if mode == 'mean':
            return mz
        if mode == 'max':
            return max(zs) if zs else 0.0
        if mode == 'raw':
            return ex / cells if cells else 0.0
        if mode == 'cohort':
            tex, tc = self.ll_train(H[0]['cohort'])
            return (tex + ex) / (tc + cells)
        if mode == 'last':
            return zs[-1] if zs else 0.0
        a = 0.3; b = 4.7
        return (a + ex) / (a + b + cells) + 1e-6 * mz

    # ---------------------------------------------------------------- run
    def run(self):
        preds = []
        peers = collections.defaultdict(list)
        rr = {}
        ll = {}
        for qq in self.queries:
            H = sorted(qq['history'], key=lambda r: r['development_lag'])
            rid = qq['record_id']
            peers[(H[0]['accident_period'], H[0]['lob'])].append(rid)
            rr[rid] = self.reopen_rate(H)
            ll[rid] = self.large(H)
            preds.append({
                'record_id': rid,
                'ultimate_severity': self.severity(H),
                'reporting_pattern': self.reporting(H),
                'cash_pattern': self.cash(H) if self.cfg.get('cash', 'exact') in ('cl', 'clreg') else self.cash_struct(H),
            })
        rp = pctile_within(peers, rr)
        lp = pctile_within(peers, ll)
        for p in preds:
            p['reopening_flag'] = bool(rp[p['record_id']] >= 0.8)
            p['large_loss_score'] = lp[p['record_id']]
        return preds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', default='/workspace/data')
    ap.add_argument('--out', default='/workspace/reserving_results.json')
    ap.add_argument('--only', default='', help='comma list of fields to keep (diagnostics)')
    ap.add_argument('--cfg', default='{}', help='JSON dict of estimator options')
    a = ap.parse_args()
    train = load(a.data + '/train.jsonl')
    queries = load(a.data + '/queries.jsonl')
    cfg = dict(BEST)
    cfg.update(json.loads(a.cfg))
    m = Model(train, queries, cfg)
    preds = m.run()
    for p in preds:
        p['reporting_pattern'] = [round(x, 10) for x in p['reporting_pattern']]
        p['cash_pattern'] = [round(x, 10) for x in p['cash_pattern']]
    if a.only:
        keep = set(a.only.split(',')) | {'record_id'}
        preds = [{k: v for k, v in p.items() if k in keep} for p in preds]
    with open(a.out, 'w') as f:
        json.dump({'predictions': preds, 'self_reported_metrics': {'record_count': len(preds)}}, f)


if __name__ == '__main__':
    main()
