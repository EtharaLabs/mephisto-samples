"""Receivables finance portfolio surveillance.

Reproduces the desk's monthly surveillance record for the obligor-periods in
queries.jsonl. Each field is estimated from the completed (closed) cases of the
matching ledger view and applied to the obligor's month-end snapshot.

The closed-case ledgers show a regime change from event period 14 onward
(dilution up, collection slower, recoveries and availability down), so every
model carries a regime indicator and query periods are scored in the current
regime.

Usage: python receivables_surveillance.py [--eval]
  --eval  score the approach against history/surveillance.jsonl
"""
import glob
import json
import os
import sys

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression

W = os.path.dirname(os.path.abspath(__file__))
REGIME_START = 14
NB = 8

SKIP = {'kind', 'case_id', 'booked_period', 'event_period', '_file', 'as_booked',
        'restated_period', 'cohort', 'obligor_id', 'period'}


def rd(p):
    with open(p) as f:
        return [json.loads(l) for l in f if l.strip()]


def load_view(v):
    rows = []
    for f in sorted(glob.glob(f'{W}/{v}/*.jsonl')):
        rows.extend(rd(f))
    closed = [r for r in rows if r['kind'] == 'closed']
    snaps = {(r['obligor_id'], r['period']): r for r in rows if r['kind'] == 'snapshot'}
    return closed, snaps


def feat_names(closed, targets):
    r = closed[0]
    return [k for k in sorted(r) if k not in SKIP and k not in targets
            and isinstance(r[k], (int, float))]


def regime(p):
    return 1.0 if p >= REGIME_START else 0.0


def mat(rows, F, periods):
    return np.array([[r[f] for f in F] + [regime(p)] for r, p in zip(rows, periods)], float)


def training(closed, F, max_event):
    c = [r for r in closed if r['event_period'] <= max_event]
    return c, mat(c, F, [r['event_period'] for r in c])


def gbr(**kw):
    base = dict(n_estimators=300, max_depth=3, learning_rate=0.03, subsample=0.8,
                min_samples_leaf=10, random_state=0)
    base.update(kw)
    return GradientBoostingRegressor(**base)


class Models:
    def __init__(self, max_event=20):
        self.max_event = max_event
        self.views = {v: load_view(v) for v in
                      ['dilution', 'collections', 'disputes', 'delinquencies',
                       'borrowing_base', 'writeoffs']}
        self.fit_all()

    def fit_all(self):
        me = self.max_event
        # dilution
        c, _ = self.views['dilution']
        self.dF = feat_names(c, {'dilution_ratio', 'open_balance'})
        tr, x = training(c, self.dF, me)
        self.dil = gbr().fit(x, [r['dilution_ratio'] for r in tr])
        # collections: discrete-time hazard over the 8 bands
        c, _ = self.views['collections']
        self.cF = feat_names(c, {'paid_bucket', 'last_observed_bucket'})
        tr, x = training(c, self.cF, me)
        xs, ys = [], []
        for r, xr in zip(tr, x):
            pb, lo = r['paid_bucket'], r['last_observed_bucket']
            last = pb if pb >= 0 else (lo if lo == NB - 1 else lo - 1)
            for b in range(last + 1):
                xs.append(np.r_[xr, np.eye(NB)[b]])
                ys.append(1 if b == pb else 0)
        xs = np.array(xs)
        self.col = GradientBoostingClassifier(n_estimators=300, max_depth=3, learning_rate=0.05,
                                              subsample=0.8, min_samples_leaf=20,
                                              random_state=0).fit(xs, ys)
        # disputes
        c, _ = self.views['disputes']
        self.sF = feat_names(c, {'escalated'})
        tr, x = training(c, self.sF, me)
        self.dis = GradientBoostingClassifier(n_estimators=200, max_depth=2, learning_rate=0.05,
                                              random_state=0).fit(x, [r['escalated'] for r in tr])
        # recovery
        c, _ = self.views['delinquencies']
        self.rF = feat_names(c, {'recovered_fraction'})
        tr, x = training(c, self.rF, me)
        y = np.array([r['recovered_fraction'] for r in tr])
        self.rec = gbr().fit(x, y)
        self.rec_cuts = np.quantile(y, [0.25, 0.5, 0.75])
        # availability
        c, _ = self.views['borrowing_base']
        self.aF = feat_names(c, {'availability_ratio'})
        tr, x = training(c, self.aF, me)
        self.av = gbr().fit(x, [r['availability_ratio'] for r in tr])
        # loss
        c, _ = self.views['writeoffs']
        self.lF = feat_names(c, {'loss_amount'})
        tr, x = training(c, self.lF, me)
        self.loss = gbr(max_depth=2).fit(x, [r['loss_amount'] for r in tr])

    def snap(self, v, o, p):
        return self.views[v][1][(o, p)]

    def predict(self, recs):
        out = {}
        for o, p in recs:
            rid = f'{o}:p{p}'
            s = self.snap('dilution', o, p)
            ratio = float(self.dil.predict(mat([s], self.dF, [p]))[0])
            dil = max(0.0, ratio) * s['open_balance']

            s = self.snap('collections', o, p)
            xr = mat([s], self.cF, [p])[0]
            xb = np.array([np.r_[xr, np.eye(NB)[b]] for b in range(NB)])
            h = self.col.predict_proba(xb)[:, 1]
            surv, prof = 1.0, []
            for b in range(NB):
                prof.append(surv * h[b])
                surv *= 1 - h[b]

            s = self.snap('disputes', o, p)
            pd_ = self.dis.predict_proba(mat([s], self.sF, [p]))[0, 1]

            s = self.snap('delinquencies', o, p)
            rf = float(self.rec.predict(mat([s], self.rF, [p]))[0])
            tier = int(np.searchsorted(self.rec_cuts, rf))

            s = self.snap('borrowing_base', o, p)
            ar = float(self.av.predict(mat([s], self.aF, [p]))[0])
            head = ar * s['gross_receivables'] - s['reserve_holdback'] - s['drawn_balance']

            s = self.snap('writeoffs', o, p)
            el = max(0.0, float(self.loss.predict(mat([s], self.lF, [p]))[0]))
            loss = el * (1 - s['insured_share'])

            out[rid] = dict(record_id=rid, dilution_reserve=dil, collection_profile=prof,
                            dispute_flag=int(pd_ >= 0.5), recovery_tier=tier,
                            _head=head, _period=p, loss_reserve=loss)
        # dense rank within period cohort
        for p in {r['_period'] for r in out.values()}:
            rs = [r for r in out.values() if r['_period'] == p]
            vals = sorted({round(r['_head'], 2) for r in rs}, reverse=True)
            rank = {v: i + 1 for i, v in enumerate(vals)}
            for r in rs:
                r['availability_rank'] = rank[round(r['_head'], 2)]
        return out


def finalize(r):
    prof = [max(0.0, float(x)) for x in r['collection_profile']]
    tot = sum(prof)
    if tot > 1.0:
        prof = [x / tot for x in prof]
    prof = [float(f'{x:.8f}') for x in prof]
    while sum(prof) > 1.0:
        i = int(np.argmax(prof))
        prof[i] = float(f'{prof[i] - 1e-8:.8f}')
    return {'record_id': r['record_id'],
            'dilution_reserve': round(max(0.0, r['dilution_reserve']), 2),
            'collection_profile': prof,
            'dispute_flag': int(r['dispute_flag']),
            'recovery_tier': int(min(3, max(0, r['recovery_tier']))),
            'availability_rank': int(r['availability_rank']),
            'loss_reserve': round(max(0.0, r['loss_reserve']), 2)}


def evaluate():
    from scipy.stats import spearmanr
    hist = rd(f'{W}/history/surveillance.jsonl')
    m = Models(max_event=REGIME_START - 1)
    pred = m.predict([(h['obligor_id'], h['period']) for h in hist])
    H = {h['record_id']: h for h in hist}
    P = {k: finalize(v) for k, v in pred.items()}
    ids = list(H)
    def arr(d, k): return np.array([d[i][k] for i in ids], float)
    for k in ['dilution_reserve', 'loss_reserve']:
        a, b = arr(H, k), arr(P, k)
        print(k, 'mape', np.mean(np.abs(a - b) / a), 'corr', np.corrcoef(a, b)[0, 1])
    a = np.array([H[i]['collection_profile'] for i in ids]); b = np.array([P[i]['collection_profile'] for i in ids])
    print('profile L1', np.abs(a - b).sum(1).mean(), 'resid', (1 - a.sum(1)).mean(), (1 - b.sum(1)).mean())
    for k in ['dispute_flag', 'recovery_tier']:
        print(k, 'acc', np.mean(arr(H, k) == arr(P, k)))
    for p in [8, 10, 12]:
        sel = [i for i in ids if H[i]['period'] == p]
        print('rank', p, spearmanr([H[i]['availability_rank'] for i in sel],
                                   [P[i]['availability_rank'] for i in sel])[0])


def main():
    if '--eval' in sys.argv:
        evaluate()
        return
    Q = rd(f'{W}/queries.jsonl')
    m = Models()
    pred = m.predict([(q['obligor_id'], q['period']) for q in Q])
    with open(f'{W}/predictions.jsonl', 'w') as f:
        for q in Q:
            f.write(json.dumps(finalize(pred[q['record_id']])) + '\n')


if __name__ == '__main__':
    main()
