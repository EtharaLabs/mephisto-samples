"""Receivables finance portfolio surveillance.

Reproduces the desk's monthly surveillance record for the obligor-periods in
queries.jsonl.

Approach, per field:
  * a "ledger model" is fitted on the completed (closed) cases of the matching
    view, using the corrected values, with a regime indicator because the
    ledgers shift from event period 14 onward;
  * the ledger model is applied to the obligor's month-end snapshot and then
    calibrated to the desk's own published records (history/surveillance.jsonl),
    which are the reference for what the desk's output looks like.

Usage: python receivables_surveillance.py [--eval]
  --eval  grouped cross-validation of the calibrated fields against history
"""
import glob
import json
import os
import sys

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression, RidgeCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import SplineTransformer, StandardScaler

W = os.path.dirname(os.path.abspath(__file__))
REGIME_START = 14
# views whose query periods are scored in the current regime
QREG = set(os.environ.get("QREG", "dil,col,dis,rec,av,loss").split(","))
PIT = os.environ.get("PIT", "0") == "1"
NOREG = os.environ.get("NOREG", "0") == "1"
REC_DESIGN = os.environ.get("REC_DESIGN", "full")
MAX_EVENT = int(os.environ.get("MAX_EVENT", 99))
NB = 8
DISPUTE_THRESHOLD = float(os.environ.get("DTHR", 0.4))


def rd(p):
    with open(p) as f:
        return [json.loads(l) for l in f if l.strip()]


def load_view(v):
    rows = []
    for f in sorted(glob.glob(f'{W}/{v}/*.jsonl')):
        rows.extend(rd(f))
    closed = [r for r in rows if r['kind'] == 'closed']
    snaps = {(r['obligor_id'], r['period']): r for r in rows if r['kind'] == 'snapshot'}
    return closed, snaps


def regime(p):
    if NOREG:
        return 0.0
    return 1.0 if p >= REGIME_START else 0.0


def onehot(v, levels):
    return [float(v == k) for k in levels[1:]]


# ---- feature maps per view -------------------------------------------------

def x_dil(r):
    return ([r['invoice_size_log'], r['pricing_dispute_index'], r['promo_intensity'],
             r['return_propensity'], r['terms_days']]
            + onehot(r['channel'], range(3)) + onehot(r['product_mix'], range(4))
            + onehot(r['terms_days'], (30, 45, 60, 90)))


def x_col(r):
    return ([r['dispute_share'], r['past_due_share'], r['payment_regularity'],
             r['remittance_lag'], r['terms_days']]
            + onehot(r['region'], range(5)) + onehot(r['terms_days'], (30, 45, 60, 90)))


def x_dis(r):
    return ([r['contact_responsiveness'], r['days_since_last_dispute'], r['invoice_error_rate'],
             r['open_dispute_count'], r['po_mismatch_rate']]
            + onehot(r['contract_type'], range(4)))


def x_rec(r):
    # recoveries step down once an exposure is 75+ days past due, and the
    # size effect depends on the legal stage
    stage = [float(r['legal_stage'] == k) for k in range(4)]
    return ([r['days_past_due'], float(r['days_past_due'] > 75), r['guarantor_strength'],
             r['prior_cures'], r['secured_share']]
            + stage[1:] + [r['exposure_log'] * st for st in stage])


def x_av(r):
    # the availability cycle runs a sixth of a season ahead per advance band
    ang = 2 * np.pi * (r['seasonality_phase'] + r['advance_band'] / 6.0)
    return ([r['concentration_index'], r['cross_aged_share'], r['dilution_history'],
             r['ineligible_share'], r['insurance_coverage'], np.cos(ang), np.sin(ang)]
            + onehot(r['advance_band'], range(4)))


def x_loss(r):
    return ([r['credit_limit_utilisation'], r['insured_share'], r['payment_score'],
             r['sector_stress'], r['years_relationship'], np.log(r['exposure'])]
            + onehot(r['rating_band'], range(4)))


def with_regime(fx, rows, periods):
    return np.array([fx(r) + [regime(p)] for r, p in zip(rows, periods)], float)


def gbr(**kw):
    base = dict(n_estimators=500, max_depth=3, learning_rate=0.03, subsample=0.8,
                min_samples_leaf=10, random_state=0)
    base.update(kw)
    return GradientBoostingRegressor(**base)


def ridge():
    return RidgeCV(alphas=np.logspace(-4, 3, 15))


# ---- ledger models ---------------------------------------------------------

def as_of(closed, asof):
    """Closed rows as the ledger stood at month `asof`: only rows already
    booked, carrying the as-booked values for corrections made later."""
    out = []
    for r in closed:
        if r['event_period'] > MAX_EVENT:
            continue
        if asof is None:
            out.append(r)
            continue
        if r['booked_period'] > asof:
            continue
        if 'as_booked' in r and r['restated_period'] > asof:
            r = dict(r, **r['as_booked'])
        out.append(r)
    return out


def load_all():
    return {v: load_view(v) for v in ['dilution', 'collections', 'disputes', 'delinquencies',
                                       'borrowing_base', 'writeoffs']}


class Ledger:
    def __init__(self, views, asof=None):
        self.views = views
        ev = lambda c: [r['event_period'] for r in c]
        get = lambda v: as_of(views[v][0], asof)

        c = get('dilution')
        self.dil = gbr(max_depth=2).fit(with_regime(x_dil, c, ev(c)),
                                        [r['dilution_ratio'] for r in c])

        # collections: discrete-time hazard over the 8 bands; censored cohorts
        # contribute exposure up to their last observed band.
        c = get('collections')
        x = with_regime(x_col, c, ev(c))
        self.col_sc = StandardScaler().fit(x)
        x = self.col_sc.transform(x)
        xs, ys = [], []
        for r, xr in zip(c, x):
            pb, lo = r['paid_bucket'], r['last_observed_bucket']
            last = pb if pb >= 0 else lo
            for b in range(last + 1):
                xs.append(np.r_[xr, np.eye(NB)[b]])
                ys.append(int(b == pb))
        self.col = LogisticRegression(C=1.0, max_iter=5000).fit(np.array(xs), ys)

        c = get('disputes')
        x = with_regime(x_dis, c, ev(c))
        self.dis_sc = StandardScaler().fit(x)
        self.dis = LogisticRegression(C=10, max_iter=5000).fit(
            self.dis_sc.transform(x), [r['escalated'] for r in c])

        c = get('delinquencies')
        self.rec = LinearRegression().fit(with_regime(x_rec, c, ev(c)),
                                        [r['recovered_fraction'] for r in c])

        c = get('borrowing_base')
        # additive in the logit of the availability ratio
        y = np.array([r['availability_ratio'] for r in c])
        self.av = make_pipeline(
            ColumnTransformer([('s', SplineTransformer(n_knots=6, degree=3), list(range(5)))],
                              remainder='passthrough'),
            LinearRegression()).fit(with_regime(x_av, c, ev(c)), np.log(y / (1 - y)))

        c = get('writeoffs')
        x = with_regime(x_loss, c, ev(c))
        y = np.array([r['loss_amount'] > 0 for r in c])
        self.loss_sc = StandardScaler().fit(x)
        self.pd = LogisticRegression(C=1.0, max_iter=5000).fit(self.loss_sc.transform(x), y)

    def snaps(self, v, recs):
        S = self.views[v][1]
        return [S[(o, p)] for o, p in recs]

    def features(self, recs):
        """Ledger-model outputs and raw snapshot features for each record."""
        P0 = [p for _, p in recs]
        PR = lambda k: P0 if k in QREG else [0] * len(P0)
        f = {}
        s = self.snaps('dilution', recs)
        f['ob'] = np.array([r['open_balance'] for r in s])
        f['dil_raw'] = np.array([x_dil(r) for r in s], float)
        f['dil_cp'] = self.dil.predict(with_regime(x_dil, s, PR('dil')))

        s = self.snaps('collections', recs)
        f['col_raw'] = np.array([x_col(r) for r in s], float)
        xx = self.col_sc.transform(with_regime(x_col, s, PR('col')))
        prof = []
        for xr in xx:
            h = self.col.predict_proba(np.array([np.r_[xr, np.eye(NB)[b]] for b in range(NB)]))[:, 1]
            prof.append(np.cumprod(np.r_[1.0, 1 - h[:-1]]) * h)
        f['col_cp'] = np.array(prof)

        s = self.snaps('disputes', recs)
        f['dis_raw'] = np.array([x_dis(r) for r in s], float)
        f['dis_cp'] = self.dis.predict_proba(self.dis_sc.transform(with_regime(x_dis, s, PR('dis'))))[:, 1]

        s = self.snaps('delinquencies', recs)
        f['rec_raw'] = np.array([x_rec(r) for r in s], float)
        f['rec_cp'] = self.rec.predict(with_regime(x_rec, s, PR('rec')))
        # the desk tiers recoveries against obligors at the same legal stage:
        # centre on the stage mean across the whole book that month
        S = self.views['delinquencies'][1]
        centre = {}
        for p, preg in sorted(set(zip(P0, PR('rec')))):
            book = [r for (o, q), r in S.items() if q == p]
            pred = self.rec.predict(with_regime(x_rec, book, [preg] * len(book)))
            for st in range(4):
                centre[(p, st)] = pred[[r['legal_stage'] == st for r in book]].mean()
        f['rec_idx'] = f['rec_cp'] - np.array([centre[(p, r['legal_stage'])] for p, r in zip(P0, s)])

        s = self.snaps('borrowing_base', recs)
        ar = 1 / (1 + np.exp(-self.av.predict(with_regime(x_av, s, PR('av')))))
        f['head'] = np.array([a * r['gross_receivables'] - r['reserve_holdback'] - r['drawn_balance']
                              for a, r in zip(ar, s)])

        s = self.snaps('writeoffs', recs)
        f['loss_raw'] = np.array([x_loss(r) for r in s], float)
        f['ex'] = np.array([r['exposure'] for r in s])
        f['ins'] = np.array([r['insured_share'] for r in s])
        f['pd'] = self.pd.predict_proba(self.loss_sc.transform(with_regime(x_loss, s, PR('loss'))))[:, 1]
        f['period'] = np.array(P0)
        return f


def ledger_features(views, recs):
    """Features for each record from the ledger as it stood at the record's
    period (point in time) or from the full ledger."""
    if not PIT:
        return Ledger(views).features(recs)
    parts = {}
    for p in sorted({p for _, p in recs}):
        idx = [i for i, (_, q) in enumerate(recs) if q == p]
        parts[p] = (idx, Ledger(views, asof=p).features([recs[i] for i in idx]))
    n = len(recs)
    keys = next(iter(parts.values()))[1].keys()
    f = {}
    for k in keys:
        first = next(iter(parts.values()))[1][k]
        arr = np.zeros((n,) + first.shape[1:], dtype=first.dtype)
        for idx, fp in parts.values():
            arr[idx] = fp[k]
        f[k] = arr
    return f


# ---- calibration to the desk's published records ---------------------------

def design(f, k):
    if k == 'dil':
        return np.c_[f['dil_raw'], f['dil_cp']]
    if k == 'col':
        return np.c_[f['col_raw'], f['col_cp']]
    if k == 'rec':
        return np.c_[f['rec_raw'], f['rec_cp']]
    if k == 'loss':
        return np.c_[f['loss_raw'], np.log(f['pd'])]


def fit_cuts(x, t):
    """Three ordered cut points on x that best reproduce the tiers t."""
    grid = np.quantile(x, np.linspace(0.05, 0.95, 46))
    best, cuts = -1.0, None
    for i in range(len(grid)):
        for j in range(i + 1, len(grid)):
            for k in range(j + 1, len(grid)):
                c = (grid[i], grid[j], grid[k])
                acc = np.mean(np.searchsorted(c, x) == t)
                if acc > best:
                    best, cuts = acc, c
    return np.array(cuts)


class Desk:
    def fit(self, f, hist):
        ratio = np.array([h['dilution_reserve'] for h in hist]) / f['ob']
        self.dil = ridge().fit(design(f, 'dil'), np.log(ratio))
        H = np.array([h['collection_profile'] for h in hist])
        self.col = [ridge().fit(design(f, 'col'), H[:, b]) for b in range(NB)]
        xr = design(f, 'rec')
        self.rec_sc = StandardScaler().fit(xr)
        self.rec = LogisticRegression(C=10, max_iter=5000).fit(
            self.rec_sc.transform(xr), [h['recovery_tier'] for h in hist])
        L = np.array([h['loss_reserve'] for h in hist])
        self.loss = ridge().fit(design(f, 'loss'), np.log(L / (f['ex'] * (1 - f['ins']))))
        return self

    def predict(self, f, ids):
        dil = np.exp(self.dil.predict(design(f, 'dil'))) * f['ob']
        prof = np.clip(np.column_stack([m.predict(design(f, 'col')) for m in self.col]), 0, None)
        tier = self.rec.predict(self.rec_sc.transform(design(f, 'rec')))
        loss = np.exp(self.loss.predict(design(f, 'loss'))) * f['ex'] * (1 - f['ins'])
        flag = (f['dis_cp'] >= DISPUTE_THRESHOLD).astype(int)
        out = []
        for i, rid in enumerate(ids):
            out.append(dict(record_id=rid, dilution_reserve=dil[i], collection_profile=prof[i],
                            dispute_flag=flag[i], recovery_tier=tier[i],
                            availability_rank=0, loss_reserve=loss[i]))
        # dense rank by estimated headroom within each period cohort
        for p in set(f['period'].tolist()):
            idx = [i for i in range(len(ids)) if f['period'][i] == p]
            vals = sorted({round(f['head'][i], 2) for i in idx}, reverse=True)
            rank = {v: j + 1 for j, v in enumerate(vals)}
            for i in idx:
                out[i]['availability_rank'] = rank[round(f['head'][i], 2)]
        return out


def subset(f, idx):
    return {k: v[idx] for k, v in f.items()}


def finalize(r):
    prof = [max(0.0, float(x)) for x in r['collection_profile']]
    tot = sum(prof)
    if tot > 1.0:
        prof = [x / tot for x in prof]
    prof = [float(f'{x:.8f}') for x in prof]
    while sum(prof) > 1.0:
        i = int(np.argmax(prof))
        prof[i] = float(f'{prof[i] - 1e-8:.8f}')
    return {'record_id': r['record_id'],
            'dilution_reserve': round(max(0.0, float(r['dilution_reserve'])), 2),
            'collection_profile': prof,
            'dispute_flag': int(r['dispute_flag']),
            'recovery_tier': int(min(3, max(0, int(r['recovery_tier'])))),
            'availability_rank': int(r['availability_rank']),
            'loss_reserve': round(max(0.0, float(r['loss_reserve'])), 2)}


def evaluate():
    from scipy.stats import spearmanr
    hist = rd(f'{W}/history/surveillance.jsonl')
    views = load_all()
    recs = [(h['obligor_id'], h['period']) for h in hist]
    f = ledger_features(views, recs)
    obl = sorted({h['obligor_id'] for h in hist})
    folds = [set(obl[i::10]) for i in range(10)]
    pred = [None] * len(hist)
    for fo in folds:
        te = np.array([h['obligor_id'] in fo for h in hist])
        d = Desk().fit(subset(f, ~te), [h for h, t in zip(hist, te) if not t])
        ti = np.where(te)[0]
        for i, r in zip(ti, d.predict(subset(f, ti), [hist[i]['record_id'] for i in ti])):
            pred[i] = finalize(r)
    # ranks are cohort-level: recompute over full period cohorts
    full = Desk().fit(f, hist).predict(f, [h['record_id'] for h in hist])
    for i, r in enumerate(full):
        pred[i]['availability_rank'] = r['availability_rank']
    def arr(src, k): return np.array([r[k] for r in src], float)
    for k in ['dilution_reserve', 'loss_reserve']:
        a, b = arr(hist, k), arr(pred, k)
        e = np.abs(a - b) / a; print(f'{k:18s} mape {e.mean():.4f} medape {np.median(e):.4f} within5 {np.mean(e<.05):.3f} within10 {np.mean(e<.1):.3f} within20 {np.mean(e<.2):.3f}')
    a, b = arr(hist, 'collection_profile'), arr(pred, 'collection_profile')
    print(f'collection_profile L1 {np.abs(a - b).sum(1).mean():.4f}')
    for k in ['dispute_flag', 'recovery_tier']:
        print(f'{k:18s} acc {np.mean(arr(hist, k) == arr(pred, k)):.4f}')
    for p in sorted({h["period"] for h in hist}):
        sel = [i for i, h in enumerate(hist) if h['period'] == p]
        print(f'availability_rank p{p} spearman '
              f'{spearmanr([hist[i]["availability_rank"] for i in sel], [pred[i]["availability_rank"] for i in sel])[0]:.4f}')


def main():
    if '--eval' in sys.argv:
        evaluate()
        return
    hist = rd(f'{W}/history/surveillance.jsonl')
    Q = rd(f'{W}/queries.jsonl')
    views = load_all()
    desk = Desk().fit(ledger_features(views, [(h['obligor_id'], h['period']) for h in hist]), hist)
    out = desk.predict(ledger_features(views, [(q['obligor_id'], q['period']) for q in Q]),
                       [q['record_id'] for q in Q])
    with open(f'{W}/predictions.jsonl', 'w') as fh:
        for r in out:
            fh.write(json.dumps(finalize(r)) + '\n')


if __name__ == '__main__':
    main()
